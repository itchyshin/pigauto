from pathlib import Path
import subprocess,time,os,json
root=Path(__file__).resolve().parent;env=dict(os.environ);env.pop('NOT_CRAN',None);env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
cmd=['Rscript','--vanilla',str(root/'urls-network.R'),str(root)];start=time.monotonic()
with (root/'urls-network.log').open('w') as out:
 try:status=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=70).returncode
 except subprocess.TimeoutExpired:status='TIMEOUT_70_SECONDS'
r={'command':cmd,'exit':status,'elapsed_seconds':time.monotonic()-start,'thread_cap':1};(root/'urls-network-execution.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
