from pathlib import Path
import os,json,subprocess,time,concurrent.futures,hashlib
root=Path(__file__).resolve().parent
jobs=['spelling','urls','absence'];meta={}
def run(name):
 env=dict(os.environ);env.pop('NOT_CRAN',None)
 env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',_R_CHECK_FORCE_SUGGESTS_='true')
 if name=='absence':env.update(R_LIBS=str(root/'absence-library'),R_LIBS_USER=str(root/'absence-library'),R_LIBS_SITE='/nonexistent')
 command=['Rscript','--vanilla',str(root/(name+'.R')),str(root)];started=time.monotonic()
 with (root/(name+'.log')).open('w') as out:
  try:r=subprocess.run(command,env=env,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=150);status=r.returncode
  except subprocess.TimeoutExpired:status='TIMEOUT_150_SECONDS'
 result={'command':command,'exit':status,'elapsed_seconds':time.monotonic()-started,'thread_cap':1,'NOT_CRAN':'UNSET'}
 (root/(name+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n');return name,result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for name,r in pool.map(run,jobs):meta[name]=r;print(name,json.dumps(r),flush=True)
identity=json.loads((root/'identity.json').read_text());assert hashlib.sha256(Path(identity['path']).read_bytes()).hexdigest()==identity['sha256']
(root/'execution-summary.json').write_text(json.dumps(meta,indent=2)+'\n')
