from pathlib import Path
import hashlib,json,datetime
scratch=Path('/private/tmp/pigauto-final-closure-20261017');f=json.loads((scratch/'FINAL.json').read_text());root=Path(f['path']).parent/'mi-matrix';m=json.loads((root/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(f['path']))==m['archive_sha256']==f['sha256'];assert m['status']=='PASS' and not m['failures'];assert len(m['cells'])==4
records=[]
for c in m['cells']:
 assert len(c['steps'])==3
 for s in c['steps']:
  assert s['exit_code']==0 and s['archive_unchanged'] and s['archive_sha256_before']==s['archive_sha256_after']==f['sha256']
  assert sha(root/s['log'])==s['log_sha256'];records.append(dict(cell=c['cell'],step=s['step'],seconds=s['elapsed_seconds'],log=s['log'],log_sha256=s['log_sha256']))
repo=Path(m['working_directory'])
for rel,v in m['executed_sources'].items():assert sha(repo/rel)==v['sha256']
start=datetime.datetime.fromisoformat(m['created_utc']).timestamp();deps={}
for name in ['drmTMB','gllvmTMB']:
 p=(root/'both'/name).resolve();files=sorted(x for x in p.rglob('*') if x.is_file());newer=[str(x.relative_to(p)) for x in files if x.stat().st_mtime>start]
 assert not newer, (name,newer)
 desc=(p/'DESCRIPTION').read_text();version=next(x.split(':',1)[1].strip() for x in desc.splitlines() if x.startswith('Version:'))
 deps[name]=dict(version=version,installed_path=str(p),description_sha256=sha(p/'DESCRIPTION'),files_sha256={str(x.relative_to(p)):sha(x) for x in files},files_modified_since_matrix_start=newer,source_commit='Not embedded in installed package; installed package bytes, version, build metadata and paths retained')
report=dict(artifact_sha256=f['sha256'],artifact_source_commit=f['source_commit'],checker_start_commit=m['source_commit'],published_checker_commit='6cd5f65b06d0c3ee32ce4b2d5a67a22c06028116',executed_sources=m['executed_sources'],steps=records,steps_passed=len(records),elapsed_step_seconds=sum(x['seconds'] for x in records),backend_packages=deps,limits='Measured dependency symlink matrix, not clean-room dependency installation. Three downstream fits per real fixture, not the prior ten-seed M20 recovery campaign.',result='FINAL_MI_MATRIX_12_STEPS_VERIFIED')
(scratch/'final-mi-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(report['result'],len(records),[(n,v['version']) for n,v in deps.items()])
