from pathlib import Path
import subprocess,os,json,time,hashlib,datetime
root=Path(__file__).resolve().parent;meta=json.loads((root/'input.json').read_text());started=time.monotonic();records=[]
env=dict(os.environ);env.pop('NOT_CRAN',None);env.update(R_LIBS=meta['library'],R_LIBS_USER=meta['library'],R_LIBS_SITE='/nonexistent',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',_R_CHECK_FORCE_SUGGESTS_='true')
assert hashlib.sha256(Path(meta['artifact']['path']).read_bytes()).hexdigest()==meta['artifact']['sha256']
for name in sorted(meta['source_rmd_sha256']):
 remaining=600-(time.monotonic()-started)
 if remaining<=0:records.append({'file':name,'exit':'NOT_RUN_TOTAL_CAP'});break
 cmd=['Rscript','--vanilla',str(root/'render-one.R'),str(root),name];stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
 with (root/(name+'.log')).open('w') as out:
  try:exitcode=subprocess.run(cmd,env=env,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=min(120,remaining)).returncode
  except subprocess.TimeoutExpired:exitcode='TIMEOUT'
 r={'file':name,'command':cmd,'start_utc':stamp,'process_elapsed_seconds':time.monotonic()-begin,'exit':exitcode};records.append(r);(root/'execution.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(r),flush=True)
 if exitcode!=0:break
post=hashlib.sha256(Path(meta['artifact']['path']).read_bytes()).hexdigest();assert post==meta['artifact']['sha256']
for name,h in meta['source_rmd_sha256'].items():assert hashlib.sha256((root/'source/pigauto/vignettes'/name).read_bytes()).hexdigest()==h
(root/'identity-after.json').write_text(json.dumps({'archive_sha256':post,'unchanged_source_rmds':True,'total_process_seconds':time.monotonic()-started,'completed_vignettes':len(records),'all_six_success':len(records)==6 and all(r['exit']==0 for r in records)},indent=2)+'\n')
