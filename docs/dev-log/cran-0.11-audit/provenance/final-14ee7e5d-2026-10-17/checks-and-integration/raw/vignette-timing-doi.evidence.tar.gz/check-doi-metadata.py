from pathlib import Path
import urllib.request,urllib.error,json,hashlib,time
root=Path(__file__).resolve().parent;url='https://api.crossref.org/works/10.1126/science.1157704';started=time.monotonic();r={'url':url,'method':'GET','no_retry':True}
try:
 req=urllib.request.Request(url,headers={'User-Agent':'pigauto-release-validation/0.11.0'})
 with urllib.request.urlopen(req,timeout=20) as response:raw=response.read();r.update(http_status=response.status,final_url=response.url)
 (root/'crossref-raw.json').write_bytes(raw);r['sha256']=hashlib.sha256(raw).hexdigest();m=json.loads(raw)['message'];r.update(doi=m.get('DOI'),title=m.get('title'),journal=m.get('container-title'),volume=m.get('volume'),issue=m.get('issue'),page=m.get('page'),published=m.get('published'),first_author=m.get('author',[{}])[0]);r['identity_matches']=m.get('DOI','').lower()=='10.1126/science.1157704' and 'A Phylogenomic Study of Birds Reveals Their Evolutionary History'.lower() in ' '.join(m.get('title',[])).lower()
except Exception as e:r.update(error=type(e).__name__+': '+str(e))
r['elapsed_seconds']=time.monotonic()-started;r['doi_url_access']='Original exact-source URL check returned403; this metadata query does not erase that finding.'
(root/'doi-metadata.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
