test_that("completed_data returns the stored completed object exactly", {
  completed <- data.frame(x = c(1, 2), row.names = c("a", "b"))
  result <- structure(list(completed = completed), class = "pigauto_result")
  expect_identical(completed_data(result), result$completed)
})

test_that("result completion preserves input rows, classes, observed cells, and data-only gaps", {
  original <- data.frame(species = c("ghost", "a", "ghost", "c"),
                         value = c(NA_real_, 1, NA_real_, NA_real_),
                         group = factor(c("g", "a", "g", "c")),
                         stringsAsFactors = FALSE)
  imputed <- data.frame(value = c(10, 30), group = factor(c("a", "c")))
  info <- build_completed(original, imputed, species_col = "species",
                          input_row_order = c(2L, 4L))
  result <- structure(list(completed = info$completed, imputed_mask = info$imputed_mask),
                      class = "pigauto_result")
  expect_identical(completed_data(result), result$completed)
  expect_identical(result$completed$species, original$species)
  expect_identical(result$completed$value, c(NA_real_, 1, NA_real_, 30))
  expect_s3_class(result$completed$group, "factor")
  expect_identical(unname(result$imputed_mask[, "value"]), c(FALSE, FALSE, FALSE, TRUE))
})

test_that("character completion keeps character values rather than factor codes", {
  original <- data.frame(x = c("A", NA_character_, "B"), stringsAsFactors = FALSE)
  imputed <- data.frame(x = factor(c("A", "B", "B")))
  out <- build_completed(original, imputed, input_row_order = 1:3)$completed
  expect_identical(out$x, c("A", "B", "B"))
  expect_type(out$x, "character")
})

test_that("result summary exposes the shared output-role contract", {
  completed <- data.frame(x = c(1, 2), row.names = c("a", "b"))
  result <- structure(
    list(completed = completed,
         imputed_mask = matrix(c(FALSE, TRUE), ncol = 1,
                               dimnames = list(c("a", "b"), "x")),
         check = list(status = "ready", ready = TRUE),
         data = list(species_names = c("a", "b"),
                     trait_map = list(x = list(name = "x", type = "continuous"))),
         evaluation = NULL),
    class = "pigauto_result"
  )
  out <- summary(result)
  expect_s3_class(out, "summary_pigauto_result")
  expect_true(is.data.frame(out$output_roles))
  expect_true(any(out$output_roles$role == "completed"))
  expect_true(any(grepl("does not authorize inference", out$output_roles$text,
                        fixed = TRUE)))
})

test_that("summary partitions target cells into observed, filled, and unresolved", {
  completed <- data.frame(x = c(1, 9, NA_real_, NA_real_), species = c("a", "b", "c", "ghost"))
  mask <- matrix(c(FALSE, TRUE, FALSE, FALSE), ncol = 1, dimnames = list(NULL, "x"))
  check <- structure(list(species = list(species_col = "species", data_only = list(names = "ghost"))), class = c("pigauto_check", "list"))
  out <- summary(structure(list(completed = completed, imputed_mask = mask, check = check, evaluation = NULL), class = "pigauto_result"))
  expect_identical(out$counts, list(filled = 1L, observed = 1L, unresolved = 1L, not_modeled = 1L))
  expect_output(print(out), "observed cells.*1")
  expect_output(print(out), "inference=not authorized")
})

test_that("summary treats an attempted but missing fill as unresolved", {
  completed <- data.frame(x = c(1, NA_real_), row.names = c("a", "b"))
  mask <- matrix(c(FALSE, TRUE), ncol = 1, dimnames = list(c("a", "b"), "x"))
  out <- summary(structure(
    list(completed = completed, imputed_mask = mask, check = NULL, evaluation = NULL),
    class = "pigauto_result"
  ))
  expect_identical(out$counts, list(filled = 0L, observed = 1L, unresolved = 1L, not_modeled = 0L))
  expect_identical(out$per_trait$filled, 0L)
  expect_identical(sum(unlist(out$counts)), 2L)
})

test_that("print methods describe targeted cells and tree rows accurately", {
  data <- list(
    species_names = c("a", "b"),
    trait_map = list(x = list(name = "x", type = "continuous"))
  )
  mask <- matrix(c(FALSE, TRUE), ncol = 1, dimnames = list(c("a", "b"), "x"))
  completed <- data.frame(x = c(1, NA_real_))

  result <- structure(list(completed = completed, imputed_mask = mask,
                           check = NULL, evaluation = NULL, fit = NULL,
                           data = data), class = "pigauto_result")
  result_text <- paste(capture.output(print(result)), collapse = "\n")
  expect_match(result_text, "1 targeted / 2 total")
  expect_match(result_text, "Per-trait targeted cell counts")
  expect_false(grepl("imputed /", result_text, fixed = TRUE))

  mi <- structure(list(data = data, imputed_mask = mask,
                       draws_method = "conformal", m = 1L),
                  class = "pigauto_mi")
  mi_text <- paste(capture.output(print(mi)), collapse = "\n")
  expect_match(mi_text, "1 targeted / 2 total")
  expect_false(grepl("imputed /", mi_text, fixed = TRUE))

  tree_mi <- structure(
    list(n_trees = 2L, m_per_tree = 1L, m = 2L,
         datasets = list(data.frame(species = c("a", "a", "b"),
                                   x = c(1, NA_real_, 3))),
         species_col = "species",
         imputed_mask = matrix(c(FALSE, TRUE, FALSE), ncol = 1,
                               dimnames = list(NULL, "x")),
         draws_method = "mc_dropout"),
    class = "pigauto_mi_trees"
  )
  tree_text <- paste(capture.output(print(tree_mi)), collapse = "\n")
  expect_match(tree_text, "Rows\\s+: 3")
  expect_match(tree_text, "1 targeted / 3 total")
  expect_false(grepl("Species", tree_text, fixed = TRUE))
  expect_false(grepl("imputed /", tree_text, fixed = TRUE))
})

test_that("report contract handles legacy checks and escapes input messages", {
  result <- structure(list(completed = data.frame(x = 1),
                           check = list(status = "ready<script>",
                                        messages = data.frame(code = "<code>", field = "x",
                                                              text = "<unsafe>", action = "use 'x'",
                                                              severity = "warning"))),
                      class = "pigauto_result")
  html <- .report_contract_html(result$check, result)
  expect_match(html, "&lt;unsafe&gt;", fixed = TRUE)
  expect_false(grepl("<unsafe>", html, fixed = TRUE))
  expect_match(html, "How to use outputs", fixed = TRUE)
  expect_match(html, "A pigauto_result does not authorize inference", fixed = TRUE)
  expect_match(html, "multi_impute_analysis() only in its documented narrow route", fixed = TRUE)
  legacy <- .report_contract_html(NULL, NULL)
  expect_match(legacy, "Preflight check unavailable", fixed = TRUE)
})

test_that("get_imputed_datasets returns the stored datasets exactly", {
  d <- data.frame(x = c(1, 2), row.names = c("a", "b"))
  mi <- structure(list(datasets = list(d, d), m = 2L),
                  class = c("pigauto_diagnostic_mi", "pigauto_mi", "list"))
  expect_identical(get_imputed_datasets(mi), mi$datasets)
})

test_that("get_imputed_datasets accepts analysis and tree-sensitivity objects", {
  d <- data.frame(x = 1)
  analysis <- structure(list(datasets = list(d)),
                        class = c("pigauto_analysis_mi", "pigauto_mi", "list"))
  trees <- structure(list(datasets = list(d, d, d)),
                     class = c("pigauto_tree_sensitivity_diagnostic",
                               "pigauto_mi_trees", "pigauto_mi"))
  expect_identical(get_imputed_datasets(analysis), analysis$datasets)
  expect_identical(get_imputed_datasets(trees), trees$datasets)
})

test_that("get_imputed_datasets rejects non-mi inputs with guidance", {
  result <- structure(list(completed = data.frame(x = 1)),
                      class = "pigauto_result")
  expect_error(get_imputed_datasets(result), "completed_data")
  expect_error(get_imputed_datasets(result), "multi_impute")
  expect_error(get_imputed_datasets(list()), "pigauto_mi")
  expect_error(get_imputed_datasets(data.frame(x = 1)), "pigauto_mi")
})
