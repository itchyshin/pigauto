# tests/testthat/test-phylo-signal-gate.R
# Smoke canary for phylogenetic-signal gate.
# See specs/2026-04-23-phylo-signal-gate-design.md.

test_that("compute_phylo_signal_per_trait returns lambda for continuous traits", {
  skip_if_not_installed("phytools")
  set.seed(2026L)
  n <- 200L
  tree <- ape::rcoal(n)
  # Strong-signal trait: simulate under BM
  t_strong <- ape::rTraitCont(tree, model = "BM", sigma = 1)
  # Weak-signal trait: white noise
  t_weak   <- stats::rnorm(n)
  traits <- data.frame(strong = t_strong, weak = t_weak,
                        row.names = tree$tip.label)
  data_obj <- pigauto::preprocess_traits(traits, tree)
  lambdas <- pigauto:::compute_phylo_signal_per_trait(
    data = data_obj, tree = tree, method = "lambda")
  expect_type(lambdas, "double")
  expect_named(lambdas, c("strong", "weak"))
  expect_gt(as.numeric(lambdas["strong"]), 0.7)   # strong BM signal
  expect_lt(as.numeric(lambdas["weak"]),   0.3)   # weak/no signal
})

test_that("compute_phylo_signal_per_trait handles constant column as NA", {
  skip_if_not_installed("phytools")
  set.seed(1L)
  n <- 50L
  tree <- ape::rcoal(n)
  traits <- data.frame(const = rep(3.14, n),
                        row.names = tree$tip.label)
  data_obj <- pigauto::preprocess_traits(traits, tree)
  lambdas <- pigauto:::compute_phylo_signal_per_trait(
    data = data_obj, tree = tree, method = "lambda")
  expect_true(is.na(as.numeric(lambdas["const"])))
})

test_that("compute_phylo_signal_per_trait returns NA below min_tips", {
  skip_if_not_installed("phytools")
  set.seed(1L)
  tree <- ape::rcoal(15L)  # below default min_tips = 20
  traits <- data.frame(x = stats::rnorm(15L),
                        row.names = tree$tip.label)
  data_obj <- pigauto::preprocess_traits(traits, tree)
  lambdas <- pigauto:::compute_phylo_signal_per_trait(
    data = data_obj, tree = tree, method = "lambda", min_tips = 20L)
  expect_true(is.na(as.numeric(lambdas["x"])))
})

test_that("fit_pigauto(phylo_signal_gate = TRUE) stores phylo_signal slots", {
  skip_if_not_installed("phytools")
  skip_if_no_libtorch()
  data("avonet300", package = "pigauto")
  data("tree300",   package = "pigauto")
  df <- avonet300
  if ("Species_Key" %in% colnames(df)) {
    rownames(df) <- df$Species_Key; df$Species_Key <- NULL
  }
  set.seed(2026L)
  df$Mass[sample(300, 30)] <- NA_real_
  res <- pigauto::impute(df, tree300,
                           phylo_signal_gate = TRUE,
                           phylo_signal_threshold = 0.2,
                           safety_floor = TRUE,
                           epochs = 50L, n_imputations = 1L,
                           verbose = FALSE, seed = 2026L)
  fit <- res$fit
  expect_true(!is.null(fit$phylo_signal_per_trait))
  expect_true(!is.null(fit$phylo_gate_triggered))
  expect_equal(fit$phylo_signal_method, "lambda")
  expect_equal(fit$phylo_signal_threshold, 0.2)
  # AVONET traits all have strong phylogenetic signal; none should be gated
  expect_false(any(fit$phylo_gate_triggered, na.rm = TRUE))
})

test_that("fit_pigauto gates weak-signal traits to (0, 0, 1) exactly", {
  skip_if_not_installed("phytools")
  skip_if_no_libtorch()
  set.seed(2026L)
  n <- 200L
  tree <- ape::rcoal(n)
  # White-noise trait — lambda ~ 0
  traits <- data.frame(noise = stats::rnorm(n),
                        row.names = tree$tip.label)
  # Mask some cells
  traits$noise[sample(n, 30)] <- NA_real_
  res <- pigauto::impute(traits, tree,
                           phylo_signal_gate = TRUE,
                           phylo_signal_threshold = 0.2,
                           safety_floor = TRUE,
                           epochs = 30L, n_imputations = 1L,
                           verbose = FALSE, seed = 2026L)
  fit <- res$fit
  expect_true(isTRUE(as.logical(fit$phylo_gate_triggered["noise"])))
  # r_cal_bm = 0, r_cal_gnn = 0, r_cal_mean = 1 on the noise latent col
  expect_equal(as.numeric(fit$r_cal_bm["noise"]),   0, tolerance = 1e-10)
  expect_equal(as.numeric(fit$r_cal_gnn["noise"]),  0, tolerance = 1e-10)
  expect_equal(as.numeric(fit$r_cal_mean["noise"]), 1, tolerance = 1e-10)
})

test_that("phylo_signal_gate = TRUE is opt-in (default FALSE since 0.11.0.9002) and threads to fit", {
  expect_false(eval(formals(pigauto::impute)$phylo_signal_gate))
  expect_false(eval(formals(pigauto::fit_pigauto)$phylo_signal_gate))
  skip_if_not_installed("phytools")
  skip_if_no_libtorch()
  data("avonet300", package = "pigauto")
  data("tree300",   package = "pigauto")
  df <- avonet300
  if ("Species_Key" %in% colnames(df)) {
    rownames(df) <- df$Species_Key; df$Species_Key <- NULL
  }
  set.seed(2026L)
  df$Mass[sample(300, 30)] <- NA_real_
  # Explicit TRUE: the gate used to be the default; this still tests that path.
  r1 <- pigauto::impute(df, tree300, phylo_signal_gate = TRUE,
                          epochs = 30L, n_imputations = 1L,
                          verbose = FALSE, seed = 2026L)
  expect_equal(r1$fit$phylo_signal_method, "lambda")
  expect_false(all(is.na(r1$fit$phylo_signal_per_trait)))
  # The new default (no phylo_signal_gate argument) leaves the gate off.
  r0 <- pigauto::impute(df, tree300, epochs = 30L, n_imputations = 1L,
                          verbose = FALSE, seed = 2026L)
  expect_true(all(is.na(r0$fit$phylo_signal_per_trait)))
  r2 <- pigauto::impute(df, tree300, phylo_signal_gate = FALSE,
                          epochs = 30L, n_imputations = 1L,
                          verbose = FALSE, seed = 2026L)
  expect_true(all(is.na(r2$fit$phylo_signal_per_trait)))
  expect_false(any(r2$fit$phylo_gate_triggered, na.rm = TRUE))
})

test_that("print.pigauto_fit shows phylogenetic-signal section when gate triggered", {
  skip_if_not_installed("phytools")
  skip_if_no_libtorch()
  set.seed(2026L)
  n <- 200L
  tree <- ape::rcoal(n)
  traits <- data.frame(noise = stats::rnorm(n),
                        row.names = tree$tip.label)
  traits$noise[sample(n, 30)] <- NA_real_
  res <- pigauto::impute(traits, tree,
                           phylo_signal_gate = TRUE,
                           phylo_signal_threshold = 0.2,
                           epochs = 30L, n_imputations = 1L,
                           verbose = FALSE, seed = 2026L)
  out <- utils::capture.output(print(res$fit))
  expect_true(any(grepl("Phylogenetic signal", out)))
  expect_true(any(grepl("noise", out)))
  expect_true(any(grepl("gated", out, ignore.case = TRUE)))
})

test_that("plants smoke: BIEN plant traits with weak phylo signal are gated", {
  skip_if_not_installed("phytools")
  cache_trait <- "script/data-cache/bien_trait_means.rds"
  cache_tree  <- "script/data-cache/bien_tree.rds"
  if (!file.exists(cache_trait)) {
    repo_root <- Sys.getenv("PIGAUTO_REPO_ROOT",
                            unset = Sys.getenv("PIGAUTO_ROOT", unset = getwd()))
    cache_trait <- file.path(repo_root, "script/data-cache",
                             "bien_trait_means.rds")
    cache_tree  <- file.path(repo_root, "script/data-cache", "bien_tree.rds")
  }
  skip_if_not(file.exists(cache_trait) && file.exists(cache_tree),
              "BIEN cache not found")
  trait_means <- readRDS(cache_trait)
  tree_raw    <- readRDS(cache_tree)
  tree_all <- if (is.list(tree_raw) && !inherits(tree_raw, "phylo")) {
    t <- tree_raw$scenario.3
    t$tip.label <- gsub("_", " ", t$tip.label)
    t
  } else {
    tree_raw
  }
  all_species <- Reduce(union, lapply(trait_means,
    function(d) if (!is.null(d)) d$species else character(0)))
  wide <- data.frame(species = all_species, stringsAsFactors = FALSE)
  for (nm in names(trait_means)) {
    d <- trait_means[[nm]]
    if (is.null(d)) { wide[[nm]] <- NA_real_; next }
    val_col <- intersect(c("mean_value", "trait_value", "value"), names(d))[1]
    if (is.na(val_col)) { wide[[nm]] <- NA_real_; next }
    m <- match(wide$species, d$species)
    wide[[nm]] <- suppressWarnings(as.numeric(d[[val_col]][m]))
  }
  matched <- intersect(wide$species, tree_all$tip.label)
  skip_if_not(length(matched) >= 500L,
              "insufficient matched species")
  set.seed(100L)
  sp <- sample(matched, 500L)
  df <- wide[wide$species %in% sp, , drop = FALSE]
  rownames(df) <- df$species; df$species <- NULL
  tr <- ape::keep.tip(tree_all, sp)
  res <- pigauto::impute(df, tr,
                           phylo_signal_gate = TRUE,
                           phylo_signal_threshold = 0.2,
                           safety_floor = TRUE,
                           epochs = 40L, n_imputations = 5L,
                           verbose = FALSE, seed = 100L)
  fit <- res$fit
  gated <- fit$phylo_gate_triggered
  n_gated <- sum(gated, na.rm = TRUE)
  expect_gte(n_gated, 2L)
  gated_names <- names(gated)[gated & !is.na(gated)]
  gated_in_r_mean <- intersect(gated_names, names(fit$r_cal_mean))
  if (length(gated_in_r_mean) > 0L) {
    expect_true(all(fit$r_cal_mean[gated_in_r_mean] == 1))
  }
})
skip_if_no_libtorch()
