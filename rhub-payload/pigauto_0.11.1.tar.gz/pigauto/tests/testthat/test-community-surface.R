source_root_or_skip <- function(root = testthat::test_path("..", ".."),
                                require_source = identical(Sys.getenv("PIGAUTO_REQUIRE_SOURCE"), "true")) {
  source_files <- c("DESCRIPTION", "README.md", "R/active_impute.R",
                    "vignettes/getting-started.Rmd")
  if (!all(file.exists(file.path(root, source_files)))) {
    if (require_source) stop("Required source checkout files are missing", call. = FALSE)
    skip("source-surface assertions run in the dedicated repository gate")
  }
  root
}

test_that("source checks distinguish installed package layout from checkout", {
  root <- testthat::test_path("..", "..")
  installed <- tempfile("installed-pigauto-")
  dir.create(installed)
  writeLines("Package: pigauto", file.path(installed, "DESCRIPTION"))
  result <- tryCatch(source_root_or_skip(installed, require_source = FALSE), skip = identity)
  expect_s3_class(result, "skip")
  expect_error(source_root_or_skip(installed, require_source = TRUE),
               "source checkout")
  if (file.exists(file.path(root, "R", "active_impute.R"))) {
    expect_identical(source_root_or_skip(root), root)
  }
})

test_that("canonical novice journey is present in the public sources", {
  root <- source_root_or_skip()
  readme <- paste(readLines(file.path(root, "README.md"), warn = FALSE), collapse = "\n")
  getting <- paste(readLines(file.path(root, "vignettes", "getting-started.Rmd"), warn = FALSE), collapse = "\n")
  expect_true(all(vapply(c(
    "traits <- avonet300", "tree   <- tree300",
    'traits <- read_traits("traits.csv", species_col = "species")',
    'tree <- read_tree("tree.nwk")',
    'check_pigauto(traits, tree, species_col = "Species_Key")',
    'mi <- multi_impute(traits, tree, species_col = "Species_Key", m = 20)',
    "datasets <- get_imputed_datasets(mi)", "pigauto_report(mi$fit)"
  ), grepl, logical(1), x = readme, fixed = TRUE)), info = "README.md")
  expect_true(all(vapply(c(
    'traits <- read_traits("traits.csv", species_col = "species")',
    'tree <- read_tree("tree.nwk")', "check_pigauto(traits, tree)",
    "result <- impute(traits, tree, gnn = FALSE)",
    "completed <- completed_data(result)", "pigauto_report(result)"
  ), grepl, logical(1), x = getting, fixed = TRUE)), info = "getting-started.Rmd")
})

test_that("installed novice fixture and script parse without fitting", {
  traits_path <- system.file("extdata", "novice_traits.csv", package = "pigauto")
  tree_path <- system.file("extdata", "novice_tree.nwk", package = "pigauto")
  script_path <- system.file("examples", "novice-workflow.R", package = "pigauto")
  expect_true(file.exists(traits_path))
  expect_true(file.exists(tree_path))
  expect_true(file.exists(script_path))
  exprs <- parse(script_path)
  expect_length(exprs, 6L)
  expression_text <- vapply(exprs, function(x) paste(deparse(x), collapse = ""), character(1))
  expect_match(expression_text[[1L]], "^traits <- pigauto::read_traits\\(")
  expect_match(expression_text[[2L]], "^tree <- pigauto::read_tree\\(")
  expect_match(expression_text[[3L]], "^pigauto::check_pigauto\\(traits, tree\\)$")
  expect_match(expression_text[[4L]], "^result <- pigauto::impute\\(traits, tree\\)$")
  expect_match(expression_text[[5L]], "^completed <- pigauto::completed_data\\(result\\)$")
  expect_match(expression_text[[6L]], "^pigauto::pigauto_report\\(result\\)$")
  traits <- read_traits(traits_path)
  tree <- read_tree(tree_path)
  expect_s3_class(traits, "data.frame")
  expect_s3_class(tree, "phylo")
  expect_true(anyNA(traits))
  check <- check_pigauto(traits, tree)
  expect_true(check$status %in% c("ready", "ready_with_warnings"))
  expect_identical(check$traits$type[check$traits$trait == "mass"], "continuous")
  expect_false(any(check$messages$code == "integer_auto_ambiguous" &
                   check$messages$field == "mass"))
  expect_no_error(parse(text = 'traits$state <- ordered(traits$state, levels = c("low", "high"))'))
  expect_no_error(parse(text = 'trait_types = c(length_mm = "continuous", cover = "proportion", parasites = "zi_count")'))
  expect_no_error(parse(text = 'multi_proportion_groups = list(diet = c("diet_insect", "diet_fruit", "diet_seed"))'))
})

test_that("recipes, advanced controls, and bounded claims remain visible", {
  root <- source_root_or_skip()
  readme <- paste(readLines(file.path(root, "README.md"), warn = FALSE), collapse = "\n")
  getting <- paste(readLines(file.path(root, "vignettes", "getting-started.Rmd"), warn = FALSE), collapse = "\n")
  mixed <- paste(readLines(file.path(root, "vignettes", "mixed-types.Rmd"), warn = FALSE), collapse = "\n")
  expect_match(readme, "Ordered ecological states")
  expect_match(readme, "Integer-valued continuous")
  expect_match(readme, "Repeated species observations")
  expect_match(readme, "check\\$species")
  expect_match(readme, "## Advanced controls", fixed = TRUE)
  expect_match(readme, 'predict_method = "exact"', fixed = TRUE)
  expect_match(getting, "nominal held-out diagnostic", fixed = TRUE)
  expect_match(mixed, "multi_impute_analysis", fixed = TRUE)
  expect_false(grepl("maximally reduce imputation uncertainty|Why this is novel|certified coverage", readme, ignore.case = TRUE))
})

test_that("public preflight and result methods are indexed by pkgdown", {
  path <- testthat::test_path("..", "..", "_pkgdown.yml")
  if (!file.exists(path)) {
    skip("source-only pkgdown configuration is excluded from the package tarball")
  }
  pkgdown <- paste(readLines(path, warn = FALSE), collapse = "\n")
  for (topic in c("print.pigauto_check", "summary.pigauto_result",
                  "print.summary_pigauto_result")) {
    expect_match(pkgdown, paste0("- ", topic), fixed = TRUE)
  }
})

test_that("current public claim surfaces retain their stated boundaries", {
  root <- source_root_or_skip()
  read_text <- function(...) paste(readLines(file.path(root, ...), warn = FALSE), collapse = "\n")
  expect_false(grepl("ensures the network only|ensures improvement", read_text("DESCRIPTION"), ignore.case = TRUE))
  expect_false(grepl("maximise imputation precision|maximally reduce|Why this is novel|appears to be new", read_text("R", "active_impute.R"), ignore.case = TRUE))
  expect_false(grepl("0\\.14-1\\.27|lower z-RMSE|~13%", read_text("R", "fit_baseline.R")))
  expect_false(grepl("\\+6\\.6|will outperform|materially outperforms|typically helps|λ > 0\\.7", read_text("vignettes", "common-pitfalls.Rmd"), ignore.case = TRUE))
  expect_false(grepl("confirmed .* beats|z-RMSE 1\\.038|giving \\>= 95", read_text("vignettes", "gnn-architecture.Rmd"), ignore.case = TRUE))
  expect_match(read_text("R", "active_impute.R"), "These are model-based screening scores", fixed = TRUE)
  expect_match(read_text("R", "active_impute.R"), "field-sampling or downstream-analysis gains", fixed = TRUE)
  expect_match(read_text("vignettes", "getting-started.Rmd"), "nominal\\s+held-out diagnostics")
})

test_that("tree benchmark and interval help retain current boundaries", {
  root <- source_root_or_skip()
  read_text <- function(...) paste(readLines(file.path(root, ...), warn = FALSE), collapse = "\n")
  tree_vignette <- read_text("vignettes", "tree-uncertainty.Rmd")
  tree_plain <- gsub("[[:space:]]+", " ", tree_vignette)
  predict_source <- read_text("R", "predict_pigauto.R")
  predict_rd <- read_text("man", "predict.pigauto_fit.Rd")
  fit_source <- read_text("R", "fit_pigauto.R")
  fit_rd <- read_text("man", "fit_pigauto.Rd")

  pkgdown_path <- file.path(root, "_pkgdown.yml")
  if (file.exists(pkgdown_path)) {
    expect_false(grepl("dev/bench_tree_uncertainty\\.html", read_text("_pkgdown.yml")))
  }
  tombstone_path <- file.path(root, "pkgdown", "assets", "dev", "bench_tree_uncertainty.html")
  if (file.exists(tombstone_path)) {
    tombstone <- read_text("pkgdown", "assets", "dev", "bench_tree_uncertainty.html")
    expect_match(tombstone, "Historical tree-sensitivity benchmark", fixed = TRUE)
    expect_match(tombstone, "articles/tree-uncertainty.html", fixed = TRUE)
    expect_match(tombstone, "not MI, Rubin pooling, SE, or FMI", fixed = TRUE)
    expect_false(grepl("Pooled estimates|Rubin's rules", tombstone, fixed = TRUE))
  }
  expect_match(tree_vignette, "prediction-sensitivity diagnostic", fixed = TRUE)
  expect_match(tree_plain, "does not measure uncertainty in a downstream effect estimate", fixed = TRUE)
  expect_match(tree_vignette, "Do not use them for downstream inference", fixed = TRUE)
  expect_match(tree_vignette, "pass them to", fixed = TRUE)
  expect_match(tree_vignette, "`pool_mi()`", fixed = TRUE)

  for (text in list(predict_source, predict_rd)) {
    plain <- gsub("[[:space:]]+", " ", gsub("#' ?", "", text))
    expect_false(grepl("safe for interval arithmetic", plain, fixed = TRUE))
    expect_match(plain, "model-dependent BM/joint conditional SD", fixed = TRUE)
    expect_match(plain, "not total final blended-prediction uncertainty", fixed = TRUE)
  }
  for (text in list(fit_source, fit_rd)) {
    plain <- gsub("[[:space:]]+", " ", text)
    expect_false(grepl("\\b(near[- ]exact|guarantee[sd]?)\\b.{0,100}\\b(coverage|interval)", plain,
      ignore.case = TRUE, perl = TRUE
    ))
    expect_false(grepl("\\b(restore[sd]?|fix(?:es)?)\\b.{0,100}\\bexchangeability\\b", plain,
      ignore.case = TRUE, perl = TRUE
    ))
    expect_false(grepl("use this when.{0,100}\\b(coverage|interval)", plain,
      ignore.case = TRUE, perl = TRUE
    ))
    expect_false(grepl("\\b(coverage|interval).{0,80}\\b(SD|range|ranging|seed|simulation|benchmark)\\b|\\b(mean|empirical).{0,80}\\bcoverage\\b", plain,
      ignore.case = TRUE, perl = TRUE
    ))
    expect_match(plain, "nominal held-out diagnostic", fixed = TRUE)
    expect_match(plain, "does not certify package-wide coverage", fixed = TRUE)
    expect_match(plain, "cross_validate", fixed = TRUE)
  }
})

test_that("NEWS labels superseded public claims in their historical sections", {
  root <- source_root_or_skip()
  news <- paste(readLines(file.path(root, "NEWS.md"), warn = FALSE), collapse = "\n")
  news_plain <- gsub("[[:space:]]+", " ", news)
  forbidden_proximity <- paste(
    "bace_final_imp.{0,240}(proper multiple-imputation|Rubin \\(1987\\))",
    "PMM.{0,240}(pool_mi|Rubin|honest standard errors|properly calibrated SEs)",
    "tree uncertainty.{0,120}downstream standard errors.{0,120}Rubin",
    "pooled via Rubin's rules.{0,120}default path|Rubin's rules stable",
    sep = "|"
  )
  has_forbidden_proximity <- function(text) {
    grepl(forbidden_proximity, gsub("[[:space:]]+", " ", text),
      ignore.case = TRUE, perl = TRUE
    )
  }

  expect_false(grepl("net win-loss vs BACE|outperformed BACE|competitive with BACE|beating BACE|pigauto is uniquely positioned|Why this is novel|Coverage is guaranteed under exchangeability", news_plain, ignore.case = TRUE))
  expect_false(grepl("accuracy switch|0\\.14-1\\.27 z-RMSE", news_plain, ignore.case = TRUE))
  expect_false(grepl("Where PMM genuinely helps", news_plain, ignore.case = TRUE))
  expect_false(has_forbidden_proximity(news))
  expect_true(has_forbidden_proximity(
    "bace_final_imp() produces\nproper multiple-imputation draws for a historical route"
  ))
  expect_true(has_forbidden_proximity(
    "PMM draws can be passed to\npool_mi() for Rubin inference"
  ))
  expect_true(has_forbidden_proximity(
    "tree uncertainty can propagate into\ndownstream standard errors through Rubin pooling"
  ))
  expect_true(has_forbidden_proximity(
    "datasets are pooled via Rubin's rules\nand become the default path"
  ))
  expect_match(news, "Historical comparator snapshot — withdrawn as current evidence", fixed = TRUE)
  expect_match(news, "Historical rationale — novelty not established", fixed = TRUE)
  expect_match(news, "Historical tree workflow — now unsupported", fixed = TRUE)
  expect_match(news, "Historical conformal description — superseded", fixed = TRUE)
  expect_match(news, "external comparator gate remains open", fixed = TRUE)
  expect_match(news, "opt-in routing with fallback", fixed = TRUE)
  expect_match(news, "Historical BACE bridge note — removed and not inference-validated", fixed = TRUE)
  expect_match(news, "Historical PMM rationale — superseded", fixed = TRUE)
  expect_match(news, "multi_impute_analysis()", fixed = TRUE)
})

test_that("unsafe historical development tombstones are archived off the public site", {
  archive <- testthat::test_path("..", "..", "dev", "archive",
                                 "cran-011-public-pages")
  if (!dir.exists(archive)) {
    skip("source-only development archive is excluded from the package tarball")
  }
  names <- c(
    "bench_avonet9993_bace.html",
    "bench_avonet9993_bace_index.html",
    "bench_avonet9993_bace_n3000.html",
    "bench_bace_avonet_head_to_head.html",
    "bench_bien.html",
    "bench_fishbase.html",
    "bench_pantheria_bace_head_to_head.html",
    "calibration_grid.html",
    "pantheria_summary.html",
    "phase8_summary.html",
    "tests_overview.html"
  )
  paths <- file.path(archive, names)
  expect_true(all(file.exists(paths)))
  expect_false(any(file.exists(file.path(
    testthat::test_path("..", "..", "pkgdown", "assets", "dev"), names
  ))))
  pages <- vapply(paths, function(path) paste(readLines(path, warn = FALSE), collapse = "\n"), character(1))
  expect_true(all(grepl("Historical development page withdrawn", pages, fixed = TRUE)))
  expect_true(all(grepl("external-comparator gate remains open", pages, fixed = TRUE)))
  expect_false(any(grepl("theoretical guarantee|distribution-free uncertainty quantification remains valid|winner highlighted",
                         pages, ignore.case = TRUE)))
})
