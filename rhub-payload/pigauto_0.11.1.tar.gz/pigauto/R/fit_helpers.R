# R/fit_helpers.R
#
# Internal helpers extracted from fit_pigauto() to keep the training
# function below ~600 lines and each logical block independently readable.
# None of these functions are exported.

# ---------------------------------------------------------------------------
# make_covs_tensor()
# ---------------------------------------------------------------------------
#
# Concatenate the baseline-mean matrix (t_MU), the corruption/inference
# indicator (mask_ind), and any user-supplied covariates into the single
# covs tensor expected by ResidualPhyloDAE$forward().
#
# Signature:
#   covs_t = [t_MU | mask_ind | t_covariates]   (n_obs × (p + 1 + k))
#
# Called during the training loop (mask_ind = actual corruption mask) and
# during evaluation/calibration/test passes (mask_ind = zeros).
#
# @param t_MU         torch tensor (n_obs × p) — baseline mean predictions
# @param mask_ind     torch tensor (n_obs × 1) — 1 if cell was corrupted
# @param t_covariates torch tensor or NULL — user covariates (n_obs × k)
# @return torch tensor (n_obs × (p + 1 + k))
make_covs_tensor <- function(t_MU, mask_ind, t_covariates) {
  cov_parts <- list(t_MU, mask_ind)
  if (!is.null(t_covariates)) {
    cov_parts[[length(cov_parts) + 1L]] <- t_covariates
  }
  torch::torch_cat(cov_parts, dim = 2L)
}

# ---------------------------------------------------------------------------
# compute_corner_loss()
# ---------------------------------------------------------------------------
#
# Per-trait calibration-time loss of a candidate weight vector `g` on a
# set of validation rows.  Used by `calibrate_gates()` for both the
# half-A grid search and the post-calibration full-val invariant check.
#
# Extracted from a closure inside `calibrate_gates()` (2026-04-30) to
# (a) make the formula testable per trait type, and (b) eliminate the
# closure-capture footgun that previously hid a zi_count `mean_j`
# contamination bug across the gate and magnitude latent columns
# (Opus adversarial review, 2026-04-30).
#
# @param g                     numeric, length-1 (legacy) or length-3 (simplex
#                              `(r_BM, r_GNN, r_MEAN)`).
# @param rows                  integer, row indices into the val set.
# @param tm                    trait_map entry for this trait.
# @param mu_cal                numeric (n_obs x p_latent), baseline preds.
# @param delta_cal             numeric (n_obs x p_latent), GNN preds.
# @param fixed_cal             optional numeric (n_obs x p_latent), direct
#                              fixed-effect predictions to add outside the
#                              BM/GNN/MEAN blend.
# @param X_truth_r             numeric (n_obs x p_latent), ground truth (NA
#                              outside masked cells; finite at val rows).
# @param safety_floor          logical; when TRUE g is the simplex weight,
#                              when FALSE g is a scalar GNN weight.
# @param mean_baseline_per_col numeric (length p_latent) per-column grand
#                              mean on the latent scale; required when
#                              safety_floor = TRUE.  Each latent column
#                              has its OWN mean (gate logit and magnitude
#                              z-score for zi_count, K log-probs for
#                              categorical, etc.) -- callers must NOT
#                              substitute one column's mean for another.
# @return numeric scalar (Inf for zero-row, multi_proportion under
#         safety_floor, or unsupported types).
compute_corner_loss <- function(
  g,
  rows,
  tm,
  mu_cal,
  delta_cal,
  X_truth_r,
  safety_floor,
  mean_baseline_per_col = NULL,
  fixed_cal = NULL
) {
  if (length(rows) == 0L) {
    return(Inf)
  }
  lc <- tm$latent_cols
  fixed_mat <- if (is.null(fixed_cal)) {
    matrix(0, nrow = nrow(mu_cal), ncol = ncol(mu_cal))
  } else {
    if (!identical(dim(fixed_cal), dim(mu_cal))) {
      stop(
        "`fixed_cal` must have the same dimensions as `mu_cal`.",
        call. = FALSE
      )
    }
    fixed_cal
  }

  # Per-column latent blend.  When safety_floor = TRUE the caller passes
  # the column-specific mean explicitly via `mean_scalar`; the default
  # NA_real_ exists only for the safety_floor = FALSE branch where the
  # mean term is unused.
  blend1 <- function(x_bm, x_delta, mean_scalar = NA_real_) {
    if (safety_floor) {
      g[1] * x_bm + g[2] * x_delta + g[3] * mean_scalar
    } else {
      r_gnn <- if (length(g) == 1L) g else g[2L]
      (1 - r_gnn) * x_bm + r_gnn * x_delta
    }
  }

  if (tm$type %in% c("continuous", "count", "ordinal", "proportion")) {
    mean_j <- if (safety_floor) mean_baseline_per_col[lc[1]] else NA_real_
    pred_j <- fixed_mat[rows, lc[1]] +
      blend1(mu_cal[rows, lc[1]], delta_cal[rows, lc[1]], mean_j)
    mean((pred_j - X_truth_r[rows, lc[1]])^2)
  } else if (tm$type == "multi_proportion") {
    # multi_proportion NOT supported in safety_floor (requires per-component
    # mean vector; out of scope for this spec).
    if (safety_floor) {
      return(Inf)
    }
    r_gnn <- if (length(g) == 1L) g else g[2L]
    pred_mat <- fixed_mat[rows, lc, drop = FALSE] +
      (1 - r_gnn) * mu_cal[rows, lc, drop = FALSE] +
      r_gnn * delta_cal[rows, lc, drop = FALSE]
    truth_mat <- X_truth_r[rows, lc, drop = FALSE]
    mean((pred_mat - truth_mat)^2)
  } else if (tm$type == "binary") {
    mean_j <- if (safety_floor) mean_baseline_per_col[lc[1]] else NA_real_
    pred_j <- fixed_mat[rows, lc[1]] +
      blend1(mu_cal[rows, lc[1]], delta_cal[rows, lc[1]], mean_j)
    pred_class <- as.numeric(pred_j > 0)
    truth_j <- X_truth_r[rows, lc[1]]
    mean(pred_class != truth_j)
  } else if (tm$type == "categorical") {
    logits <- matrix(0, nrow = length(rows), ncol = length(lc))
    for (kk in seq_along(lc)) {
      mean_k <- if (safety_floor) mean_baseline_per_col[lc[kk]] else NA_real_
      logits[, kk] <- fixed_mat[rows, lc[kk]] +
        blend1(
          mu_cal[rows, lc[kk]],
          delta_cal[rows, lc[kk]],
          mean_scalar = mean_k
        )
    }
    pred_class <- max.col(logits, ties.method = "first")
    truth_mat <- X_truth_r[rows, lc, drop = FALSE]
    truth_class <- max.col(truth_mat, ties.method = "first")
    mean(pred_class != truth_class)
  } else if (tm$type == "zi_count") {
    # Gate column (lc[1], logit-scale) and magnitude column (lc[2],
    # z-scored log1p) have DIFFERENT mean baselines.  The pre-2026-04-30
    # closure version of this branch used a single
    # `mean_j = mean_baseline_per_col[lc[1]]` for both blend calls, which
    # contaminated the magnitude formula's pure-MEAN corner with the
    # gate's logit value.  Fixed here per the Opus adversarial review of
    # 2026-04-30.  Each column now uses its own column mean.
    mean_gate <- if (safety_floor) mean_baseline_per_col[lc[1]] else NA_real_
    mean_mag <- if (safety_floor) mean_baseline_per_col[lc[2]] else NA_real_
    gate_pred <- fixed_mat[rows, lc[1]] +
      blend1(mu_cal[rows, lc[1]], delta_cal[rows, lc[1]], mean_gate)
    mag_pred <- fixed_mat[rows, lc[2]] +
      blend1(mu_cal[rows, lc[2]], delta_cal[rows, lc[2]], mean_mag)
    p_nz <- expit(gate_pred)
    count_hat <- pmax(expm1(mag_pred * tm$sd + tm$mean), 0)
    pred_ev <- p_nz * count_hat
    truth_gate <- X_truth_r[rows, lc[1]]
    truth_mag <- X_truth_r[rows, lc[2]]
    truth_ev <- rep(0, length(rows))
    nz <- which(truth_gate > 0.5 & is.finite(truth_mag))
    truth_ev[nz] <- expm1(truth_mag[nz] * tm$sd + tm$mean)
    mean((pred_ev - truth_ev)^2)
  } else {
    Inf
  }
}

# ---------------------------------------------------------------------------
# calibrate_gates()
# ---------------------------------------------------------------------------
#
# Post-training per-trait gate calibration on a held-out validation set.
#
# Uses a 9-point grid search with a half-A / half-B split-validation
# cross-check to prevent the GNN from degrading traits the BM baseline
# already handles well.  For discrete traits the calibration metric is
# 0-1 loss (not cross-entropy) so the val signal matches the test metric.
#
# The gate is accepted only if the improvement passes BOTH a relative-gain
# floor (cal_min_rel_gain) AND, for discrete traits, an absolute cell-level
# floor (2 correctly-flipped cells on half A, 1 on half B).
#
# @param trait_map        list of trait descriptors from preprocess_traits()
# @param mu_cal           numeric matrix (n_obs × p) — baseline predictions
# @param delta_cal        numeric matrix (n_obs × p) — GNN predictions
# @param fixed_cal        optional numeric matrix (n_obs × p) — fixed-effect
#                         predictions added outside the blend.
# @param X_truth_r        numeric matrix (n_obs × p) — original data with NAs
# @param val_mask_mat     logical matrix (n_obs × p) — TRUE = validation cell
# @param gate_grid        numeric vector — candidate gate values (9-pt grid)
# @param gate_cap         numeric scalar — maximum allowed gate value
# @param cal_min_rel_gain numeric — minimum relative improvement (default 0.02)
# @param seed             integer — random seed for half-split (seed + 17L)
# @param latent_names     character vector or NULL — for verbose output
# @param verbose          logical
# @return named numeric vector of length p; values in [0, gate_cap]
calibrate_gates <- function(trait_map, mu_cal, delta_cal,
                            X_truth_r, val_mask_mat,
                            gate_grid, gate_cap,
                            cal_min_rel_gain = 0.02,
                            gate_method = c("single_split", "median_splits",
                                             "cv_folds"),
                            gate_splits_B = 31L,
                            gate_cv_folds = 5L,
                            safety_floor = FALSE,
                            mean_baseline_per_col = NULL,
                            simplex_step = 0.05,
                            min_val_cells = 10L,
                            seed = NULL,
                            latent_names = NULL,
                            verbose = FALSE,
                            fixed_cal = NULL) {
  gate_method <- match.arg(gate_method)
  if (gate_method == "cv_folds") {
    if (
      !is.numeric(gate_cv_folds) ||
        length(gate_cv_folds) != 1L ||
        !is.finite(gate_cv_folds) ||
        gate_cv_folds < 2L ||
        gate_cv_folds != as.integer(gate_cv_folds)
    ) {
      stop(
        "'gate_cv_folds' must be a single integer >= 2 when ",
        "gate_method = 'cv_folds'",
        call. = FALSE
      )
    }
    gate_cv_folds <- as.integer(gate_cv_folds)
  }
  if (safety_floor) {
    if (is.null(mean_baseline_per_col)) {
      stop(
        "safety_floor = TRUE requires mean_baseline_per_col (numeric, length = ncol(mu_cal))"
      )
    }
    stopifnot(length(mean_baseline_per_col) == ncol(mu_cal))
    simplex <- simplex_grid(step = simplex_step)
  } else {
    simplex <- NULL
  }
  p <- ncol(mu_cal)
  calibrated_gates <- numeric(p)
  r_cal_bm_vec <- numeric(p)
  r_cal_gnn_vec <- numeric(p)
  r_cal_mean_vec <- numeric(p)
  low_val_traits <- character(0)
  low_val_n <- integer(0)
  conf_unreachable_traits <- character(0)

  for (tm in trait_map) {
    lc <- tm$latent_cols

    # Restrict to validation rows that have finite truth values
    val_cells <- val_mask_mat[, lc[1]]
    if (length(lc) > 1L) {
      truth_ok <- rowSums(is.na(X_truth_r[, lc, drop = FALSE])) == 0L
    } else {
      truth_ok <- !is.na(X_truth_r[, lc[1]])
    }
    val_cells <- val_cells & truth_ok
    val_row_idx <- which(val_cells)
    n_val <- length(val_row_idx)

    if (n_val == 0) {
      calibrated_gates[lc] <- 0
      r_cal_bm_vec[lc] <- 1 # pure BM fallback
      r_cal_gnn_vec[lc] <- 0
      r_cal_mean_vec[lc] <- 0
      next
    }

    if (n_val < min_val_cells) {
      low_val_traits <- c(low_val_traits, sprintf("%s (n=%d)", tm$name, n_val))
      low_val_n <- c(low_val_n, n_val)
    }
    # Independent of min_val_cells: split-conformal's achievable coverage
    # ceiling is n_val / (n_val + 1) (the largest quantile level <= 1
    # reachable with n_val residuals). That ceiling is < 0.95 whenever
    # n_val < 19, so below 19 val cells the 95% target is not merely
    # "noisy" -- it is arithmetically unreachable, regardless of model
    # quality. Conformal scores are only computed for non-discrete types.
    if (n_val < 19L && !tm$type %in% c("binary", "categorical")) {
      conf_unreachable_traits <- c(conf_unreachable_traits,
                                   sprintf("%s (n=%d)", tm$name, n_val))
    }

    # ------------------------------------------------------------------
    # Select the half-A / half-B split(s) used for grid search.
    #
    # "single_split" (default, backward-compat): one deterministic split
    # keyed off `seed + 17L`. Fast; unstable when n_val is small (e.g.
    # 7 val cells -> 3-4 in half_a -> gate picks are essentially random
    # between 0 and the max grid value).
    #
    # "median_splits": repeat the whole grid + half-B-verify procedure
    # for each of `gate_splits_B` random splits, take the MEDIAN gate
    # across the B runs. Shrinks the bimodal-gate flip-flop observed at
    # small n_val without any retraining. Default B = 31 gives a cheap
    # variance reduction and is odd so the median is well-defined.
    #
    # "cv_folds" (2026-04-30, NEW): partition val cells into K=`gate_cv_folds`
    # deterministic non-overlapping folds; each fold becomes the "held-out"
    # set (half_b) while the union of the other K-1 folds is the "training"
    # set (half_a).  Run the grid + half-B-verify procedure K times, take
    # the componentwise MEDIAN of K winning weight vectors as w_final.
    # Compared to median_splits: uses larger half_a per split (4/5 vs 1/2),
    # has non-overlapping splits, and has a standard cross-validation
    # interpretation.  Falls back to single_split when n_val < 2 (CV ill-
    # defined).  Edge: when n_val < gate_cv_folds we cap K_eff = n_val
    # so each fold has at least 1 cell.
    # ------------------------------------------------------------------
    split_seeds <- if (gate_method == "single_split") {
      if (is.null(seed)) list(NULL) else (seed + 17L)
    } else {
      if (is.null(seed)) rep(list(NULL), gate_splits_B) else
        as.integer(seed + 17L + seq_len(gate_splits_B) - 1L)
    }

    resolve_best_g_one_split <- function(ss) {
      if (!is.null(ss)) set.seed(ss)
      perm_i <- sample(n_val)
      half_a_i <- val_row_idx[perm_i[seq_len(floor(n_val / 2))]]
      half_b_i <- val_row_idx[perm_i[(floor(n_val / 2) + 1L):n_val]]
      if (length(half_a_i) == 0L || length(half_b_i) == 0L) {
        half_a_i <- val_row_idx
        half_b_i <- val_row_idx
      }
      list(half_a = half_a_i, half_b = half_b_i)
    }

    split_pairs <- if (gate_method != "cv_folds") {
      lapply(split_seeds, resolve_best_g_one_split)
    } else {
      K_eff <- min(gate_cv_folds, n_val)
      if (K_eff < 2L) {
        # CV ill-defined at n_val < 2; fall back to a single split.
        list(resolve_best_g_one_split(if (is.null(seed)) NULL else seed + 17L))
      } else {
        if (!is.null(seed)) set.seed(seed + 17L)
        # rep(seq_len(K_eff), length.out = n_val) gives a balanced fold
        # assignment (within +/- 1 cell across folds); sample() randomises
        # which val_row gets which fold id, fixed by the seed above.
        fold_id <- sample(rep(seq_len(K_eff), length.out = n_val))
        lapply(seq_len(K_eff), function(k) {
          train_local <- val_row_idx[fold_id != k]
          held_out <- val_row_idx[fold_id == k]
          if (length(train_local) == 0L) {
            train_local <- val_row_idx
          }
          if (length(held_out) == 0L) {
            held_out <- val_row_idx
          }
          list(half_a = train_local, half_b = held_out)
        })
      }
    }

    # Helper: mean loss for gate g on a set of row indices, closing over
    # the trait-loop variables (lc, tm, mu_cal, delta_cal, X_truth_r,
    # safety_floor, mean_baseline_per_col) and forwarding to the
    # standalone `compute_corner_loss()` function below.  The closure
    # exists to preserve the original two-arg call signature in the
    # half-A/half-B grid search and post-calibration check.
    cal_mean_loss <- function(g, rows) {
      compute_corner_loss(
        g,
        rows,
        tm,
        mu_cal,
        delta_cal,
        X_truth_r,
        safety_floor = safety_floor,
        mean_baseline_per_col = mean_baseline_per_col,
        fixed_cal = fixed_cal
      )
    }

    # Absolute minimum cell-level improvement floor for discrete traits
    # (relative gains on 0-1 loss are small: a 2% relative gain over 0.35
    # baseline is only ~0.007, easily noise on small val sets).
    is_discrete <- tm$type %in% c("binary", "categorical")

    # Inner: grid search on half_a + half_b verification, returns best weight vector.
    resolve_one_split <- function(ha, hb) {
      min_abs_a <- if (is_discrete) 2 / max(length(ha), 1L) else 0
      min_abs_b <- if (is_discrete) 1 / max(length(hb), 1L) else 0

      # Candidate grid is 3-column: for safety_floor use the simplex,
      # for legacy 1-D use the scalar gate_grid promoted to (1-g, g, 0).
      cand_grid <- if (safety_floor) {
        simplex
      } else {
        matrix(
          c(1 - gate_grid, gate_grid, rep(0, length(gate_grid))),
          ncol = 3L,
          dimnames = list(NULL, c("r_bm", "r_gnn", "r_mean"))
        )
      }

      # "Pure BM" reference: (1,0,0) in simplex form when safety_floor = TRUE;
      # scalar 0 (i.e. g=0, no GNN) in legacy form when safety_floor = FALSE.
      # Both cal_mean_loss calls use the same dispatch path so no recycling occurs.
      ref_w <- if (safety_floor) c(1, 0, 0) else 0
      loss_a_pure_bm <- cal_mean_loss(ref_w, ha)
      best_w <- ref_w
      # Defensive: if loss_a_pure_bm is non-finite (e.g. multi_proportion
      # CLR latents with too few half-A cells for some component), seed
      # best_la with Inf so any finite candidate la beats it.  Same NA-
      # safety pattern as the half-B fix in commit 573decd.  Without
      # this, `la < best_la` errors with "missing value where TRUE/FALSE
      # needed" when best_la is NA.
      best_la <- if (is.finite(loss_a_pure_bm)) loss_a_pure_bm else Inf
      pure_bm_is_finite <- is.finite(loss_a_pure_bm)
      for (ci in seq_len(nrow(cand_grid))) {
        w_try <- cand_grid[ci, ]
        la <- cal_mean_loss(w_try, ha)
        if (!is.finite(la)) {
          next
        }
        if (!safety_floor) {
          # Legacy half-A filter (bit-identical to Task 3): skip candidates
          # that do not beat pure-BM by cal_min_rel_gain AND min_abs_a.
          r_gnn_try <- w_try[2L]
          if (r_gnn_try == 0) {
            next
          }
          # If pure-BM loss is non-finite, the legacy filter cannot
          # evaluate; admit the candidate (the half-B verification step
          # is the safety net).
          if (pure_bm_is_finite) {
            rel <- (loss_a_pure_bm - la) / max(loss_a_pure_bm, 1e-12)
            abs_gain <- loss_a_pure_bm - la
            if (rel < cal_min_rel_gain || abs_gain < min_abs_a) next
          }
        }
        if (la < best_la) {
          best_la <- la
          best_w <- w_try
        }
      }

      # Half-B verification: require the winning w's half-B loss to also
      # beat the pure-BM half-B loss by cal_min_rel_gain (legacy: /2) AND
      # by the discrete absolute cell floor.
      loss_b_pure_bm <- cal_mean_loss(ref_w, hb)
      loss_b_best <- cal_mean_loss(best_w, hb)
      rel_gain_b <- (loss_b_pure_bm - loss_b_best) / max(loss_b_pure_bm, 1e-12)
      abs_gain_b <- loss_b_pure_bm - loss_b_best
      rel_gain_threshold <- if (safety_floor) {
        cal_min_rel_gain
      } else {
        cal_min_rel_gain / 2
      }
      # Defensive: if either half-B loss is NA (e.g. a multi_proportion CLR
      # column with too few cells in half-B for some component), the gain
      # cannot be evaluated.  Treat as "verification failed" -> fall back
      # to the safe reference, preserving the safety guarantee.
      verification_failed <-
        !is.finite(rel_gain_b) ||
        rel_gain_b < rel_gain_threshold ||
        (is_discrete && (!is.finite(abs_gain_b) || abs_gain_b < min_abs_b))
      if (verification_failed) {
        # Revert to best safe fallback.  When safety_floor = TRUE the pure-mean
        # point (0,0,1) is always a valid option — pick whichever of BM and mean
        # is better on half-B so the safety guarantee is preserved.
        if (safety_floor) {
          mean_ref_w <- c(0, 0, 1)
          loss_b_mean <- cal_mean_loss(mean_ref_w, hb)
          # If either loss is NA, prefer the BM ref (safer than mean
          # for continuous-like latents); otherwise pick whichever is
          # smaller on half-B.
          best_w <- if (is.finite(loss_b_mean) && is.finite(loss_b_pure_bm)) {
            if (loss_b_mean <= loss_b_pure_bm) mean_ref_w else ref_w
          } else {
            ref_w
          }
        } else {
          best_w <- ref_w
        }
      }

      # Always return a length-3 vector so vapply(., numeric(3L)) works uniformly.
      if (length(best_w) == 1L) c(1 - best_w, best_w, 0) else best_w
    }

    best_w_across_splits <- vapply(
      split_pairs,
      function(pair) {
        resolve_one_split(pair$half_a, pair$half_b)
      },
      numeric(3L)
    ) # 3 rows x B cols
    w_final <- apply(best_w_across_splits, 1L, stats::median)
    # Guard against degenerate median = c(0, 0, 0), which can occur when
    # adversarial splits alternate between corners (e.g. >50% of splits pick
    # (1,0,0), >50% pick (0,0,1), and each coordinate's median is 0). Pure-mean
    # (0,0,1) is the safe fallback matching the invariant guarantee.
    if (!is.finite(sum(w_final)) || sum(w_final) < 1e-10) {
      w_final <- if (safety_floor) c(0, 0, 1) else c(1, 0, 0)
    } else {
      w_final <- w_final / sum(w_final) # renormalise (medians don't preserve sum)
    }

    # ---- Post-calibration full-val invariant check ------------------
    # Single dispatcher (refactored 2026-04-30 per Opus adversarial
    # review #5; unified both-corners check 2026-08-15 per issue #157).
    # All families route through the shared `compute_corner_loss()`
    # helper via the `cal_mean_loss` closure.  The asymmetry between
    # trait families is captured in a per-family POLICY:
    #
    #   continuous family (continuous / count / ordinal / proportion):
    #     override if blend loses to pure-MEAN on the full val set
    #     (strict at float tolerance), OR loses to pure-BM by MORE
    #     than a relative margin (cal_min_rel_gain / 2, default 1%).
    #     The margin exists because a STRICT pure-BM check is too
    #     sensitive to sampling noise at typical val sizes — in the
    #     2026-04-29 AVONET Mass over-correction (commit 1ac34b1)
    #     blend's val MSE was numerically equal to pure-BM's on a
    #     450-cell val set yet blend was meaningfully better on test.
    #     Issue #157 is the opposite regime: a gate accepted from
    #     half-set comparisons (or a half-B fallback corner) can be
    #     MATERIALLY worse than pure BM on the full val set (+2.1%
    #     measured), and pre-#157 no check caught it for this family.
    #     The margin separates the regimes: near-ties survive, material
    #     losses close the gate.
    #
    #   discrete family (binary / categorical / zi_count):
    #     override if blend loses to EITHER pure-BM or pure-MEAN on the
    #     full val set, strict at float tolerance.  Discrete 0-1 /
    #     argmax losses are step functions on a small set, so the
    #     strict-tie comparison is well-conditioned even at typical
    #     val sizes (val→test extrapolation noise survives, but is at
    #     most a few cell-flips per trait).
    #
    #   Override target (both families): whichever pure corner has
    #   lower full-val loss; BM wins ties over MEAN (`lm_bm <= lm_mean`).
    #
    #   multi_proportion: skipped entirely.  cal_mean_loss returns Inf
    #     under safety_floor = TRUE for this type by design (no
    #     per-component mean vector); the legacy gate-naturally-closes
    #     path produces pigauto = baseline at every signal level.
    #
    # Tie semantics (lb ≤ corner + 1e-12, or within the continuous
    # margin): blend wins.  The `1e-12` is a numerical floor against
    # floating-point drift, not a meaningful tolerance — typical loss
    # scales (0.07 for 0-1 discrete, 0.3 for z-scored MSE, ~1000 for
    # zi_count count^2 MSE) are all >> 1e-12.  This enforces the
    # invariant on the PRE-REFINE calibration surface (fixed delta_cal,
    # val/test cells hidden).  A second, identical margin floor runs in
    # `fit_pigauto()` on the POST-refine calibrated surface (the one
    # `predict()` delivers) after the conformal re-refine — see the
    # "Post-refine delivered-surface floor (issue #157)" block there.
    # The Task 12 invariant test evaluates on the calibration-matched
    # surface (`.mask_observed_idx`, issue #157) and keeps its `* 1.05`
    # slack for residual refine drift.
    is_continuous_family <-
      tm$type %in% c("continuous", "count", "ordinal", "proportion")
    is_discrete_family <-
      tm$type %in% c("binary", "categorical", "zi_count")
    if (
      length(val_row_idx) > 0L &&
        (is_continuous_family || is_discrete_family) &&
        # multi_proportion has tm$type "multi_proportion" and falls
        # outside both family flags, so it is skipped.
        TRUE
    ) {
      coerce_loss <- function(x) if (is.finite(x)) x else Inf
      lb <- coerce_loss(cal_mean_loss(w_final, val_row_idx))
      lm_mean <- if (safety_floor) {
        coerce_loss(cal_mean_loss(c(0, 0, 1), val_row_idx))
      } else {
        Inf
      }
      tol <- 1e-12

      # BM is always a valid corner; MEAN only when safety_floor = TRUE
      # (legacy path's `cal_mean_loss` is undefined for the (0,0,1)
      # gate).
      bm_corner <- if (safety_floor) c(1, 0, 0) else 0
      lm_bm <- coerce_loss(cal_mean_loss(bm_corner, val_row_idx))
      # Continuous-family BM comparison is margin-based (see POLICY
      # above, issue #157); discrete stays strict at float tolerance.
      bm_threshold <- if (is_continuous_family) {
        lm_bm * (1 + cal_min_rel_gain / 2)
      } else {
        lm_bm + tol
      }
      if (lb > bm_threshold || lb > lm_mean + tol) {
        # On ties, BM wins via `<=`.
        w_final <- if (lm_bm <= lm_mean) c(1, 0, 0) else c(0, 0, 1)
      }
    }

    calibrated_gates[lc] <- w_final[2] # legacy scalar = r_gnn
    r_cal_bm_vec[lc] <- w_final[1]
    r_cal_gnn_vec[lc] <- w_final[2]
    r_cal_mean_vec[lc] <- w_final[3]
  }

  if (verbose) {
    gate_summary <- round(calibrated_gates, 3)
    names(gate_summary) <- if (!is.null(latent_names)) {
      latent_names
    } else {
      paste0("col", seq_len(p))
    }
    message(
      "Calibrated gates: ",
      paste(names(gate_summary), gate_summary, sep = "=", collapse = ", ")
    )
  }

  # Small-val warning: if any trait had fewer than `min_val_cells`
  # validation cells, the gate calibration AND the conformal score will
  # be noisy for that trait. Users see under-/over-coverage in that
  # regime; surface this up-front so they know to (a) increase the
  # fraction of held-out data, (b) use gate_method = "median_splits" +
  # conformal_method = "bootstrap" to smooth the per-split variance,
  # or (c) accept that intervals are approximate.
  if (length(low_val_traits) > 0L || length(conf_unreachable_traits) > 0L) {
    warning(
      if (length(low_val_traits) > 0L) {
        paste0(
          "Small validation set for ", length(low_val_traits),
          " trait(s): ", paste(low_val_traits, collapse = ", "),
          ". Calibrated gate and conformal scores will be noisy for ",
          "these trait(s). "
        )
      } else {
        ""
      },
      if (length(conf_unreachable_traits) > 0L) {
        paste0(
          "95% split-conformal coverage is NOT achievable for ",
          length(conf_unreachable_traits), " trait(s) with fewer than 19 ",
          "validation cells (", paste(conf_unreachable_traits,
                                      collapse = ", "),
          "): the achievable ceiling is n_val / (n_val + 1), which only ",
          "reaches 0.95 at n_val >= 19. "
        )
      } else {
        ""
      },
      "See `?fit_pigauto` under 'Calibration at small n' for ",
      "smoothing options.",
      call. = FALSE
    )
  }

  if (!is.null(latent_names)) {
    if (length(latent_names) == length(calibrated_gates)) {
      names(calibrated_gates) <- latent_names
    }
    if (length(latent_names) == length(r_cal_bm_vec)) {
      names(r_cal_bm_vec) <- latent_names
      names(r_cal_gnn_vec) <- latent_names
      names(r_cal_mean_vec) <- latent_names
    }
  }
  list(
    r_cal_bm = r_cal_bm_vec,
    r_cal_gnn = r_cal_gnn_vec,
    r_cal_mean = r_cal_mean_vec
  )
}

# ---------------------------------------------------------------------------
# compute_conformal_scores()
# ---------------------------------------------------------------------------
#
# Compute per-trait conformal prediction scores from validation residuals.
#
# Produces the (1 - alpha) conformal quantile of |truth - pred| on held-out
# validation cells for continuous, count, ordinal, proportion, and zi_count
# (magnitude / log1p-z column only; the gate is discrete). Used at prediction
# time to construct marginal conformal intervals and as the MI draw width.
#
# Three estimators are supported:
#
# - `"split"` (default, backward compat): the classical Vovk conformal
#   quantile at level `ceil((1 - alpha)(n + 1))/n` on the val residuals.
#   Fast, exact finite-sample coverage guarantee under exchangeability,
#   but extremely noisy when `n_val` is small (~10 cells): at `n_val = 7`
#   the estimator is essentially `max(residuals)`, and a single seed
#   reshuffle can move it by an order of magnitude.
#
# - `"bootstrap"` (new): compute `B` bootstrap resamples of the val
#   residuals, take the split-conformal quantile on each resample, then
#   average (mean). This reduces the score's Monte-Carlo variance ~√B×
#   at the cost of a single `B`-sample loop per trait.  It loses the
#   exact exchangeability guarantee from split conformal but stays in the
#   same asymptotic regime.  Recommended when `n_val` per trait is < 30.
#
# - `"mondrian"` (B2, 2026-08-16): stratified conformal that conditions on
#   phylogenetic sampling locality, fixing the exchangeability failure
#   documented in `docs/dev-log/2026-08-16-mechanism-coverage-results.md`
#   (split conformal calibrates on the observed complement, which is
#   systematically closer to other observed cells than genuinely-missing
#   cells are -- worst under clade-structured (MAR_phylo) missingness).
#   For each val cell, a locality statistic is the mean cophenetic
#   distance to its 5 nearest species with an OBSERVED (non-NA,
#   non-split-masked) value for that trait (`obs_mask_mat`, `D_sq`). Val
#   cells are split into two strata at the median locality and a
#   split-conformal quantile is computed within each stratum at the same
#   adjusted level. If either stratum has fewer than 19 residuals (the coverage-ceiling minimum), the
#   trait falls back to the global `"split"` score (recorded in the
#   `"mondrian"` attribute's `fallback` flag). Per-trait near/far scores
#   and the stratification threshold are returned via
#   `attr(., "mondrian")`; the base named-vector value stays the global
#   split score so callers that ignore the attribute keep a sane single
#   number. Single-obs only -- see the `multi_obs` guard in
#   `fit_pigauto()`.
#
# @param trait_map         list of trait descriptors
# @param calibrated_gates  named numeric vector (length p), legacy GNN gate
#                           used when three-way calibration weights are NULL.
# @param mu_cal            numeric matrix (n × p) — baseline predictions
# @param delta_cal         numeric matrix (n × p) — GNN predictions
# @param r_cal_bm          optional numeric vector (length p), BM weights.
# @param r_cal_gnn         optional numeric vector (length p), GNN weights.
# @param r_cal_mean        optional numeric vector (length p), MEAN weights.
# @param mean_baseline_per_col optional numeric vector (length p), MEAN corner.
# @param fixed_cal         optional numeric matrix (n × p), direct
#                          fixed-effect predictions added outside the blend.
# @param X_truth_r         numeric matrix (n × p) — truth with NAs
# @param val_mask_mat      logical matrix (n × p) — TRUE = validation cell
# @param alpha             numeric — miscoverage level; default 0.05 (→ 95%)
# @param method            `"split"`, `"bootstrap"`, or `"mondrian"`
# @param bootstrap_B       integer — bootstrap resamples when `method = "bootstrap"`
# @param D_sq              numeric matrix (n_species × n_species), squared
#                          cophenetic distances (`build_phylo_graph()$D_sq`).
#                          Required when `method = "mondrian"`.
# @param obs_mask_mat      logical matrix (n × p) — TRUE = observed AND used
#                          for training (i.e. not held out for val/test).
#                          Required when `method = "mondrian"`.
# @param k_locality         integer — nearest-observed-species count for the
#                          Mondrian locality statistic (default 5).
# @param verbose           logical
# @return named numeric vector; NA for binary/categorical or empty val sets.
#   zi_count scores are on the magnitude (log1p-z) latent, not E[X]. When
#   `method = "mondrian"`, carries an additional `"mondrian"` attribute
#   (see above).
compute_conformal_scores <- function(
  trait_map,
  calibrated_gates,
  mu_cal,
  delta_cal,
  X_truth_r,
  val_mask_mat,
  alpha = 0.05,
  method = c("split", "bootstrap", "mondrian"),
  bootstrap_B = 500L,
  D_sq = NULL,
  obs_mask_mat = NULL,
  k_locality = 5L,
  verbose = FALSE,
  r_cal_bm = NULL,
  r_cal_gnn = NULL,
  r_cal_mean = NULL,
  mean_baseline_per_col = NULL,
  fixed_cal = NULL
) {
  method <- match.arg(method)
  if (method == "mondrian" && (is.null(D_sq) || is.null(obs_mask_mat))) {
    stop(
      "`D_sq` and `obs_mask_mat` are required when method = \"mondrian\".",
      call. = FALSE
    )
  }
  p <- ncol(mu_cal)
  n <- nrow(mu_cal)

  if (!identical(dim(delta_cal), dim(mu_cal))) {
    stop(
      "`delta_cal` must have the same dimensions as `mu_cal`.",
      call. = FALSE
    )
  }
  if (!identical(dim(X_truth_r), dim(mu_cal))) {
    stop(
      "`X_truth_r` must have the same dimensions as `mu_cal`.",
      call. = FALSE
    )
  }
  if (!identical(dim(val_mask_mat), dim(mu_cal))) {
    stop(
      "`val_mask_mat` must have the same dimensions as `mu_cal`.",
      call. = FALSE
    )
  }

  fixed_mat <- if (is.null(fixed_cal)) {
    matrix(0, nrow = n, ncol = p)
  } else {
    if (!identical(dim(fixed_cal), dim(mu_cal))) {
      stop(
        "`fixed_cal` must have the same dimensions as `mu_cal`.",
        call. = FALSE
      )
    }
    fixed_cal
  }

  if (!is.null(r_cal_bm) && !is.null(r_cal_gnn) && !is.null(r_cal_mean)) {
    w_bm <- as.numeric(r_cal_bm)
    w_gnn <- as.numeric(r_cal_gnn)
    w_mean <- as.numeric(r_cal_mean)
  } else {
    w_gnn <- as.numeric(calibrated_gates)
    w_bm <- 1 - w_gnn
    w_mean <- rep(0, p)
  }
  mean_vec <- if (is.null(mean_baseline_per_col)) {
    rep(0, p)
  } else {
    as.numeric(mean_baseline_per_col)
  }
  if (
    length(w_bm) != p ||
      length(w_gnn) != p ||
      length(w_mean) != p ||
      length(mean_vec) != p
  ) {
    stop(
      "Calibration weights and means must have length ncol(`mu_cal`).",
      call. = FALSE
    )
  }

  # Blended predictions using the same calibrated weights used by predict().
  pred_cal <- matrix(0, n, p)
  for (j in seq_len(p)) {
    pred_cal[, j] <- fixed_mat[, j] +
      w_bm[j] * mu_cal[, j] +
      w_gnn[j] * delta_cal[, j] +
      w_mean[j] * mean_vec[j]
  }

  conformal_scores <- rep(NA_real_, length(trait_map))
  names(conformal_scores) <- vapply(trait_map, "[[", character(1), "name")
  mondrian_info <- if (method == "mondrian") list() else NULL

  for (tm in trait_map) {
    if (
      !(tm$type %in%
        c("continuous", "count", "ordinal", "proportion", "zi_count"))
    ) {
      next
    }
    lc <- tm$latent_cols
    # zi_count: score the magnitude (log1p-z) column, not the Bernoulli gate
    # and not decoded E[X]. Zeros leave mag NA, so val cells are non-zeros.
    score_col <- if (identical(tm$type, "zi_count")) lc[2L] else lc[1L]
    val_cells <- val_mask_mat[, score_col]
    if (sum(val_cells) == 0) {
      next
    }

    # species_idx tracks row indices in step with `residuals` so the
    # Mondrian branch can look up per-cell locality after the finite
    # filter below.
    species_idx <- which(val_cells)
    residuals <- abs(
      X_truth_r[species_idx, score_col] -
        pred_cal[species_idx, score_col]
    )
    finite <- is.finite(residuals)
    residuals <- residuals[finite]
    species_idx <- species_idx[finite]
    n_val <- length(residuals)
    if (n_val == 0L) {
      next
    }

    q_level <- min(ceiling((1 - alpha) * (n_val + 1)) / n_val, 1)

    if (method == "split") {
      conformal_scores[tm$name] <- as.numeric(
        stats::quantile(residuals, q_level, na.rm = TRUE)
      )
    } else if (method == "bootstrap") {
      # bootstrap: average the split quantile over B resamples
      B <- as.integer(bootstrap_B)
      qs <- vapply(
        seq_len(B),
        function(b) {
          idx <- sample.int(n_val, n_val, replace = TRUE)
          as.numeric(stats::quantile(residuals[idx], q_level, na.rm = TRUE))
        },
        numeric(1)
      )
      conformal_scores[tm$name] <- mean(qs, na.rm = TRUE)
    } else {
      # mondrian: global (split) score is always computed first, both as
      # the base named-vector value and as the fallback score.
      global_score <- as.numeric(
        stats::quantile(residuals, q_level, na.rm = TRUE)
      )
      conformal_scores[tm$name] <- global_score

      obs_idx <- which(obs_mask_mat[, score_col])
      fallback <- length(obs_idx) == 0L
      n_near <- NA_integer_  # realised stratum sizes; kept on fallback
      n_far  <- NA_integer_
      near_score <- global_score
      far_score  <- global_score
      threshold  <- NA_real_
      n_near <- NA_integer_
      n_far  <- NA_integer_

      if (!fallback) {
        locality <- mondrian_locality(D_sq, obs_idx, species_idx,
                                      k = k_locality)
        loc_ok <- is.finite(locality)
        if (sum(loc_ok) == 0L) {
          fallback <- TRUE
        } else {
          threshold <- stats::median(locality[loc_ok])
          near <- loc_ok & (locality <= threshold)
          far  <- loc_ok & (locality > threshold)
          n_near <- sum(near)
          n_far  <- sum(far)
          # Each stratum needs >= 19 residuals or its own achievable
          # coverage ceiling n_s/(n_s+1) sits below 0.95 -- the same
          # arithmetic as the small-validation warning. Measured on the
          # 2026-08-16 mech_cov_mondrian verification: with ~13-cell
          # strata (n=300, ~26 val cells/trait) MCAR coverage landed at
          # exactly the 13/14 = 0.929 ceiling. Below 19 per stratum,
          # stratifying is guaranteed to undercover, so fall back to the
          # global split score.
          if (n_near < 19L || n_far < 19L) {
            fallback <- TRUE
          } else {
            q_near <- min(ceiling((1 - alpha) * (n_near + 1)) / n_near, 1)
            q_far  <- min(ceiling((1 - alpha) * (n_far  + 1)) / n_far,  1)
            near_score <- as.numeric(
              stats::quantile(residuals[near], q_near, na.rm = TRUE)
            )
            far_score <- as.numeric(
              stats::quantile(residuals[far], q_far, na.rm = TRUE)
            )
          }
        }
      }

      if (fallback) {
        near_score <- global_score
        far_score  <- global_score
        threshold  <- NA_real_
      }

      if (verbose && fallback) {
        message(sprintf(
          "Mondrian conformal fallback for trait '%s': n_near=%s, n_far=%s (floor 19)",
          tm$name,
          if (is.na(n_near)) "NA" else n_near,
          if (is.na(n_far)) "NA" else n_far
        ))
      }

      mondrian_info[[tm$name]] <- list(
        near_score = near_score,
        far_score  = far_score,
        threshold  = threshold,
        fallback   = fallback,
        n_val      = n_val,
        n_near     = n_near,
        n_far      = n_far
      )
    }
  }

  if (verbose) {
    cs_print <- round(conformal_scores[!is.na(conformal_scores)], 4)
    message(sprintf(
      "Conformal scores (latent scale, method=%s): %s",
      method,
      paste(names(cs_print), cs_print, sep = "=", collapse = ", ")
    ))
  }

  if (method == "mondrian") {
    attr(conformal_scores, "mondrian") <- mondrian_info
  }

  conformal_scores
}

# Mean cophenetic distance from each target species to its `k` nearest
# OBSERVED species (excluding self). Used by the `"mondrian"` conformal
# method to condition calibration on phylogenetic sampling locality.
#
# @param D_sq        numeric matrix (n_species × n_species), squared
#                    cophenetic distances (`build_phylo_graph()$D_sq`).
# @param obs_idx     integer vector of species row/col indices treated as
#                    "observed" (the calibration donor pool) for one trait.
# @param target_idx  integer vector of species indices to compute locality
#                    for.
# @param k           integer, number of nearest observed species averaged
#                    (default 5). Uses all available when fewer than `k`.
# @return numeric vector, same length as `target_idx`; `NA_real_` for a
#   target with no eligible (non-self) observed species.
# @noRd
mondrian_locality <- function(D_sq, obs_idx, target_idx, k = 5L) {
  obs_idx    <- as.integer(obs_idx)
  target_idx <- as.integer(target_idx)
  n_t <- length(target_idx)
  out <- rep(NA_real_, n_t)
  if (n_t == 0L || length(obs_idx) == 0L) {
    return(out)
  }
  dist_sub <- sqrt(D_sq[target_idx, obs_idx, drop = FALSE])
  for (i in seq_len(n_t)) {
    d <- dist_sub[i, ]
    self_pos <- which(obs_idx == target_idx[i])
    if (length(self_pos) > 0L) {
      d <- d[-self_pos]
    }
    if (length(d) == 0L) {
      next
    }
    kk <- min(as.integer(k), length(d))
    out[i] <- mean(sort(d)[seq_len(kk)])
  }
  out
}

# ---------------------------------------------------------------------------
# mask_heldout_with_baseline() / pigauto_refine_forward()
# ---------------------------------------------------------------------------
#
# Train/cal/predict symmetry helpers (B1 / B3, 2026-08-07).
# Held-out val/test cells must not appear as truth in the DAE input during
# training or calibration. Iterative refine at calibration must use the same
# refine_steps count that predict() will use.

#' Apply phylo-signal gate override to calibrated three-way weights (B2).
#'
#' Mean corner `(0,0,1)` requires a real `mean_baseline_per_col`. Without
#' it, predict falls back to latent 0 — use BM `(1,0,0)` instead.
#'
#' @return list with updated `r_cal_bm`, `r_cal_gnn`, `r_cal_mean`, and
#'   `used_mean_corner` (logical)
#' @noRd
apply_phylo_signal_gate_override <- function(
  r_cal_bm,
  r_cal_gnn,
  r_cal_mean,
  gated_latent_cols,
  safety_floor,
  mean_baseline_per_col,
  warn = TRUE
) {
  if (length(gated_latent_cols) == 0L) {
    return(list(
      r_cal_bm = r_cal_bm,
      r_cal_gnn = r_cal_gnn,
      r_cal_mean = r_cal_mean,
      used_mean_corner = FALSE
    ))
  }
  use_mean <- isTRUE(safety_floor) && !is.null(mean_baseline_per_col)
  if (use_mean) {
    r_cal_bm[gated_latent_cols] <- 0
    r_cal_gnn[gated_latent_cols] <- 0
    r_cal_mean[gated_latent_cols] <- 1
  } else {
    if (isTRUE(warn)) {
      warning(
        "phylo_signal_gate triggered for ",
        length(gated_latent_cols),
        " latent column(s) but safety_floor = FALSE (or mean baseline ",
        "unavailable); falling back to BM (r_cal_bm = 1) instead of the ",
        "mean corner, which would become latent 0 at predict time.",
        call. = FALSE
      )
    }
    r_cal_bm[gated_latent_cols] <- 1
    r_cal_gnn[gated_latent_cols] <- 0
    r_cal_mean[gated_latent_cols] <- 0
  }
  list(
    r_cal_bm = r_cal_bm,
    r_cal_gnn = r_cal_gnn,
    r_cal_mean = r_cal_mean,
    used_mean_corner = use_mean
  )
}

#' Replace held-out latent cells with the baseline prediction.
#'
#' @param X_fill numeric matrix (n × p), NA-filled with baseline already
#' @param MU numeric matrix (n × p), baseline predictions
#' @param hold_idx integer vector of linear (column-major) indices to mask,
#'   typically `c(splits$val_idx, splits$test_idx)`. May be empty.
#' @return numeric matrix same dim as `X_fill`
#' @noRd
mask_heldout_with_baseline <- function(X_fill, MU, hold_idx) {
  out <- X_fill
  if (length(hold_idx) > 0L) {
    out[hold_idx] <- MU[hold_idx]
  }
  out
}

#' Iterative GNN forward with pinned observed cells.
#'
#' Used by gate calibration (and tests) so the delta surface matches the
#' multi-step refine path in `predict.pigauto_fit()`.
#'
#' @param blend `"learned_rs"` uses the model's sigmoid gates; `"calibrated"`
#'   uses the supplied `t_w_*` tensors (must all be non-NULL).
#' @param pin_mask logical/bool torch tensor (n × p) or NULL. When set,
#'   those cells are reset to `X_init` after every step.
#' @return list with `out` (last model output), `pred` (last blend), `delta_mat`,
#'   `fixed_mat` (matrix or NULL)
#' @noRd
pigauto_refine_forward <- function(
  model,
  X_init,
  t_coords,
  t_adj,
  t_obs_to_sp,
  t_D_sq,
  t_MU,
  t_covariates,
  pin_mask,
  refine_steps,
  device,
  blend = c("learned_rs", "calibrated"),
  t_w_bm = NULL,
  t_w_gnn = NULL,
  t_w_mean = NULL,
  t_mean_baseline = NULL
) {
  blend <- match.arg(blend)
  refine_steps <- as.integer(refine_steps)
  if (refine_steps < 1L) {
    stop("refine_steps must be >= 1", call. = FALSE)
  }
  if (identical(blend, "calibrated")) {
    if (
      is.null(t_w_bm) ||
        is.null(t_w_gnn) ||
        is.null(t_w_mean) ||
        is.null(t_mean_baseline)
    ) {
      stop(
        "calibrated blend requires t_w_bm, t_w_gnn, t_w_mean, ",
        "t_mean_baseline",
        call. = FALSE
      )
    }
  }

  X_iter <- X_init$clone()
  out <- NULL
  pred <- NULL
  n <- X_init$size(1)
  torch::with_no_grad({
    for (step in seq_len(refine_steps)) {
      mask_ind0 <- torch::torch_zeros(c(n, 1L), device = device)
      covs0 <- make_covs_tensor(t_MU, mask_ind0, t_covariates)
      out <- model(X_iter, t_coords, covs0, t_adj, t_obs_to_sp, D_sq = t_D_sq)
      if (identical(blend, "learned_rs")) {
        pred <- (1 - out$rs) * t_MU + out$rs * out$delta
      } else {
        pred <- t_w_bm * t_MU + t_w_gnn * out$delta + t_w_mean * t_mean_baseline
      }
      if (!is.null(out$fixed_effects)) {
        pred <- pred + out$fixed_effects
      }
      if (!is.null(pin_mask)) {
        X_iter <- torch::torch_where(pin_mask, X_init, pred)
      } else {
        X_iter <- pred
      }
    }
  })

  fixed_mat <- if (!is.null(out$fixed_effects)) {
    as.matrix(out$fixed_effects$cpu())
  } else {
    NULL
  }
  list(
    out = out,
    pred = pred,
    delta_mat = as.matrix(out$delta$cpu()),
    fixed_mat = fixed_mat
  )
}
