# R/gbif_centroids.R
# Fetch and aggregate GBIF species-occurrence records to per-species
# centroid lat/lon covariates for pigauto.
# See specs/2026-04-23-gbif-centroids-design.md.

# Sanitise a species name for use as a filesystem-safe cache key.
# Any character that's not alphanumeric, `_`, `.`, or `-` is replaced
# with `_`. Guaranteed non-empty; guaranteed to not contain `/`.
#
# @param sp character scalar, species name
# @return character scalar
# @noRd
.gbif_cache_key <- function(sp) {
  stopifnot(is.character(sp), length(sp) == 1L, nzchar(sp))
  key <- gsub("[^A-Za-z0-9_-]", "_", sp)
  if (!nzchar(key)) key <- "unnamed"
  key
}

# Aggregate a GBIF occurrence data.frame to a single centroid.
#
# Input must have at least these columns:
#   decimalLatitude, decimalLongitude, hasGeospatialIssues, basisOfRecord
#
# Applies filters (dropping fossil specimens, living specimens, records
# flagged with geospatial issues, NA coords, out-of-range coords), then
# returns list(centroid_lat, centroid_lon, n_occurrences).
#
# @noRd
.gbif_centroid_one <- function(records) {
  if (nrow(records) == 0L) {
    return(list(centroid_lat = NA_real_,
                 centroid_lon = NA_real_,
                 n_occurrences = 0L))
  }
  # hasGeospatialIssues may be absent from the GBIF response (column NULL) —
  # the v3 API does not always return this field.  Treat absent as FALSE
  # (pass through; we already filter on coord range and hasCoordinate=TRUE).
  # For a present column, treat NA as TRUE (conservative).
  has_issue <- records$hasGeospatialIssues
  if (is.null(has_issue)) {
    has_issue <- rep(FALSE, nrow(records))
  } else {
    has_issue[is.na(has_issue)] <- TRUE
  }
  # basisOfRecord may also be absent; treat absent as not-excluded.
  bor <- records$basisOfRecord
  if (is.null(bor)) bor <- rep("UNKNOWN", nrow(records))
  ok <- !is.na(records$decimalLatitude) &
         !is.na(records$decimalLongitude) &
         records$decimalLatitude  >= -90  & records$decimalLatitude  <= 90 &
         records$decimalLongitude >= -180 & records$decimalLongitude <= 180 &
         !has_issue &
         !(bor %in% c("FOSSIL_SPECIMEN", "LIVING_SPECIMEN"))
  kept <- records[ok, , drop = FALSE]
  if (nrow(kept) == 0L) {
    return(list(centroid_lat = NA_real_,
                 centroid_lon = NA_real_,
                 n_occurrences = 0L))
  }
  list(centroid_lat = stats::median(kept$decimalLatitude),
        centroid_lon = stats::median(kept$decimalLongitude),
        n_occurrences = nrow(kept))
}

# Fetch (and cache) centroids for one species.
#
# Cache check first: if an RDS exists at {cache_dir}/{cache_key}.rds,
# load it unless refresh_cache = TRUE.
#
# Otherwise: rgbif::name_backbone() -> rgbif::occ_search() -> filter -> aggregate.
# Cache the result (including n_occ = 0 cases so we don't re-hit the API
# for a species with no records).
#
# Failed queries stop without writing a cache entry. Existing entries survive
# a failed refresh. Occurrence page requests retry 3 times with backoff.
#
# @noRd
.gbif_fetch_one <- function(sp, cache_dir = NULL,
                             occurrence_limit = 500L,
                             sleep_ms = 100L,
                             refresh_cache = FALSE,
                             store_points = FALSE) {
  stopifnot(is.character(sp), length(sp) == 1L, nzchar(sp))
  # Cache lookup
  cache_path <- if (!is.null(cache_dir)) {
    dir.create(cache_dir, showWarnings = FALSE, recursive = TRUE)
    file.path(cache_dir, paste0(.gbif_cache_key(sp), ".rds"))
  } else {
    NA_character_
  }
  if (!refresh_cache && !is.na(cache_path) && file.exists(cache_path)) {
    cached <- tryCatch(readRDS(cache_path), error = function(e) NULL)
    if (!is.null(cached) && identical(cached$species, sp)) {
      # Check if per-occurrence points are required but missing
      if (store_points && is.null(cached$points)) {
        message(sprintf("Updating cache for %s: per-occurrence points requested but not found.", sp))
        # Skips the return, forcing it to fall through to the live fetch below
      } else {
        return(list(species = sp,
                    centroid_lat = cached$centroid_lat,
                    centroid_lon = cached$centroid_lon,
                    n_occurrences = cached$n_occurrences,
                    points = cached$points))
      }
    }
  }
  # Require rgbif for live fetch
  if (!requireNamespace("rgbif", quietly = TRUE)) {
    stop("pull_gbif_centroids() requires the 'rgbif' package: ",
         "install.packages('rgbif')", call. = FALSE)
  }
  # Resolve taxon
  bbone <- tryCatch(rgbif::name_backbone(name = sp), error = function(e) {
    stop("GBIF name lookup failed for '", sp, "': ", conditionMessage(e),
         call. = FALSE)
  })
  if (is.null(bbone) || is.null(bbone$usageKey)) {
    res <- list(species = sp, centroid_lat = NA_real_, centroid_lon = NA_real_,
                 n_occurrences = 0L)
    if (!is.na(cache_path)) {
      saveRDS(c(res, list(fetched_at = Sys.time(), match_type = "NO_MATCH")),
              cache_path)
    }
    return(res)
  }
  # Fetch occurrences (with pagination to support occurrence_limit > 300)
  per_call <- 300L
  pages <- ceiling(occurrence_limit / per_call)
  records <- NULL
  for (p in seq_len(pages)) {
    offset <- (p - 1L) * per_call
    limit  <- min(per_call, occurrence_limit - offset)
    if (limit <= 0L) break
    ret <- .gbif_fetch_page(bbone$usageKey, offset, limit)
    if (is.null(ret)) {
      stop("GBIF occurrence request failed for '", sp,
           "' after retries; no partial result was cached.", call. = FALSE)
    }
    if (nrow(ret) == 0L) break
    records <- rbind(records, ret)
    if (sleep_ms > 0L) Sys.sleep(sleep_ms / 1000)
  }
  # Aggregate
  centroid <- .gbif_centroid_one(records %||% data.frame(
    decimalLatitude = numeric(0), decimalLongitude = numeric(0),
    hasGeospatialIssues = logical(0), basisOfRecord = character(0)))
  res <- list(species = sp,
               centroid_lat = centroid$centroid_lat,
               centroid_lon = centroid$centroid_lon,
               n_occurrences = centroid$n_occurrences)
  # Collect raw valid points if store_points = TRUE
  points_df <- NULL
  if (isTRUE(store_points) && !is.null(records) && nrow(records) > 0L) {
    # Apply the SAME filters as .gbif_centroid_one for consistency
    ok <- !is.na(records$decimalLatitude) &
           !is.na(records$decimalLongitude) &
           records$decimalLatitude  >= -90  & records$decimalLatitude  <= 90 &
           records$decimalLongitude >= -180 & records$decimalLongitude <= 180
    has_issue <- records$hasGeospatialIssues
    if (is.null(has_issue)) has_issue <- rep(FALSE, nrow(records))
    has_issue[is.na(has_issue)] <- TRUE
    bor <- records$basisOfRecord
    if (is.null(bor)) bor <- rep("UNKNOWN", nrow(records))
    ok <- ok & !has_issue &
           !(bor %in% c("FOSSIL_SPECIMEN", "LIVING_SPECIMEN"))
    kept <- records[ok, , drop = FALSE]
    if (nrow(kept) > 0L) {
      points_df <- data.frame(
        lat = kept$decimalLatitude,
        lon = kept$decimalLongitude,
        stringsAsFactors = FALSE)
    }
  }
  if (!is.na(cache_path)) {
    cache_obj <- c(res, list(fetched_at = Sys.time(),
                              match_type = bbone$matchType %||% "UNKNOWN"))
    if (!is.null(points_df)) cache_obj$points <- points_df
    saveRDS(cache_obj, cache_path)
  }
  res
}

# Inner page-fetcher, retriable.  Separated so tests can mock.
# @noRd
.gbif_fetch_page <- function(taxon_key, offset, limit) {
  tries <- 0L
  while (tries < 3L) {
    ret <- tryCatch(
      rgbif::occ_search(taxonKey = taxon_key,
                         hasCoordinate = TRUE,
                         limit = limit, start = offset),
      error = function(e) {
        Sys.sleep(2 ^ tries)
        NULL
      })
    if (!is.null(ret) && !is.null(ret$data)) return(ret$data)
    tries <- tries + 1L
  }
  NULL
}

#' Fetch species range-centroid covariates from GBIF
#'
#' Pulls occurrence records from the Global Biodiversity Information
#' Facility (GBIF) for each species in \code{species}, aggregates them
#' to a median latitude / longitude centroid. The returned data.frame
#' contains species identifiers, centroid coordinates, and occurrence
#' counts.
#'
#' With the default \code{cache_dir = NULL}, results are not cached, so a
#' later call queries GBIF again for each species. Set \code{cache_dir}
#' to a writable directory to reuse stored results; the example below uses
#' \code{"script/data-cache/gbif"}.
#'
#' For each species: resolve taxon via
#' \code{\link[rgbif]{name_backbone}}, fetch up to
#' \code{occurrence_limit} records via \code{\link[rgbif]{occ_search}}
#' (paginated at 300 per GBIF call), filter out records with
#' \code{hasGeospatialIssues = TRUE} and \code{basisOfRecord} in
#' \code{c("FOSSIL_SPECIMEN", "LIVING_SPECIMEN")}, drop
#' out-of-range coordinates, then take the median latitude and
#' longitude as the species centroid.
#'
#' Species with zero post-filter records receive \code{NA} centroids;
#' their rows are still included in the returned data.frame so it
#' aligns with the input species list.
#'
#' For cache files written by pigauto, \code{refresh_cache = FALSE}
#' reuses a readable entry when its saved species name exactly matches the
#' request. A live GBIF query is needed when no matching cache entry is
#' available or \code{refresh_cache = TRUE}. GBIF is also queried again
#' for that species when \code{store_points = TRUE} and the saved
#' \code{points} field is absent or \code{NULL}. With
#' \code{cache_dir = NULL}, each call queries GBIF instead of using a
#' cache. These live-query paths require the optional \code{rgbif} package.
#'
#' A cached result can still contain an \code{NA} centroid. That can mean
#' pigauto could not match the species name, GBIF returned no records, or
#' all records were excluded by pigauto's filters. Older cache entries may
#' also reflect failed requests, including incomplete non-\code{NA} centroids
#' or points when a later occurrence page failed. Set
#' \code{refresh_cache = TRUE} to retry affected entries; this requires a
#' live GBIF query and the optional \code{rgbif} package. A failed name
#' lookup or occurrence request now stops with an error without caching a
#' partial result or replacing an existing cache entry. Occurrence requests
#' are retried before stopping.
#'
#' @param species           non-empty character vector of unique species names.
#'   Do not include missing or empty names. These names are used for
#'   GBIF lookups, output row names, and (when caching) cache-key
#'   generation.
#' @param cache_dir         directory to cache per-species RDS files.
#'   \code{NULL} (default) disables caching — not recommended for
#'   production use.
#' @param occurrence_limit  integer, maximum number of occurrences to
#'   fetch per species (default 500; paginated if > 300).
#' @param sleep_ms          integer, polite delay between API calls in
#'   milliseconds (default 100).
#' @param verbose           logical, print progress every 50 species.
#' @param refresh_cache     logical, force re-fetch even when cache
#'   exists.
#' @param store_points logical. When \code{TRUE}, persists the raw
#'   filtered lat/lon occurrence points in each species' cache RDS
#'   under the \code{points} field.  Used by
#'   \code{\link{pull_worldclim_per_species}} for per-occurrence
#'   bioclim extraction. Default \code{FALSE} stores centroid summaries
#'   without the raw point list. Requesting points refetches an existing
#'   centroid-only GBIF cache when the point list is absent.
#'
#' @return A data.frame with columns \code{species}, \code{centroid_lat},
#'   \code{centroid_lon}, \code{n_occurrences}. Rownames are set to
#'   \code{species}. NA centroids are returned for species with no
#'   GBIF hits; the caller should decide how to handle them (typical:
#'   drop or impute).
#'
#' @seealso \code{\link{impute}}. For geographic covariates, select only
#'   \code{centroid_lat} and \code{centroid_lon}. With one row per species,
#'   keep species row names so coordinates match the species in the traits and
#'   tree. With repeated
#'   observations, repeat each species' coordinates in trait-row order. Resolve
#'   missing or non-finite coordinates before fitting.
#'
#' @examplesIf interactive()
#' sp <- c("Quercus alba", "Pinus taeda", "Acer saccharum")
#' cov <- pull_gbif_centroids(sp, cache_dir = "script/data-cache/gbif")
#' cov_num <- cov[, c("centroid_lat", "centroid_lon"), drop = FALSE]
#'
#' @export
pull_gbif_centroids <- function(species, cache_dir = NULL,
                                 occurrence_limit = 500L,
                                 sleep_ms = 100L,
                                 verbose = TRUE,
                                 refresh_cache = FALSE,
                                 store_points = FALSE) {
  stopifnot(is.character(species), length(species) >= 1L)
  n_sp <- length(species)
  rows <- vector("list", n_sp)
  n_success <- 0L
  for (i in seq_along(species)) {
    sp <- species[[i]]
    row <- .gbif_fetch_one(sp,
                             cache_dir = cache_dir,
                             occurrence_limit = occurrence_limit,
                             sleep_ms = sleep_ms,
                             refresh_cache = refresh_cache,
                             store_points = store_points)
    rows[[i]] <- row
    if (is.finite(row$centroid_lat)) n_success <- n_success + 1L
    if (verbose && (i %% 50L == 0L || i == n_sp)) {
      cat(sprintf("[gbif] %d/%d species fetched, %d with valid centroids\n",
                   i, n_sp, n_success))
    }
  }
  out <- data.frame(
    species       = vapply(rows, function(r) r$species, character(1L)),
    centroid_lat  = vapply(rows, function(r) r$centroid_lat, numeric(1L)),
    centroid_lon  = vapply(rows, function(r) r$centroid_lon, numeric(1L)),
    n_occurrences = vapply(rows, function(r) r$n_occurrences, integer(1L)),
    stringsAsFactors = FALSE,
    row.names = species)
  out
}

# In-file %||% shim (pigauto defines one elsewhere, but making this file
# self-contained helps testthat mock_bindings for rgbif).
`%||%` <- function(a, b) if (is.null(a)) b else a
