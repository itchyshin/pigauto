#' Generate experimental stochastic completion datasets
#'
#' Run pigauto's full imputation pipeline and return `M` stochastic
#' completions of the trait matrix instead of a single point estimate.
#' The conformal-width and mc_dropout draws returned here are experimental
#' prediction diagnostics. The mc_dropout route uses independent Gaussian
#' perturbations per latent cell, scaled by selected baseline SD, and adds GNN
#' dropout variation only when the GNN is enabled. Do not use these datasets for
#' downstream inference or Rubin pooling.
#'
#' For continuous traits, `draws_method = "posterior"` instead returns
#' posterior predictive draws that the documented software route permits
#' analysts to fit and pool under the conditions below.
#'
#' **Validation boundary:** the registered validation found five of eight
#' tested posterior-slope regimes failed and three were indeterminate; none
#' met the support criteria. These results are limited to the tested regimes
#' and do not establish performance for a new analysis. See [the registered
#' inferential results](https://itchyshin.github.io/pigauto/articles/validation-results.html#inferential-results)
#' before using [with_imputations()] and [pool_mi()]. The separate
#' analysis-aware backend,
#' [multi_impute_analysis()], covers its own documented narrow regime.
#'
#' @section When to use this:
#'
#' With `draws_method = "conformal"` or `"mc_dropout"`, this function is
#' useful for comparing stochastic prediction behavior from one tree; those
#' draws are not for downstream inference. With `draws_method = "posterior"`
#' (continuous traits), it returns posterior predictive draws that the
#' documented software route permits analysts to fit and pool under the
#' conditions in "Posterior draws". This software eligibility does not
#' establish model compatibility or inferential performance across regimes;
#' the registered validation had five tested slope regimes fail and three
#' remain indeterminate. [with_imputations()] fits eligible analyses and
#' [pool_mi()] pools those fits.
#' [multi_impute_analysis()] is the separate analysis-aware backend for its
#' own documented regime.
#'
#' [multi_impute_trees()] provides an experimental posterior-tree sensitivity
#' check. Its outputs are diagnostic and are not accepted by
#' [with_imputations()] or [pool_mi()], so tree-aware downstream inference is
#' not currently supported.
#'
#' @param traits data.frame with species as rownames and trait columns.
#'   Same input format as [impute()]. Supported column types are
#'   numeric, integer, factor, ordered factor, and logical.
#' @param tree object of class `phylo` aligned with `traits`.
#' @param m integer. Number of stochastic completion datasets to generate
#'   (default `100`). Observed cells are identical across all `M`
#'   datasets; only originally-missing cells vary.
#' @param draws_method character. How stochastic draws are generated for
#'   missing cells. One of:
#'   \describe{
#'     \item{`"auto"`}{(default; previously `"conformal"`) Use `"posterior"` when
#'       the data fit its requirements (every trait continuous, one row per
#'       species, no `covariates`, no `multi_proportion_groups`); otherwise
#'       use `"conformal"` and print a message saying why and that the draws
#'       cannot be pooled. The chosen method is stored in
#'       `result$draws_method`. To get the previous default, set
#'       `draws_method = "conformal"`.}
#'     \item{`"conformal"`}{Use this method when `"auto"` falls back
#'       because the posterior sampler's requirements are not met, or when
#'       explicitly requested. Run the model once, then sample each
#'       originally-missing cell from a Normal distribution centred on the
#'       point estimate with SD = conformal_score / 1.96. Converting a
#'       split-conformal residual quantile to a Normal scale is a heuristic;
#'       a nominal held-out conformal diagnostic does not establish that these
#'       draws are suitable for downstream multiple-imputation inference.
#'       For continuous, count, ordinal, and proportion traits, when no finite
#'       conformal score is available, pigauto uses the reported `pred$se` as a
#'       scale input for fallback draws. For
#'       log-transformed continuous traits, log1p-transformed counts, and
#'       logit-transformed proportions, `pred$se` is reported on the original
#'       scale, but the draw is made on the transformed scale. Pigauto does
#'       not fully convert `pred$se` between these scales, so diagnostic draw
#'       spread may be too wide or too narrow. Fitted point predictions are
#'       unchanged. Binary and
#'       categorical traits use Bernoulli /
#'       categorical draws from predicted probabilities.}
#'     \item{`"mc_dropout"`}{Add independent Gaussian perturbations per latent
#'       cell, scaled by selected baseline SD. This returns `M` stochastic
#'       draws; when the GNN is enabled, its network runs use dropout in
#'       training mode. These prediction-diagnostic draws are not joint
#'       phylogenetic BM posterior draws and are unsupported for downstream
#'       inference.}
#'     \item{`"posterior"`}{Continuous traits only, one row per species, no
#'       covariates. Fit a Bayesian multivariate phylogenetic mixed model by
#'       MCMC and return `m` completions drawn from the posterior predictive
#'       distribution of the missing cells. No GNN is fitted. See "Posterior
#'       draws" below. In simulation (continuous traits, 30% missing
#'       completely at random, 200 datasets per cell, n = 100 to 1000,
#'       lambda 0.3 to 1, trait correlation 0 or 0.5), a Rubin-pooled
#'       downstream PGLS slope and phylogenetic correlation had 95% interval
#'       coverage of 0.925 to 0.975 in every cell. At lambda = 1 with trait
#'       correlation 0.5, slope coverage was 0.955, 0.940 and 0.965 at
#'       n = 100, 300 and 1000 (reference frequentist MI:
#'       0.955, 0.920, 0.935). At n = 100 with correlated traits the pooled
#'       slope was biased by about -0.02 towards zero, with coverage still
#'       0.96. These results concern only the stated simulation regimes and
#'       do not establish inferential performance elsewhere. The registered
#'       validation found five tested posterior slope regimes failed and
#'       three indeterminate; see the [registered inferential
#'       results](https://itchyshin.github.io/pigauto/articles/validation-results.html#inferential-results).
#'       The previous residual prior (`posterior_control =
#'       list(residual_prior = "iw")`) attenuated the relationship between
#'       correlated traits at lambda near 1: coverage 0.96, 0.88 and 0.75 at
#'       the same three n.}
#'   }
#'   Conformal and MC-dropout draws perturb missing cells around a point
#'   prediction rather than drawing them jointly from their conditional
#'   distribution given the observed data. In a 16-regime simulation of a
#'   downstream phylogenetic regression (PGLS slope, two traits, 120
#'   replicates per regime), conformal draws biased the pooled slope by
#'   -0.20 to -0.46, and the pooled 95% intervals covered the truth in 0 to
#'   17% of replicates, in all 16 regimes; MC-dropout draws biased it by
#'   -0.03 to -0.38. For continuous traits, the documented route permits
#'   eligible `"posterior"` draws to be fitted with
#'   [with_imputations()] and pooled with [pool_mi()] under the conditions
#'   below. Software eligibility does not show that the resulting estimates
#'   and uncertainty are reliable. In the registered validation, five of
#'   eight tested posterior-slope regimes failed the prespecified criteria
#'   and three were indeterminate; none was supported. These results apply
#'   to those tested regimes. Other analyses need evidence for their model,
#'   data, and missingness process; see the [registered inferential
#'   results](https://itchyshin.github.io/pigauto/articles/validation-results.html#inferential-results).
#' @param species_col character or `NULL`. If set, marks the column
#'   in `traits` containing species identifiers and enables multiple
#'   observations per species. See [impute()] for details.
#' @param trait_types named character vector overriding auto-detected
#'   trait types for specific columns. Required for `"proportion"` and
#'   `"zi_count"`. See [impute()] and [preprocess_traits()]. Default
#'   `NULL` (auto-detect).
#' @param ordinal_levels named list giving the scientific order of ordinal
#'   levels, e.g. `list(status = c("LC", "NT", "VU", "EN", "CR"))`. Each
#'   named column is coerced to an ordered factor with exactly those levels
#'   before type detection, and the completed datasets return it as an
#'   ordered factor. Observed values absent from the declared levels are an
#'   error. See [impute()] / [read_traits()]. Default `NULL`.
#' @param multi_proportion_groups named list declaring compositional
#'   trait groups (rows summing to 1), e.g.
#'   `list(diet = c("plant", "invert", "vert"))`. Forwarded to
#'   [impute()] / [preprocess_traits()]. Default `NULL`.
#' @param log_transform logical. Log-transform every continuous trait whose
#'   observed values are all positive
#'   (default `TRUE`), then back-transform the imputations. Set it to
#'   `FALSE` when traits are already on a log scale (for example log body
#'   mass): otherwise they are logged a second time and imputed on a
#'   log(log) scale, which can bias analyses done on the log scale. With a
#'   mix of raw and already-logged traits, log the raw ones yourself and set
#'   `FALSE`. In a real-data check (PanTHERIA, 4,027 mammal species, four
#'   already-logged traits, posterior draws), the default shifted
#'   Rubin-pooled regression slopes by up to 3.9 standard errors of the
#'   complete-data slope, in a direction that depended on which values were
#'   missing; with `FALSE` the largest shift was 1.8.
#' @param missing_frac numeric. Fraction of observed cells held out for
#'   validation/test during training (default `0.25`). Passed through
#'   to [impute()].
#' @param covariates data.frame or matrix of fully observed environmental
#'   covariates. For \code{"mc_dropout"} and \code{"conformal"} diagnostic
#'   draws, forwarded to [impute()]: a selected per-column numeric BM
#'   baseline may use them even with \code{gnn = FALSE}. Joint MVN and
#'   threshold-joint baselines omit them and emit a separate baseline warning.
#'   One-versus-rest categorical baselines also omit them but do not trigger that
#'   warning themselves. In a mixed fit, another selected joint route can still
#'   trigger it. With
#'   \code{gnn = TRUE}, they also
#'   enter the GNN and additive linear component. Choosing
#'   \code{predict_method = "per_column"} within a joint fit does not enable
#'   covariate regression. The posterior sampler is a separate model route;
#'   see its eligibility requirements below. Default `NULL`.
#' @param epochs integer. Maximum GNN training epochs (default `2000`).
#' @param verbose logical. Print progress (default `TRUE`).
#' @param seed optional integer. When supplied, makes fitting and imputation
#'   draws reproducible; the default `NULL` uses the current RNG stream.
#' @param gnn logical. Passed through to [impute()] / [fit_pigauto()]. When
#'   `TRUE`, the usual GNN correction is trained. When `FALSE` (default),
#'   no GNN is used (baseline-only fit; see [fit_pigauto()]). With
#'   `draws_method = "mc_dropout"` this uses independent latent-cell Gaussian
#'   perturbations scaled by baseline SD, with no GNN dropout; an explanatory
#'   message is printed for that call. These are not joint BM posterior draws;
#'   `draws_method = "conformal"` is unaffected. Covariate use is
#'   route-dependent as described above; the warning under `gnn = FALSE`
#'   does not rule out covariate-aware per-column BM predictions/draws.
#' @param lambda_mode character. Pagel-lambda mode for the BM baseline,
#'   forwarded to [impute()] / [fit_pigauto()]. `"estimate"` (default) fits
#'   a per-trait Pagel's lambda on each continuous-family (BM-eligible)
#'   latent column. Discrete traits estimate their own lambda by default
#'   (`discrete_lambda = "estimate"`, passed through `...` to [impute()]);
#'   set `discrete_lambda = "fixed_1"` to retain lambda = 1 for their
#'   baseline. Joint exact prediction can also use a shared `lambda_block`
#'   for its cross-trait conditional. `"fixed_1"`
#'   preserves the pre-lambda Brownian correlation matrix everywhere;
#'   `"cv"` and `"bayes"` are alternative per-column estimators. See
#'   [fit_pigauto()] for the full contract, including the
#'   `predict_method = "exact"` / `joint_refine_iter > 0` interaction with
#'   `lambda_block`.
#' @param posterior_control list of settings for `draws_method =
#'   "posterior"` (ignored otherwise). Elements, with defaults:
#'   \describe{
#'     \item{`n_chains`}{`4L`. Number of MCMC chains. Chain 1 starts at the
#'       per-trait REML Pagel's lambda clamped to \[0.02, 0.98\] (up to 2,000
#'       tips; above that, or if the REML fit fails, at lambda = 0.9), and the
#'       other chains start from values dispersed around it.
#'       `mi$posterior$start` holds the REML lambda and chain 1's lambda
#'       before clamping.}
#'     \item{`n_iter`}{`5000L`. Sweeps per chain after burn-in.}
#'     \item{`burnin`}{`1000L`. Burn-in sweeps per chain (also used to tune
#'       the Metropolis step sizes).}
#'     \item{`thin`}{Default: `n_iter` integer-divided by
#'       `ceiling(keep_draws / n_chains)`, so
#'       that the chains together keep `keep_draws` sweeps.}
#'     \item{`keep_draws`}{`1000L`. Target number of kept posterior
#'       predictive draws across chains, used for the per-cell intervals.
#'       Must be at least `m`. The default `thin` keeps at least this many
#'       whenever `n_iter` is at least `ceiling(keep_draws / n_chains)`. If
#'       a user-set `n_iter` or `thin` keeps fewer (but at least `m`), a
#'       warning is raised and the intervals use the sweeps that were kept;
#'       keeping fewer than `m` is an error.}
#'     \item{`param_uncertainty`}{`"full"` (default), `"none"` or `"both"`.
#'       `"none"` is an improper plug-in mode for validation only: the
#'       covariance matrices are fixed at their posterior means from a full
#'       run, and only the missing cells (and the trait means) are drawn.
#'       Its result carries `mi_workflow =
#'       "pigauto_posterior_plugin_diagnostic"`, and [with_imputations()]
#'       and [pool_mi()] refuse it.
#'       `"both"` is also for validation only: it runs the sampler once and
#'       returns the proper results exactly as `"full"` does, plus the
#'       plug-in draws from the same run in `mi$posterior_improper`.}
#'     \item{`seed`}{Integer or `NULL`. Defaults to `seed`.}
#'     \item{`auto_extend`}{`TRUE`. If the chains fail the convergence rule
#'       (any split R-hat at least 1.05 or any bulk ESS at most 400), every
#'       chain continues from where it stopped for another `n_iter` sweeps
#'       and the diagnostics are recomputed on all sweeps after burn-in; this
#'       repeats until the rule is met or `max_extend` extensions have been
#'       made. Burn-in is not repeated and the Metropolis step sizes stay as
#'       tuned in burn-in, so an extended chain is the same chain as one run
#'       longer from the start. After `k` extensions the kept draws are every
#'       `thin * (k + 1)`-th sweep, spread over the whole run, so their
#'       number does not change. A fit that meets the rule first time is not
#'       affected. `FALSE` never extends.}
#'     \item{`max_extend`}{`3L`. Maximum number of extensions, a whole
#'       number from 0 to 10. The default allows at most 4 times `n_iter`
#'       sweeps per chain after burn-in.}
#'     \item{`residual_prior`}{`"sep"` (default) or `"iw"`. The default
#'       separation strategy uses half-Cauchy priors for residual standard
#'       deviations, scaled by the trait's observed latent-trait standard
#'       deviation, and an LKJ(1) prior for the full residual-correlation
#'       matrix. Before applying the numerical cutoff, the LKJ(1) prior does
#'       not give each pairwise correlation a uniform distribution when there
#'       are more than two traits. The cutoff also narrows the prior support;
#'       see the posterior-draw details. `"iw"`
#'       selects the legacy inverse-Wishart prior
#'       used before pigauto 0.11.0.9002; it is retained for reproducing
#'       earlier results.}
#'   }
#' @param ... additional arguments forwarded to [fit_pigauto()] via
#'   [impute()]. See [fit_pigauto()] for the full list, including the
#'   optional `safety_floor` control described below.
#'
#' @return An object of class `"pigauto_mi"` with components:
#'   \describe{
#'     \item{`datasets`}{A list of length `m`. Each element is a
#'       data.frame with the same shape and column types as the input
#'       `traits`; observed cells are preserved. Missing cells are filled
#'       with stochastic draws where available. A cell marked for imputation
#'       can remain `NA` if no prediction is available. These datasets are
#'       for prediction diagnostics, not downstream inference, except with
#'       `draws_method = "posterior"` (unless
#'       `posterior_control$param_uncertainty = "none"`), whose datasets are
#'       posterior imputations: fit the analysis to them with
#'       [with_imputations()] and pool the fits with [pool_mi()] (see
#'       `posterior` below and "Posterior draws").}
#'     \item{`m`}{Number of stochastic completion datasets.}
#'     \item{`pooled_point`}{A single data.frame of observed values and point
#'       completions for reporting; missing cells can remain `NA` when no
#'       prediction is available. It is
#'       the point completion returned by the selected route, not generally
#'       an average of the `m` decoded datasets. Use `datasets` for an
#'       eligible downstream multiple-imputation analysis. For the posterior
#'       route, missing-cell values decode the mean latent value over retained
#'       posterior predictive draws, not necessarily the `m` returned datasets.}
#'     \item{`se`}{Matrix of per-cell uncertainty summaries. For the
#'       conformal and MC-dropout routes, these come from the prediction step;
#'       for posterior draws, they are original-scale posterior predictive
#'       standard deviations calculated from all retained draws. Their
#'       meaning depends on the method and trait type, and they need not
#'       describe the spread among the returned datasets. They are
#'       descriptive, not Rubin's-rules pooled standard errors, and must not
#'       be used for downstream pooling.}
#'     \item{`draws_method`}{The method actually used, including the selected
#'       method when `draws_method = "auto"`.}
#'     \item{Diagnostic prediction outputs}{The `conformal_lower`,
#'       `conformal_upper`, `probabilities`, and `evaluation` components are
#'       returned for the conformal and MC-dropout routes, not the posterior
#'       route.}
#'     \item{`conformal_lower`, `conformal_upper`}{For diagnostic routes,
#'       lower and upper prediction-bound matrices when conformal scores are
#'       available. A bound matrix may contain `NA` for traits without scores;
#'       both components are `NULL` when no score object is available. See
#'       [predict.pigauto_fit()] for scale and trait-specific interpretation.}
#'     \item{`probabilities`}{For diagnostic routes, a named list of class
#'       probabilities and, for a `multi_proportion` trait when only one prediction run is returned,
#'       component proportions. See [predict.pigauto_fit()] for the per-type shapes.}
#'     \item{`evaluation`}{For diagnostic routes, validation- and test-set
#'       evaluation metrics
#'       from the underlying imputation fit. This is `NULL` when there are no
#'       test cells or when evaluation fails.}
#'     \item{Prediction row order}{On diagnostic routes, `se`, the bound
#'       matrices, and probability rows follow the fitted model's internal row
#'       order. `data$input_row_order[k]` gives the original input row placed
#'       at internal row `k`; `NA` marks a tree tip without an input row; use `order(data$input_row_order, na.last = NA)` to restore input-row order.
#'       `datasets` and `pooled_point` use original input row order. Posterior-
#'       route `se` uses original input row order.}
#'     \item{`mi_workflow`}{Method-dependent provenance. Prediction-diagnostic
#'       conformal and MC-dropout draws use `"pigauto_diagnostic_mi"`.
#'       Eligible posterior draws with parameter uncertainty use
#'       `"pigauto_posterior_mi_v1"` and can enter [with_imputations()] and
#'       [pool_mi()] under the documented posterior-route conditions.
#'       Posterior draws with `param_uncertainty = "none"` use
#'       `"pigauto_posterior_plugin_diagnostic"`: covariance matrices are
#'       fixed while trait means and missing cells are drawn, and these
#'       draws remain ineligible for downstream pooling.}
#'     \item{`imputed_mask`}{Logical matrix aligned to the input rows and
#'       trait columns; `TRUE` marks an originally missing target in a row
#'       included in the fit, not necessarily a successful fill. A marked
#'       cell can remain `NA` if no prediction was available. When
#'       `species_col` is supplied, its column is excluded.}
#'     \item{`fit`}{The underlying [`pigauto_fit`][fit_pigauto()]
#'       object, retained for diagnostics and calls to [predict()] on the
#'       fitted data. New-species prediction is not implemented.}
#'     \item{`data`}{The [`pigauto_data`][preprocess_traits()] object.}
#'     \item{`tree`}{The input phylogeny.}
#'     \item{`species_col`}{Passed-through species-column name or
#'       `NULL`.}
#'     \item{`posterior`}{`draws_method = "posterior"` only. A list with
#'       `cell_interval` (data.frame: `row` (row of `traits`), `trait`,
#'       `lower`, `upper`, `median`; 95% posterior predictive interval on
#'       the original scale), `diagnostics` (data.frame: `parameter`, `rhat`,
#'       `ess_bulk`, with attributes `"converged"`, `"n_extensions"` (the
#'       number of automatic extensions made) and `"sweeps_per_chain"` (the
#'       sweeps after burn-in per chain that the diagnostics use)), `params`
#'       (list: `Sigma_P` and `Sigma_E` as `K x K x draws` arrays, `lambda` and `mu`
#'       as `draws x K` matrices, on the latent scale), `converged`,
#'       `control`, `hyper` (priors), `start` (REML lambda and chain-1 start
#'       lambda, before clamping to \[0.02, 0.98\]), `draw_index` (kept
#'       sweeps used for the `m` datasets),
#'       `wall_s` and `sweeps` (all sweeps, burn-in included, summed over
#'       chains). For this method `fit` is `NULL`, `se` holds
#'       the posterior predictive SD of each imputed cell, the class is
#'       `c("pigauto_posterior_mi", "pigauto_mi", "list")` and
#'       `mi_workflow` is `"pigauto_posterior_mi_v1"`
#'       (`"pigauto_posterior_plugin_diagnostic"` with
#'       `posterior_control$param_uncertainty = "none"`, which
#'       [with_imputations()] and [pool_mi()] refuse).}
#'     \item{`posterior_improper`}{Only with
#'       `posterior_control$param_uncertainty = "both"` (validation only). A
#'       list with `datasets` (`m` data.frames drawn with the covariance
#'       matrices fixed at their posterior means, with the same missing-cell
#'       limits described above, from the same
#'       chain run as `datasets`), `cell_interval` (same columns as
#'       `posterior$cell_interval`), and the fixed `Sigma_P` and `Sigma_E`.
#'       Not for downstream inference: it ignores parameter uncertainty.}
#'   }
#'
#' @details
#' With the default \code{draws_method = "auto"}, eligible continuous-trait data
#' use posterior draws; other inputs use conformal prediction-diagnostic
#' draws. Check \code{result$draws_method} before downstream fitting.
#'
#' The conformal and MC-dropout draws do not condition on a declared
#' substantive analysis model.
#' Consequently, stochastic variation alone does not make them proper or
#' congenial multiple imputations. The analysis-aware backend requires the
#' analysis model before generating draws and dispatches only across its
#' documented supported model classes.
#'
#' **`draws_method = "conformal"`**: Run the model once. For a
#' continuous latent column standardized to mean zero and unit variance,
#' missing values are sampled as
#' \eqn{z_{ij}^{(k)} \sim \mathrm{N}(\hat z_{ij},\; (q_{ij}/1.96)^2)}.
#' Here \eqn{q_{ij}} is the available split-conformal score: the global
#' trait score or, with Mondrian calibration, the near/far score for cell
#' \eqn{i}. Other trait types use their type-specific latent representation
#' and decoding described below. Dividing the score by 1.96 is a pragmatic
#' Normal-scale construction,
#' not an inference consequence of a nominal held-out conformal diagnostic. For discrete traits (binary,
#' categorical) it uses Bernoulli / categorical draws from the estimated
#' probability vector. For \code{zi_count} the gate is Bernoulli from
#' P(nonzero) and the conditional magnitude is drawn on the log1p-z
#' latent using the conformal score (or the magnitude latent SE when
#' scores are unavailable) — not the reported SE of expected count. For
#' \code{multi_proportion} groups it draws the
#' K CLR latent columns with their BM latent SEs, projects back to
#' sum-zero CLR space, and decodes to the simplex.
#'
#' **`draws_method = "mc_dropout"`**: Add independent Gaussian perturbations
#' per latent cell, scaled by selected baseline SD. This returns `M` stochastic
#' draws; when the GNN is enabled, its network runs use dropout in training
#' mode. These are prediction-diagnostic draws, not joint phylogenetic
#' BM posterior draws or validated downstream-inference imputations. A
#' baseline perturbation can contribute variation when the GNN weight is zero,
#' but this does not guarantee non-zero variation.
#'
#' **`draws_method = "posterior"`**: see the "Posterior draws" section.
#'
#' Nakagawa & Freckleton (2008, 2011) provide ecological missing-data context.
#' Their full-text passages were not verified for a blanket recommendation
#' about this workflow; they do not establish validity of pigauto draws.
#'
#' @references
#' Rubin DB (1987). *Multiple Imputation for Nonresponse in Surveys.*
#' Wiley.
#'
#' Nakagawa S, Freckleton RP (2008). "Missing inaction: the dangers of
#' ignoring missing data." *Trends in Ecology & Evolution* 23(11):
#' 592-596.
#'
#' Gelman A (2006). "Prior distributions for variance parameters in
#' hierarchical models." *Bayesian Analysis* 1(3): 515-534.
#'
#' Hadfield JD (2010). "MCMC methods for multi-response generalized linear
#' mixed models: the MCMCglmm R package." *Journal of Statistical Software*
#' 33(2): 1-22.
#'
#' Hadfield JD, Nakagawa S (2010). "General quantitative genetic methods for
#' comparative biology: phylogenies, taxonomies and multi-trait models for
#' continuous and categorical characters." *Journal of Evolutionary Biology*
#' 23(3): 494-508.
#'
#' Vehtari A, Gelman A, Simpson D, Carpenter B, Buerkner P-C (2021).
#' "Rank-normalization, folding, and localization: an improved R-hat for
#' assessing convergence of MCMC." *Bayesian Analysis* 16(2): 667-718.
#'
#' Nakagawa S, Freckleton RP (2011). "Model averaging, missing data and
#' multiple imputation: a case study for behavioural ecology."
#' *Behavioral Ecology and Sociobiology* 65(1): 103-116.
#'
#' The references provide methodological context for priors, phylogenetic
#' models and MCMC diagnostics. They do not establish pigauto's exact prior
#' specification, sampler correctness or package-specific diagnostic
#' thresholds. The "Posterior draws" section describes the implementation
#' and retained campaign evidence separately.
#'
#' @section Posterior draws:
#' With `draws_method = "posterior"`, the latent (z-scored, optionally
#' log-transformed) traits follow the multivariate phylogenetic mixed model
#' \deqn{\begin{aligned}
#' \mathrm{vec}(Y) &\sim \mathrm{N}(\mathrm{vec}(1_n\mu^\top),\\
#' &\quad \Sigma_P \otimes R + \Sigma_E \otimes I_n),
#' \end{aligned}}
#' where \eqn{Y} is the \eqn{n}-species by \eqn{K}-trait matrix,
#' \eqn{\mu} is the vector of \eqn{K} trait means, and \eqn{\mathrm{vec}}
#' stacks matrix columns. Here \eqn{1_n} is an \eqn{n}-vector of ones,
#' \eqn{R} is the phylogenetic correlation matrix of the tree, and
#' \eqn{I_n} is the \eqn{n \times n} identity matrix. The model uses full
#' \eqn{K \times K} phylogenetic (\eqn{\Sigma_P}) and
#' residual (\eqn{\Sigma_E}) covariance matrices, with a flat prior on
#' \eqn{\mu}.
#' The implied Pagel's lambda of trait \eqn{k} is
#' \eqn{\Sigma_P[k,k] / (\Sigma_P[k,k] + \Sigma_E[k,k])}.
#'
#' The phylogenetic covariance uses a parameter-expanded inverse-Wishart
#' prior on its standardized covariance matrix and Normal priors on the
#' expansion parameters. The default residual
#' covariance prior uses a separation strategy: residual standard deviations
#' have half-Cauchy priors scaled by the observed latent-trait standard
#' deviations, and the full residual-correlation matrix has an LKJ(1) prior.
#' Before applying the numerical cutoff, the LKJ(1) prior does not give each
#' pairwise correlation a uniform distribution when there are more than two
#' traits. For numerical stability, the sampler gives zero prior density if
#' the smallest eigenvalue of the residual covariance matrix, standardized by
#' observed latent-trait standard deviations, is below 0.000001. In plain
#' language, on this standardized scale, variance along every unit-length
#' direction must be at least 0.000001. This cutoff narrows the prior support. The legacy
#' `posterior_control$residual_prior = "iw"` option instead uses an
#' inverse-Wishart prior on the residual covariance. Prior settings are
#' returned in `mi$posterior$hyper`.
#'
#' The sampler draws the phylogenetic effects, the trait means and the missing
#' cells as one block using the implementation's sparse phylogenetic
#' node-precision Cholesky factor, and updates the covariance matrices by
#' parameter-expanded Gibbs steps plus Metropolis moves with the
#' phylogenetic effects integrated out. Mixing is monitored with
#' rank-normalised split R-hat and bulk effective sample size (Vehtari et
#' al. 2021); `mi$posterior$diagnostics` reports them. Vehtari et al.
#' recommend R-hat below 1.01. Pigauto's R-hat cutoff of 1.05 is less strict
#' than the paper's recommendation; its bulk-ESS cutoff is 400. When any
#' R-hat is at least 1.05 or any ESS is at most 400, the chains are extended
#' automatically (`posterior_control$auto_extend` and `max_extend`), and a
#' warning is raised if the rule still fails after the last extension.
#' These diagnostics cover the monitored elements of `Sigma_P`, `Sigma_E`
#' and `lambda`; they do not establish adequate precision for every posterior
#' quantile or validate the sampler.
#'
#' Before fitting a downstream model, check
#' `attr(mi$posterior$diagnostics, "converged")`. If it is not `TRUE`, inspect
#' the per-parameter diagnostics and sampling controls, then refit and check
#' again. Do not interpret or pool the draws while the flag is false or
#' unavailable. Passing this package-specific convergence rule does not
#' establish calibrated downstream inference.
#'
#' **Evidence scope.** The earlier
#' [Rubin-study campaign](https://github.com/itchyshin/pigauto/blob/abf1229417fea75478205c7f7dfd7e96a6de09b2/docs/dev-log/arc/2026-10-02-rubin-pigauto-campaign.md)
#' used pigauto b565cad and subsequent separation-prior refits, 200 datasets
#' per cell, n = 100, 300 or 1000, lambda = 0.3, 0.7 or 1, trait correlation
#' 0 or 0.5, and 30% MCAR missingness. Its downstream targets were PGLS
#' slopes and phylogenetic correlations; the coverage claims above belong
#' to that study and distinguish the legacy IW from the separation prior.
#' The separate
#' [posterior acceptance sweep](https://github.com/itchyshin/pigauto/blob/main/docs/dev-log/mi-posterior/sep_validation/README.md)
#' used 40 regimes and its own gate rules. The later
#' [registered validation](https://github.com/itchyshin/pigauto/blob/da71711cdc6fcb587babaf4d5b323c4468cb4492/docs/dev-log/validation-20261018/scientific-report.md)
#' froze a different source and used the default separation prior. Its eight
#' posterior slope regimes used Brownian GLS, n = 300 or 1000, lambda = 0.5
#' or 1, trait correlation 0.7, 30% missingness under MCAR or phylogenetic MAR,
#' and 500 replicates per regime. Five failed and three were indeterminate;
#' empirical 95% coverage ranged from 86.2% to 95.2%. No inferential scenario
#' met all prespecified support criteria. These campaigns should be compared
#' within their stated models, priors, missingness and acceptance rules.
#' Bayesian properness under the stated model does not by itself establish
#' that an applied analysis is calibrated.
#'
#' The `m` datasets are posterior predictive draws spaced evenly across the
#' kept sweeps of all chains. Per-cell 95% intervals in
#' `mi$posterior$cell_interval` come from all kept sweeps (`keep_draws` of
#' them by default), never from the `m` datasets.
#'
#' These draws come from a linear-Gaussian model of the imputed traits on
#' the scale where they were imputed (the log scale for traits
#' log-transformed by `log_transform`). The documented software route permits
#' downstream fitting only under the stated eligibility conditions: analyses
#' must be linear in the imputed traits on that scale and use variables among
#' the imputed traits. This fitting eligibility does not establish model
#' compatibility or inferential performance across analyses or tested
#' regimes. In the registered validation, five posterior slope regimes
#' failed and three were indeterminate; see
#' [the registered inferential results](https://itchyshin.github.io/pigauto/articles/validation-results.html#inferential-results).
#' Each imputed trait must also have at least two observed values among the
#' rows being fitted; otherwise posterior mode stops and names the affected
#' traits. This minimum is a software requirement, not evidence that two
#' observations are enough for reliable estimation.
#' Not covered: covariates from outside the imputed traits, because the
#' imputation model does not contain them; nonlinear terms (such as squares)
#' or interactions among imputed traits; and analysing a log-transformed
#' trait on its raw scale. The GNN is not used,
#' and `gnn`, `epochs`, `missing_frac`, `lambda_mode` and other fitting
#' arguments are ignored (a message lists any that were supplied).
#' Non-continuous traits, multiple observations per species (or any
#' `species_col`), `covariates`, and input with no missing cells in the rows
#' of `traits` (tree tips absent from `traits` do not count) are errors.
#'
#' @section Optional safety floor:
#'   When \code{fit_pigauto()} is called with \code{safety_floor = TRUE}
#'   (opt-in; the default is \code{FALSE}), the 3-way blend
#'   \code{r_BM * BM + r_GNN * GNN + r_MEAN * MEAN} propagates through
#'   prediction-diagnostic draws through \code{predict.pigauto_fit()}.
#'   The posterior sampler uses its own model and does not use this blend.
#'   For \code{draws_method = "mc_dropout"}
#'   the mean term contributes no between-draw variance (it is a
#'   deterministic scalar per column); between-draw variance comes from the
#'   independent baseline perturbations and, when enabled, GNN-dropout terms
#'   only.  For \code{draws_method = "conformal"} the blend centre is the
#'   3-way prediction and conformal scores remain calibrated on the
#'   blended residuals.
#'
#' @seealso [impute()] for point imputation and [multi_impute_analysis()]
#'   for the narrow analysis-aware inferential backend.
#'
#' @examples
#' \donttest{
#' library(pigauto)
#' data(avonet300, tree300)
#' tree <- ape::keep.tip(tree300, tree300$tip.label[seq_len(30L)])
#' df <- avonet300[match(tree$tip.label, avonet300$Species_Key),
#'                 c("Mass", "Wing.Length"), drop = FALSE]
#' rownames(df) <- tree$tip.label
#' df$Mass[seq_len(3L)] <- NA_real_
#' mi <- multi_impute(df, tree, m = 2L, draws_method = "conformal",
#'                    epochs = 5L, verbose = FALSE)
#' print(mi)
#' lapply(mi$datasets, head)
#' }
#'
#' @export
multi_impute <- function(traits, tree, m = 100L,
                         draws_method = c("auto", "conformal", "mc_dropout",
                                          "posterior"),
                         species_col = NULL,
                         trait_types = NULL,
                               multi_proportion_groups = NULL,
                         log_transform = TRUE,
                         missing_frac = 0.25,
                         covariates = NULL,
                         epochs = 2000L, verbose = TRUE, seed = NULL,
                         gnn = FALSE,
                         lambda_mode = c("estimate", "fixed_1", "cv", "bayes"),
                         posterior_control = list(),
                         ..., ordinal_levels = NULL) {

  # Recorded before match.arg() reassigns lambda_mode (used only by
  # draws_method = "posterior" to report ignored fitting arguments).
  supplied_fit_args <- c(if (!missing(gnn)) "gnn",
                         if (!missing(epochs)) "epochs",
                         if (!missing(missing_frac)) "missing_frac",
                         if (!missing(lambda_mode)) "lambda_mode")
  draws_method <- match.arg(draws_method)
  lambda_mode <- match.arg(lambda_mode)
  # Coerce once, before route resolution and the per-draw impute() calls,
  # so every downstream consumer sees the ordered factors.
  traits <- .apply_ordinal_levels(traits, ordinal_levels)
  if (draws_method == "auto") {
    draws_method <- .mi_resolve_draws_auto(
      traits = traits, tree = tree, species_col = species_col,
      trait_types = trait_types,
      multi_proportion_groups = multi_proportion_groups,
      log_transform = log_transform, covariates = covariates,
      verbose = verbose)
  }
  m <- as.integer(m)
  if (!is.finite(m) || m < 2L) {
    stop("`m` must be an integer >= 2 (stochastic diagnostics need at least ",
         "two draws). Got m = ", m, ".", call. = FALSE)
  }

  if (draws_method == "posterior") {
    # ---- Posterior: Bayesian phylogenetic mixed model (R/mi_posterior.R) ----
    # No GNN is fitted; arguments that only configure the GNN fit are
    # reported as ignored.
    ignored <- c(supplied_fit_args, names(list(...)))
    return(.multi_impute_posterior(
      traits = traits, tree = tree, m = m, species_col = species_col,
      trait_types = trait_types,
      multi_proportion_groups = multi_proportion_groups,
      log_transform = log_transform, covariates = covariates,
      verbose = verbose, seed = seed, control = posterior_control,
      ignored_args = ignored))
  }

  if (draws_method == "mc_dropout") {
    # gnn = FALSE: there is no GNN dropout. predict() adds independent
    # Gaussian perturbations per latent cell using selected baseline SD;
    # these are prediction diagnostics, not joint phylogenetic BM posterior
    # draws or validated multiple imputations.
    if (isFALSE(gnn)) {
      message("gnn = FALSE: mc_dropout uses independent latent-cell baseline-SD perturbations (no GNN dropout); these are not joint phylogenetic BM posterior draws.")
    }
    # ---- MC dropout: M stochastic GNN forward passes (training mode) --------
    # Run the pipeline with n_imputations = m so predict() runs the model M
    # times with dropout active. Each pass yields a different latent matrix;
    # the M decoded data.frames are returned in pred$imputed_datasets.
    res <- impute(
      traits        = traits,
      tree          = tree,
      species_col   = species_col,
      trait_types   = trait_types,
      multi_proportion_groups = multi_proportion_groups,
      log_transform = log_transform,
      missing_frac  = missing_frac,
      n_imputations = m,
      covariates    = covariates,
      epochs        = as.integer(epochs),
      verbose       = verbose,
      seed          = if (is.null(seed)) NULL else as.integer(seed),
      gnn           = gnn,
      lambda_mode   = lambda_mode,
      ...
    )

    pred <- res$prediction
    if (is.null(pred$imputed_datasets) || length(pred$imputed_datasets) != m) {
      stop("predict.pigauto_fit() did not return ", m,
           " imputed datasets. This is an internal error -- please report.",
           call. = FALSE)
    }
    # Pass `input_row_order` so build_completed re-aligns predictions back
    # to the user's input row order (multi-obs reordering fix, 2026-04-26).
    input_row_order <- res$data$input_row_order
    datasets <- lapply(pred$imputed_datasets, function(imp_df) {
      build_completed(traits, imp_df, species_col,
                       input_row_order = input_row_order)$completed
    })

  } else {
    # ---- Conformal: single pass + conformal-width Normal sampling -----------
    # Run once to get point estimates, conformal scores, and probabilities.
    res <- impute(
      traits        = traits,
      tree          = tree,
      species_col   = species_col,
      trait_types   = trait_types,
      multi_proportion_groups = multi_proportion_groups,
      log_transform = log_transform,
      missing_frac  = missing_frac,
      n_imputations = 1L,
      covariates    = covariates,
      epochs        = as.integer(epochs),
      verbose       = verbose,
      seed          = if (is.null(seed)) NULL else as.integer(seed),
      gnn           = gnn,
      lambda_mode   = lambda_mode,
      ...
    )

    pred      <- res$prediction
    trait_map <- res$fit$trait_map
    imask     <- res$imputed_mask

    # Mondrian (2026-09-23): when the fit was calibrated with
    # conformal_method = "mondrian", draws below use the per-cell
    # near/far stratum score instead of the single global conformal
    # score. mondrian_cell_scores() (R/predict_pigauto.R) is the same
    # helper predict.pigauto_fit() uses for its conformal intervals, so
    # the two are identical in latent scale and stratum assignment. NULL
    # for any other conformal_method (split / bootstrap / none), in which
    # case .sample_conformal_draw() falls back to the global score
    # unchanged.
    cell_scores <- if (identical(res$fit$conformal_method, "mondrian")) {
      mondrian_cell_scores(res$fit, res$fit$graph$D_sq, trait_map,
                            nrow(pred$imputed_latent))
    } else {
      NULL
    }

    input_row_order <- res$data$input_row_order
    # `imask` is in user-input row order (built by build_completed from
    # the original traits data.frame).  But pred$imputed / pred$se /
    # pred$probabilities are in INTERNAL (tree-tip) order from the
    # model.  .sample_conformal_draw (called inside .conformal_draws)
    # therefore maps input-order mask indices to internal-order before
    # perturbing imp; otherwise it perturbs the wrong cells and
    # build_completed re-aligns the unperturbed (internal) values back
    # into the user's missing cells, producing zero between-imputation
    # variance.  See adversarial_review_opus.md (HIGH severity finding
    # C.1).  P1-11: this sampling block is shared with
    # multi_impute_trees(draws_method = "conformal") via .conformal_draws().
    datasets <- .conformal_draws(traits, pred, imask, trait_map, m,
                                 species_col = species_col, seed = seed,
                                 input_row_order = input_row_order,
                                 mondrian_scores = cell_scores)
  }

  structure(
    list(
      datasets        = datasets,
      m               = m,
      draws_method    = draws_method,
      pooled_point    = res$completed,
      se              = pred$se,
      # Exposed for downstream coverage / interval-width / Brier analyses
      # without having to round-trip through `mi$fit` + a fresh predict().
      # `conformal_lower` / `conformal_upper` are the trait-level 95%
      # prediction intervals (back-transformed to user scale when the
      # trait was log-transformed); `probabilities` is the per-discrete-
      # trait probability list (binary: numeric vector, categorical: K-
      # column matrix). See predict.pigauto_fit() for shape and scale
      # conventions. Either may be NULL when the underlying conformal
      # scores were unavailable (e.g. zero validation cells for a trait).
      conformal_lower = pred$conformal_lower,
      conformal_upper = pred$conformal_upper,
      probabilities   = pred$probabilities,
      imputed_mask    = res$imputed_mask,
      fit             = res$fit,
      data            = res$data,
      tree            = tree,
      species_col     = species_col,
      mi_workflow     = "pigauto_diagnostic_mi",
      evaluation      = res$evaluation
    ),
    class = c("pigauto_diagnostic_mi", "pigauto_mi", "list")
  )
}


# ---- Internal: M conformal-width completed datasets from one prediction ----
# Shared sampling block (P1-11): given a single-pass prediction (`pred`),
# draws `m` conformal-width stochastic completions and re-aligns each to
# the user's input row order via build_completed(). Both multi_impute()
# (draws_method = "conformal") and multi_impute_trees()
# (draws_method = "conformal") call this so the sampling mechanism is
# identical in both places -- only how `pred` / `imputed_mask` / `trait_map`
# are obtained differs (single-tree impute() vs per-tree impute() /
# predict()).
#
# @param traits           original traits data.frame (user input).
# @param pred              a `pigauto_pred` object from a single-pass
#                          (`n_imputations = 1`) predict() / impute() call.
# @param imputed_mask      logical matrix in user-input row order, TRUE for
#                          originally-missing cells (e.g. `res$imputed_mask`).
# @param trait_map         trait map from the fit that produced `pred`.
# @param m                 integer, number of draws to generate.
# @param species_col       character or NULL, forwarded to build_completed().
# @param seed              optional integer base seed; draw `i` uses
#                          `seed + i`. NULL uses the current RNG stream.
# @param input_row_order    forwarded to .sample_conformal_draw() /
#                          build_completed() for row re-alignment.
# @return list of `m` completed data.frames.
.conformal_draws <- function(traits, pred, imputed_mask, trait_map, m,
                             species_col = NULL, seed = NULL,
                             input_row_order = NULL,
                             mondrian_scores = NULL) {
  lapply(seq_len(m), function(i) {
    imp_df <- .sample_conformal_draw(
      pred, imputed_mask, trait_map,
      seed_i = if (is.null(seed)) NULL else as.integer(seed) + i,
      input_row_order = input_row_order,
      mondrian_scores = mondrian_scores
    )
    build_completed(traits, imp_df, species_col,
                    input_row_order = input_row_order)$completed
  })
}


# ---- Internal: one conformal-width draw -------------------------------------
# Samples missing cells from N(mu, conformal_score / 1.96) for continuous
# types (on the appropriate transformed scale), and from Bernoulli /
# Categorical for discrete types. zi_count: Bernoulli gate + Normal draw
# on the magnitude log1p-z latent (conformal score or se_latent mag),
# never pred$se of E[X]. Falls back to BM / latent SE when the conformal
# score is not available for a trait.
#
# Converting a conformal half-width to a Normal SD via /1.96 is already a
# heuristic (see multi_impute()'s roxygen). When `mondrian_scores` is
# supplied (fit calibrated with conformal_method = "mondrian"), that same
# /1.96 conversion is applied per cell to a score that is itself a coarse
# near/far stratum step function (mondrian_cell_scores() /
# mondrian_locality() in R/predict_pigauto.R and R/fit_helpers.R), not a
# smooth function of phylogenetic distance -- two compounding
# approximations, not one. NULL (any non-Mondrian conformal_method) keeps
# the single global score, unchanged from before this parameter existed.
.sample_conformal_draw <- function(pred, imputed_mask, trait_map, seed_i,
                                    input_row_order = NULL,
                                    mondrian_scores = NULL) {
  if (!is.null(seed_i)) set.seed(seed_i)
  imp    <- pred$imputed
  probs  <- pred$probabilities
  cscores <- pred$conformal_scores  # named; NA for binary/categorical

  # Build input-row -> internal-row index map.  `imputed_mask` rows are in
  # user-input order; `pred$imputed` / `pred$se` / `pred$probabilities` are
  # in internal (tree-tip) order.  `input_row_order[k] = i` means internal
  # row k holds original input row i, so the inverse map is over the full
  # input mask: `match(seq_len(nrow(imputed_mask)), input_row_order)`.  This
  # preserves NA entries for data-only rows after filtering. When NULL or
  # identity, internal order == input order and the conversion is a no-op.
  input_to_internal <- if (!is.null(input_row_order)) {
    match(seq_len(nrow(imputed_mask)), input_row_order)
  } else NULL

  to_internal <- function(rows_input) {
    if (is.null(input_to_internal)) return(rows_input)
    out <- input_to_internal[rows_input]
    out[!is.na(out)]    # drop input rows with no internal counterpart
  }

  for (tm in trait_map) {
    nm   <- tm$name
    if (tm$type == "multi_proportion") {
      comp_cols <- if (!is.null(tm$input_cols)) tm$input_cols else tm$levels
      if (!all(comp_cols %in% names(imp))) next
      if (!all(comp_cols %in% colnames(imputed_mask))) next

      missing_rows <- rowSums(imputed_mask[, comp_cols, drop = FALSE]) > 0
      rows <- to_internal(which(missing_rows))
      if (length(rows) == 0L) next

      lc <- tm$latent_cols
      latent_mu <- pred$imputed_latent[rows, lc, drop = FALSE]
      s_latent <- pred$se_latent[rows, lc, drop = FALSE]
      s_latent[!is.finite(s_latent)] <- 0

      latent_draw <- latent_mu +
        matrix(stats::rnorm(length(rows) * length(lc)), nrow = length(rows)) *
          s_latent

      clr_mat <- latent_draw
      for (k in seq_along(lc)) {
        clr_mat[, k] <- clr_mat[, k] * tm$sd[k] + tm$mean[k]
      }
      clr_mat <- clr_mat - rowMeans(clr_mat)
      prop_mat <- softmax_rows(clr_mat)

      for (k in seq_along(comp_cols)) {
        imp[[comp_cols[k]]][rows] <- prop_mat[, k]
      }
      next
    }

    if (!(nm %in% names(imp))) next
    if (!(nm %in% colnames(imputed_mask))) next
    # Map input-order mask indices to internal-order indices for indexing
    # into pred$imputed / pred$se / pred$probabilities.
    rows <- to_internal(which(imputed_mask[, nm]))
    if (length(rows) == 0L) next
    N    <- length(rows)

    # Conformal half-width → approximate 1-sigma SD. Per-cell (vector,
    # one value per row) when this fit used Mondrian conformal and the
    # trait has a populated stratum score; otherwise the single global
    # score (scalar), recycled by rnorm() exactly as before.
    cs <- if (!is.null(cscores) && nm %in% names(cscores) &&
               is.finite(cscores[nm])) {
            if (!is.null(mondrian_scores) &&
                nm %in% colnames(mondrian_scores$scores) &&
                !is.na(mondrian_scores$scores[1L, nm])) {
              mondrian_scores$scores[rows, nm] / 1.96
            } else {
              cscores[nm] / 1.96
            }
          } else {
            NULL
          }

    if (tm$type == "continuous") {
      mu       <- imp[[nm]][rows]           # original-scale point estimate
      # s_latent = SE in z-score (latent) space
      s_latent <- if (!is.null(cs)) cs else pred$se[rows, nm] / tm$sd
      if (isTRUE(tm$log_transform)) {
        # Draw on the z-score scale then back-transform to avoid the
        # delta-method approximation error (s_orig/mu is tiny when mu >> 1).
        z_mu  <- (log(pmax(mu, .Machine$double.eps)) - tm$mean) / tm$sd
        z_drw <- rnorm(N, z_mu, s_latent)
        imp[[nm]][rows] <- exp(z_drw * tm$sd + tm$mean)
      } else {
        # Non-log: draw directly in original scale (s_orig = s_latent * sd)
        imp[[nm]][rows] <- rnorm(N, mu, s_latent * tm$sd)
      }

    } else if (tm$type == "count") {
      # log1p transform: draw on z-score scale, back via expm1
      mu       <- as.numeric(imp[[nm]][rows])
      s_latent <- if (!is.null(cs)) cs else pred$se[rows, nm] / tm$sd
      z_mu  <- (log1p(pmax(mu, 0)) - tm$mean) / tm$sd
      z_drw <- rnorm(N, z_mu, s_latent)
      draw  <- pmax(round(expm1(z_drw * tm$sd + tm$mean)), 0L)
      imp[[nm]][rows] <- as.integer(draw)

    } else if (tm$type == "ordinal") {
      K        <- length(tm$levels)
      int_mu   <- as.integer(imp[[nm]][rows]) - 1L
      s_latent <- if (!is.null(cs)) cs else pred$se[rows, nm] / tm$sd
      s_orig   <- s_latent * tm$sd   # ordinal is integer-scale, no transform
      draw_i   <- pmin(pmax(round(rnorm(N, int_mu, s_orig)), 0L), K - 1L)
      imp[[nm]][rows] <- factor(tm$levels[as.integer(draw_i) + 1L],
                                levels = tm$levels, ordered = TRUE)

    } else if (tm$type == "proportion") {
      # logit transform: draw on z-score scale, back via plogis
      mu       <- imp[[nm]][rows]
      s_latent <- if (!is.null(cs)) cs else pred$se[rows, nm] / tm$sd
      p_mu     <- pmin(pmax(mu, 1e-6), 1 - 1e-6)
      logit_mu <- stats::qlogis(p_mu)
      z_mu     <- (logit_mu - tm$mean) / tm$sd
      z_drw    <- rnorm(N, z_mu, s_latent)
      imp[[nm]][rows] <- stats::plogis(z_drw * tm$sd + tm$mean)

    } else if (tm$type == "binary") {
      p   <- probs[[nm]][rows]
      idx <- rbinom(N, 1L, pmin(pmax(p, 0), 1)) + 1L
      imp[[nm]][rows] <- factor(tm$levels[idx], levels = tm$levels)

    } else if (tm$type == "categorical") {
      pm  <- probs[[nm]][rows, , drop = FALSE]
      idx <- apply(pm, 1L, function(p) {
        p <- pmax(p, 0); p <- p / sum(p)
        sample.int(length(p), 1L, prob = p)
      })
      imp[[nm]][rows] <- factor(tm$levels[idx], levels = tm$levels)

    } else if (tm$type == "zi_count") {
      # Gate: Bernoulli from P(nonzero). Magnitude: log1p-z latent draw
      # using the conformal score (or se_latent of the mag column). Do
      # not use pred$se — that slot is the delta-method SE of E[X].
      p_nz <- pmin(pmax(probs[[nm]][rows], 0), 1)
      gate <- stats::rbinom(N, 1L, p_nz)
      lc   <- tm$latent_cols
      z_mu <- as.numeric(pred$imputed_latent[rows, lc[2L]])
      if (!is.null(cs)) {
        s_latent <- cs
      } else if (!is.null(pred$se_latent) &&
                 ncol(pred$se_latent) >= lc[2L]) {
        s_latent <- pred$se_latent[rows, lc[2L]]
        s_latent[!is.finite(s_latent)] <- 0
      } else {
        s_latent <- 0
      }
      z_drw  <- stats::rnorm(N, z_mu, s_latent)
      draw_c <- as.integer(pmax(round(expm1(z_drw * tm$sd + tm$mean)), 0L))
      draw_c[gate == 0L] <- 0L
      imp[[nm]][rows] <- draw_c
    }
  }
  imp
}


#' @rdname multi_impute
#' @param x A stochastic-completion or posterior MI object.
#' @section Printing:
#' Prints diagnostic or posterior/convergence summaries. Cell counts refer to
#' targeted cells; a targeted cell can remain missing if a prediction is
#' unavailable. Displaying an object does not authorize downstream pooling.
#' The `...` argument is currently unused.
#' @return The print method returns `x` invisibly.
#' @export
print.pigauto_mi <- function(x, ...) {
  n_sp  <- length(x$data$species_names)
  traits <- vapply(x$data$trait_map, "[[", character(1), "name")
  p <- length(traits)

  total_cells <- length(x$imputed_mask)
  n_imp_cells <- sum(x$imputed_mask)
  pct <- if (total_cells > 0) 100 * n_imp_cells / total_cells else 0

  if (identical(x$draws_method, "posterior")) {
    return(.print_posterior_mi(x, n_sp, traits, p, n_imp_cells, total_cells,
                               pct))
  }
  cat("pigauto experimental stochastic completion diagnostics\n")
  method_label <- switch(x$draws_method %||% "mc_dropout",
    mc_dropout = "MC dropout",
    conformal  = "conformal-width sampling",
    x$draws_method
  )
  cat(sprintf("  M        : %d completion draws (%s)\n", x$m, method_label))
  cat(sprintf("  Species  : %d\n", n_sp))
  cat(sprintf("  Traits   : %d -- %s\n", p,
              paste(traits, collapse = ", ")))
  cat(sprintf("  Cells    : %d targeted / %d total (%.1f%%)\n",
              n_imp_cells, total_cells, pct))

  cat("\n  Access diagnostic draws:  mi$datasets[[i]]\n")
  cat("  Downstream inference:     unsupported for these draws\n")
  cat("  Analysis-aware MI:        multi_impute_analysis(...)\n")
  invisible(x)
}


# ---- Internal: print method body for draws_method = "posterior" ------------
.print_posterior_mi <- function(x, n_sp, traits, p, n_imp_cells, total_cells,
                                pct) {
  post <- x$posterior
  ctl <- post$control
  dg <- post$diagnostics
  cat("pigauto posterior multiple imputation (phylogenetic mixed model)\n")
  cat(sprintf("  M        : %d completed datasets (posterior predictive)\n",
              x$m))
  cat(sprintf("  Species  : %d\n", n_sp))
  cat(sprintf("  Traits   : %d -- %s\n", p, paste(traits, collapse = ", ")))
  cat(sprintf("  Cells    : %d targeted / %d total (%.1f%%)\n",
              n_imp_cells, total_cells, pct))
  # After k automatic extensions each chain ran (k + 1) * n_iter sweeps
  # after burn-in and the kept draws are every thin * (k + 1)-th sweep.
  n_ext <- attr(dg, "n_extensions") %||% 0L
  cat(sprintf("  MCMC     : %d chains x (%d burn-in + %d sweeps, thin %d)%s%s\n",
              ctl$n_chains, ctl$burnin, (n_ext + 1L) * ctl$n_iter,
              (n_ext + 1L) * ctl$thin,
              if (n_ext > 0L) sprintf(", extended %d time(s)", n_ext) else "",
              switch(ctl$param_uncertainty,
                     none = "; covariances fixed (plug-in mode)",
                     both = "; plug-in draws also in mi$posterior_improper",
                     "")))
  lam <- colMeans(post$params$lambda)
  cat(sprintf("  lambda   : %s (%s)\n",
              paste(sprintf("%s = %.2f", names(lam), lam), collapse = ", "),
              switch(ctl$param_uncertainty,
                     none = "at the posterior-mean covariances",
                     "posterior means")))
  cat(sprintf(paste0("  Converged: %s (max R-hat %.3f, needs < 1.05; ",
                     "min bulk ESS %.0f, needs > 400)\n"),
              if (isTRUE(post$converged)) "yes" else "NO",
              max(dg$rhat, na.rm = TRUE), min(dg$ess_bulk, na.rm = TRUE)))
  if (!isTRUE(post$converged)) {
    cat("             Increase posterior_control$n_iter before using these draws.\n")
  }
  cat("\n  Access datasets:          mi$datasets[[i]]\n")
  cat("  Per-cell 95% intervals:   mi$posterior$cell_interval\n")
  if (identical(x$mi_workflow, "pigauto_posterior_plugin_diagnostic")) {
    cat("  Downstream inference:     unsupported for these draws (plug-in\n")
    cat("                            validation mode; rerun with\n")
    cat("                            param_uncertainty = \"full\")\n")
  } else {
    cat("  Downstream inference:     with_imputations(mi, f) then pool_mi()\n")
  }
  invisible(x)
}


# ---- Internal: resolve draws_method = "auto" --------------------------------
# "posterior" when the data fit the posterior route's input contract
# (.multi_impute_posterior() in R/mi_posterior.R: continuous traits only, one
# row per species, no covariates); otherwise "conformal", with a message
# saying why and that those draws cannot be pooled. Missing-cell and tree
# checks are left to the chosen route so its own error messages apply.
.mi_resolve_draws_auto <- function(traits, tree, species_col, trait_types,
                                   multi_proportion_groups, log_transform,
                                   covariates, verbose = TRUE) {
  reason <- NULL
  if (!is.null(covariates)) {
    reason <- "`covariates` were supplied"
  } else if (!is.null(species_col)) {
    reason <- "`species_col` was supplied (multiple observations per species)"
  } else if (!is.null(multi_proportion_groups)) {
    reason <- "`multi_proportion_groups` were supplied"
  } else {
    data <- suppressMessages(preprocess_traits(
      traits, tree, trait_types = trait_types,
      multi_proportion_groups = multi_proportion_groups,
      log_transform = log_transform))
    types <- vapply(data$trait_map, `[[`, character(1), "type")
    names(types) <- vapply(data$trait_map, `[[`, character(1), "name")
    bad <- types[types != "continuous"]
    if (length(bad)) {
      reason <- paste0("some traits are not continuous (",
                       paste(sprintf("%s: %s", names(bad), bad),
                             collapse = ", "), ")")
    }
  }
  if (is.null(reason)) {
    if (verbose) {
      message("draws_method = \"auto\": all traits are continuous and the ",
              "supplied options meet the input conditions for ",
              "\"posterior\" draws. This does not establish downstream ",
              "inferential validity; see ?multi_impute. The sampler can take ",
              "several minutes.")
    }
    return("posterior")
  }
  message("draws_method = \"auto\": using \"conformal\" because ", reason,
          ". These draws show the spread of plausible values but are not ",
          "proper multiple imputations; with_imputations() and pool_mi() ",
          "refuse them. See ?multi_impute.")
  "conformal"
}
