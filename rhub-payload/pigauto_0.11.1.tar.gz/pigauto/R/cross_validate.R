#' k-fold cross-validation for pigauto trait imputation
#'
#' Evaluates trait-imputation performance by rotating observed cells within
#' each trait through k test folds. Folds do not hold out whole species or
#' clades, and they are not stratified by outcome class. Returns per-fold
#' and aggregated metrics.
#'
#' @param data pigauto_data object (output of \code{\link{preprocess_traits}}).
#' @param tree phylo object.
#' @param k integer.  Number of folds (default 5).
#' @param seeds optional integer vector. Seeds for replicate runs. The default
#'   \code{NULL} performs one run using the current RNG stream.
#' @param epochs integer.  Training epochs per fold (default 500).
#' @param verbose logical.  Print progress (default TRUE).
#' @param ... Additional arguments passed to \code{\link{fit_pigauto}}
#'   (e.g. \code{hidden_dim}, \code{k_eigen}, \code{use_attention}).
#' @details
#' \code{cross_validate()} precomputes one graph shared across folds and uses
#' \code{k_eigen = 8L} for that graph when \code{k_eigen} is omitted. An
#' explicit \code{k_eigen} is used for the shared graph and forwarded to
#' \code{fit_pigauto()}. Folds divide observed cells within each trait; they
#' do not hold out whole species or clades or stratify by outcome class.
#' Interpret each metric on its documented scale in
#' \code{\link{evaluate_imputation}}; continuous and count RMSE use latent
#' scales. Conformal coverage is calculated separately after predictions are
#' decoded.
#' @return A list of class \code{"pigauto_cv"} with:
#'   \describe{
#'     \item{results}{Data.frame with columns: fold, rep, trait, type,
#'       metric, value.}
#'     \item{summary}{Data.frame with mean and sd across folds/reps for
#'       each trait + metric.}
#'     \item{conformal_coverage}{Data.frame of coverage per trait across
#'       folds (if available).}
#'     \item{k}{Number of folds.}
#'     \item{n_reps}{Number of replicates.}
#'   }
#' @examples
#' \donttest{
#' data(avonet300, tree300, package = "pigauto")
#' tree <- ape::keep.tip(tree300, tree300$tip.label[seq_len(12L)])
#' traits <- avonet300[match(tree$tip.label, avonet300$Species_Key),
#'                      c("Mass", "Wing.Length"), drop = FALSE]
#' rownames(traits) <- tree$tip.label
#' cv <- cross_validate(preprocess_traits(traits, tree), tree, k = 3L,
#'                      seeds = 1L, epochs = 1L, verbose = FALSE,
#'                      k_eigen = 4L, hidden_dim = 8L,
#'                      use_transformer_blocks = FALSE)
#' print(cv)
#' summary(cv)
#' }
#' @export
cross_validate <- function(data, tree, k = 5L, seeds = NULL,
                           epochs = 500L, verbose = TRUE, ...) {
  if (!inherits(data, "pigauto_data")) {
    stop("'data' must be a pigauto_data object (output of preprocess_traits).")
  }
  if (!inherits(tree, "phylo")) stop("'tree' must be a phylo object.")
  k <- as.integer(k)
  if (k < 2L) stop("'k' must be >= 2.")
  if (is.null(seeds)) {
    seeds <- list(NULL)
  } else {
    if (!is.numeric(seeds) || anyNA(seeds) || any(!is.finite(seeds))) {
      stop("`seeds` must be NULL or a finite numeric vector.", call. = FALSE)
    }
    seeds <- as.list(as.integer(seeds))
  }

  X_scaled  <- data$X_scaled
  trait_map <- data$trait_map
  n         <- nrow(X_scaled)
  p         <- ncol(X_scaled)

  # Pre-compute graph (depends only on tree, reuse across all folds)
  dots <- list(...)
  k_eigen <- dots$k_eigen %||% 8L
  if (verbose) message("Building phylogenetic graph (reused across folds)...")
  graph <- build_phylo_graph(tree, k_eigen = k_eigen)

  # Collect per-fold results

  all_results   <- list()
  all_conformal <- list()

  for (rep_i in seq_along(seeds)) {
    seed <- seeds[[rep_i]]

    # Create k non-overlapping folds from observed cells
    folds <- make_cv_folds(X_scaled, k, seed, trait_map)

    for (fold_i in seq_len(k)) {
      if (verbose) {
        message(sprintf("Rep %d/%d, Fold %d/%d%s...",
                        rep_i, length(seeds), fold_i, k,
                        if (is.null(seed)) "" else paste0(" (seed=", seed, ")")))
      }

      # Build splits: fold_i = test, fold_i+1 (mod k) = val, rest = train
      val_fold <- ((fold_i %% k) + 1L)  # next fold wraps around
      test_idx <- folds[[fold_i]]
      val_idx  <- folds[[val_fold]]

      splits <- list(
        val_idx  = val_idx,
        test_idx = test_idx,
        n        = n,
        p        = p
      )

      # Fit pigauto for this fold
      fit <- fit_pigauto(
        data    = data,
        tree    = tree,
        splits  = splits,
        graph   = graph,
        epochs  = as.integer(epochs),
        seed    = seed,
        verbose = FALSE,
        ...
      )

      # Predict on test fold with validation/test cells hidden from DAE
      # context, matching the held-out input used during fit/calibration.
      pred <- predict(fit, return_se = TRUE,
                      .mask_observed_idx = c(splits$val_idx, splits$test_idx))

      # Evaluate using evaluate_imputation (test split)
      eval_df <- evaluate_imputation(
        pred   = pred,
        truth  = X_scaled,
        splits = splits
      )

      # Keep only test-set rows
      eval_test <- eval_df[eval_df$split == "test", , drop = FALSE]

      if (nrow(eval_test) > 0L) {
        # Pivot to long format: one row per (fold, rep, trait, type, metric)
        fold_results <- pivot_eval_to_long(eval_test, fold_i, rep_i)
        all_results[[length(all_results) + 1L]] <- fold_results
      }

      # Conformal coverage (if available)
      if (!is.null(fit$conformal_scores) && !is.null(trait_map)) {
        cov_df <- compute_conformal_coverage_fold(
          pred, X_scaled, splits$test_idx, trait_map, fold_i, rep_i
        )
        if (!is.null(cov_df)) {
          all_conformal[[length(all_conformal) + 1L]] <- cov_df
        }
      }
    }
  }

  # Combine results
  if (length(all_results) == 0L) {
    results <- data.frame(
      fold = integer(0), rep = integer(0), trait = character(0),
      type = character(0), metric = character(0), value = double(0),
      stringsAsFactors = FALSE
    )
  } else {
    results <- do.call(rbind, all_results)
    rownames(results) <- NULL
  }

  # Aggregate: mean and sd per trait + metric
  summary_df <- aggregate_cv_results(results)

  # Conformal coverage
  conformal_coverage <- NULL
  if (length(all_conformal) > 0L) {
    conformal_coverage <- do.call(rbind, all_conformal)
    rownames(conformal_coverage) <- NULL
  }

  structure(
    list(
      results            = results,
      summary            = summary_df,
      conformal_coverage = conformal_coverage,
      k                  = k,
      n_reps             = length(seeds)
    ),
    class = "pigauto_cv"
  )
}


# ---- Internal: create k non-overlapping folds from observed cells -----------
#
# For each trait, the observed cells are randomly assigned to k folds.
# This ensures every fold has cells from every trait (when possible).
# Returns a list of k integer vectors (linear column-major indices into
# the n x p matrix).

make_cv_folds <- function(X_scaled, k, seed, trait_map = NULL) {
  if (!is.null(seed)) set.seed(seed)
  n <- nrow(X_scaled)
  p <- ncol(X_scaled)

  if (!is.null(trait_map)) {
    # Trait-level folding: assign observed (species, trait) cells to folds,
    # then expand to latent indices.
    n_traits <- length(trait_map)
    folds_latent <- vector("list", k)
    for (i in seq_len(k)) folds_latent[[i]] <- integer(0)

    for (ti in seq_along(trait_map)) {
      tm <- trait_map[[ti]]
      lc <- tm$latent_cols

      # Observed rows for this trait (check first latent column)
      obs_rows <- which(!is.na(X_scaled[, lc[1]]))
      if (length(obs_rows) == 0L) next

      # Randomly assign observed rows to folds
      fold_assign <- sample(rep(seq_len(k), length.out = length(obs_rows)))

      for (fi in seq_len(k)) {
        rows_fi <- obs_rows[fold_assign == fi]
        if (length(rows_fi) == 0L) next
        # Expand to latent column indices (column-major)
        for (lj in lc) {
          folds_latent[[fi]] <- c(folds_latent[[fi]],
                                  rows_fi + (lj - 1L) * n)
        }
      }
    }
    return(folds_latent)
  }

  # Fallback: no trait_map, fold at individual cell level
  observed <- which(!is.na(X_scaled))
  if (length(observed) == 0L) {
    stop("No observed cells in X_scaled.")
  }
  fold_assign <- sample(rep(seq_len(k), length.out = length(observed)))
  lapply(seq_len(k), function(i) observed[fold_assign == i])
}


# ---- Internal: pivot evaluate_imputation output to long format ---------------

pivot_eval_to_long <- function(eval_df, fold, rep) {
  metric_cols <- c("rmse", "pearson_r", "coverage_95", "mae",
                   "spearman_rho", "accuracy", "brier")
  rows <- list()

  for (i in seq_len(nrow(eval_df))) {
    for (mc in metric_cols) {
      val <- eval_df[[mc]][i]
      if (!is.na(val)) {
        rows[[length(rows) + 1L]] <- data.frame(
          fold   = fold,
          rep    = rep,
          trait  = eval_df$trait[i],
          type   = eval_df$type[i],
          metric = mc,
          value  = val,
          stringsAsFactors = FALSE
        )
      }
    }
  }

  if (length(rows) == 0L) return(NULL)
  do.call(rbind, rows)
}


# ---- Internal: aggregate CV results to mean +/- sd --------------------------

aggregate_cv_results <- function(results) {
  if (nrow(results) == 0L) {
    return(data.frame(
      trait = character(0), type = character(0), metric = character(0),
      mean = double(0), sd = double(0), n_folds = integer(0),
      stringsAsFactors = FALSE
    ))
  }

  keys <- unique(results[, c("trait", "type", "metric")])
  rows <- vector("list", nrow(keys))

  for (i in seq_len(nrow(keys))) {
    mask <- results$trait  == keys$trait[i] &
            results$type   == keys$type[i] &
            results$metric == keys$metric[i]
    vals <- results$value[mask]

    rows[[i]] <- data.frame(
      trait   = keys$trait[i],
      type    = keys$type[i],
      metric  = keys$metric[i],
      mean    = mean(vals, na.rm = TRUE),
      sd      = stats::sd(vals, na.rm = TRUE),
      n_folds = length(vals),
      stringsAsFactors = FALSE
    )
  }

  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}


# ---- Internal: conformal coverage on test fold cells -------------------------

compute_conformal_coverage_fold <- function(pred, X_scaled, test_idx,
                                            trait_map, fold, rep) {
  if (is.null(pred$conformal_lower) || is.null(pred$conformal_upper)) {
    return(NULL)
  }

  n <- nrow(X_scaled)
  rows <- list()

  for (tm in trait_map) {
    nm <- tm$name
    lc <- tm$latent_cols

    if (!(tm$type %in% c("continuous", "count", "ordinal", "proportion"))) next

    # Find test rows for this trait's first latent column
    row_i <- ((test_idx - 1L) %% n) + 1L
    col_j <- ((test_idx - 1L) %/% n) + 1L
    keep  <- which(col_j == lc[1])
    ri    <- row_i[keep]
    if (length(ri) == 0L) next

    # Truth in original scale
    truth_latent <- X_scaled[ri, lc[1]]
    ok <- is.finite(truth_latent)
    if (sum(ok) == 0L) next

    # Back-transform truth to original scale for comparison with intervals
    if (tm$type == "continuous") {
      truth_orig <- truth_latent[ok] * tm$sd + tm$mean
      if (isTRUE(tm$log_transform)) truth_orig <- exp(truth_orig)
    } else if (tm$type == "count") {
      truth_orig <- expm1(truth_latent[ok] * tm$sd + tm$mean)
    } else if (tm$type == "proportion") {
      truth_orig <- stats::plogis(truth_latent[ok] * tm$sd + tm$mean)
    } else {
      truth_orig <- truth_latent[ok] * tm$sd + tm$mean
    }

    lower <- pred$conformal_lower[ri[ok], nm]
    upper <- pred$conformal_upper[ri[ok], nm]

    covered <- (truth_orig >= lower) & (truth_orig <= upper)
    coverage <- mean(covered, na.rm = TRUE)

    rows[[length(rows) + 1L]] <- data.frame(
      fold     = fold,
      rep      = rep,
      trait    = nm,
      type     = tm$type,
      coverage = coverage,
      n        = sum(ok),
      stringsAsFactors = FALSE
    )
  }

  if (length(rows) == 0L) return(NULL)
  do.call(rbind, rows)
}


# ---- Print and summary methods -----------------------------------------------

#' Print a cross-validation summary.
#'
#' Displays the number of folds and replicates, then reports each trait's
#' mean and standard deviation for every metric. Returns \code{x} invisibly.
#' Additional arguments are ignored by this print method.
#'
#' @param x A \code{pigauto_cv} object returned by \code{cross_validate()}.
#' @rdname cross_validate
#' @section Printing:
#' \code{print.pigauto_cv()} reports \code{k} folds and the replicate count,
#' followed by each trait's metric means and SDs. Displayed \code{n} is the
#' number of represented fold-by-replicate metric rows, not just the fold
#' count. This count includes rows with missing metric values; means and
#' SDs omit those values. When available, a separate conformal block shows
#' mean coverage and its SD against a nominal 95% target; the target is
#' not a guarantee. Empty summaries print \dQuote{No results.} The method
#' ignores \code{...} and returns \code{x} invisibly.
#' @export
print.pigauto_cv <- function(x, ...) {
  cat(sprintf("%d-fold cross-validation (%d replicate%s)\n",
              x$k, x$n_reps, if (x$n_reps > 1L) "s" else ""))
  rule <- paste(rep("\u2500", 50), collapse = "")
  cat(rule, "\n")


  if (nrow(x$summary) == 0L) {
    cat("No results.\n")
    return(invisible(x))
  }

  # Build display table
  traits <- unique(x$summary$trait)
  for (tr in traits) {
    sub <- x$summary[x$summary$trait == tr, , drop = FALSE]
    tp  <- sub$type[1]
    cat(sprintf("%-25s [%s]\n", tr, tp))

    for (i in seq_len(nrow(sub))) {
      cat(sprintf("  %-18s %7.4f +/- %.4f  (n=%d)\n",
                  sub$metric[i], sub$mean[i], sub$sd[i], sub$n_folds[i]))
    }
  }

  # Conformal coverage summary
  if (!is.null(x$conformal_coverage) && nrow(x$conformal_coverage) > 0L) {
    cat("\nConformal coverage (95% target):\n")
    cov_agg <- stats::aggregate(
      coverage ~ trait + type,
      data = x$conformal_coverage,
      FUN = function(v) c(mean = mean(v), sd = stats::sd(v))
    )
    cov_flat <- cbind(
      cov_agg[, c("trait", "type")],
      as.data.frame(cov_agg$coverage)
    )
    for (i in seq_len(nrow(cov_flat))) {
      cat(sprintf("  %-25s %.3f +/- %.3f\n",
                  cov_flat$trait[i], cov_flat$mean[i], cov_flat$sd[i]))
    }
  }

  invisible(x)
}

#' Print a compact summary of cross-validation results
#'
#' @rdname cross_validate
#' @aliases summary.pigauto_cv
#' @usage \method{summary}{pigauto_cv}(object, ...)
#' @param object A \code{pigauto_cv} object returned by
#'   \code{cross_validate()}.
#' @param ... Additional arguments forwarded by \code{cross_validate()} to \code{fit_pigauto()}; ignored by the print and summary methods.
#' @return Invisibly returns the summary data frame stored in
#'   \code{object$summary}.
#' @section Summary method:
#' \code{summary.pigauto_cv()} prints a compact per-trait table with RMSE,
#' Pearson \eqn{r} for continuous traits, Spearman \eqn{\rho} for ordinal
#' traits, and accuracy when returned (binary/categorical accuracy or
#' multi-proportion dominant-component accuracy). A dash means the metric
#' row is absent. A present but nonfinite metric may display \code{NA} or
#' \code{NaN}. An empty summary prints \dQuote{No results.} The full
#' \code{object$summary} data frame, which can contain metrics omitted from
#' this display, is returned invisibly. The method ignores \code{...}.
#' @export
summary.pigauto_cv <- function(object, ...) {
  cat(sprintf("%d-fold cross-validation (%d replicate%s)\n",
              object$k, object$n_reps,
              if (object$n_reps > 1L) "s" else ""))
  rule <- paste(rep("\u2500", 70), collapse = "")
  cat(rule, "\n")

  if (nrow(object$summary) == 0L) {
    cat("No results.\n")
    return(invisible(object$summary))
  }

  # Wide-format display with key metrics per trait type
  traits <- unique(object$summary$trait)

  # Header
  cat(sprintf("%-25s %-12s %15s %15s %15s\n",
              "Trait", "Type", "RMSE (mean+/-sd)",
              "r (mean+/-sd)", "Acc (mean+/-sd)"))
  cat(paste(rep("\u2500", 85), collapse = ""), "\n")

  for (tr in traits) {
    sub <- object$summary[object$summary$trait == tr, , drop = FALSE]
    tp  <- sub$type[1]

    # Extract key metrics
    fmt_metric <- function(metric_name) {
      row <- sub[sub$metric == metric_name, , drop = FALSE]
      if (nrow(row) == 0L) return("\u2500")
      sprintf("%.3f +/- %.3f", row$mean[1], row$sd[1])
    }

    rmse_str <- fmt_metric("rmse")
    r_str    <- if (tp == "continuous") {
      fmt_metric("pearson_r")
    } else if (tp == "ordinal") {
      s <- fmt_metric("spearman_rho")
      if (s != "\u2500") paste0(s, " (rho)") else s
    } else {
      "\u2500"
    }
    acc_str <- fmt_metric("accuracy")

    cat(sprintf("%-25s %-12s %15s %15s %15s\n",
                tr, tp, rmse_str, r_str, acc_str))
  }

  invisible(object$summary)
}
