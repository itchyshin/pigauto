#' Impute missing traits using a fitted pigauto model
#'
#' @description
#' Returns imputed trait values on the original scale for data used to fit the
#' model. Supports continuous, binary, categorical, ordinal, count, proportion,
#' zero-inflated count, and multi-proportion traits.
#'
#' **Multiple draws are diagnostic only.** With \code{n_imputations > 1},
#' returned draws are not supported for downstream inference. For
#' multi-proportion traits, pooled point values and simplex probabilities are
#' omitted; use a single-run prediction when you need the simplex output.
#'
#' @details
#' With \code{n_imputations > 1}, predictions include stochastic diagnostic
#' draws, not joint phylogenetic BM posterior draws. On each run, independent
#' Gaussian perturbations are added per latent cell to the selected baseline
#' component, scaled by that component's standard deviation (the second
#' parameter in \code{N(mu, sd)} is an SD, not a variance). A route that
#' supplies zero uncertainty placeholders adds no Gaussian perturbation for
#' those cells; a zero placeholder does not indicate certainty. When the GNN
#' is enabled, dropout also varies across runs. Because predictions use the
#' phylogenetic graph, predictions across species need not be independent.
#' The calibrated latent prediction combines the selected baseline, GNN
#' prediction and optional mean baseline using their calibrated weights;
#' an applicable direct covariate contribution is then added. In stochastic
#' runs the selected baseline term uses its perturbed value.
#' A zero GNN weight removes only the neural contribution. The output equals
#' the baseline draw only when the baseline weight is one and every other
#' contribution is absent. Point predictions and these stochastic diagnostic
#' draws are distinct outputs.
#' Point estimates follow the type-specific "Pooling decoded draws" table
#' below. The M complete datasets are returned in
#' \code{imputed_datasets} for prediction diagnostics. These datasets are not
#' supported for downstream inference. Use \code{multi_impute_analysis()} for
#' the narrow analysis-aware backend after consulting its supported-model and
#' lifecycle documentation.
#'
#' **\code{gnn = FALSE} fits (traditional-stats mode):** when the fit was
#' produced with \code{gnn = FALSE}, no GNN was ever trained, so this
#' function makes no \code{torch::} calls at all -- prediction is the
#' calibrated baseline blend \code{r_cal_bm * baseline + r_cal_mean *
#' mean_baseline_per_col} (\code{r_cal_gnn} is always zero) computed on
#' plain R matrices. Two baselines are available: in production mode (the
#' default, \code{evaluation = FALSE}) predictions use \code{baseline_full}
#' -- fit with \code{splits = NULL}, so every observed cell can inform every
#' other cell; in evaluation mode (\code{evaluation = TRUE}) predictions use the held-out
#' \code{baseline} instead, so scored cells never see their own value.
#' \code{n_imputations > 1} adds independent Gaussian perturbations per
#' latent cell, scaled by the selected baseline standard deviation. Cells
#' with zero selected baseline SD receive no Gaussian perturbation. These
#' are stochastic prediction diagnostics, not joint phylogenetic BM posterior
#' draws. The \code{gnn = FALSE} path has no GNN-dropout contribution.
#'
#' **Decoding per type:**
#' \describe{
#'   \item{continuous}{reverse z-score, then \code{exp()} if log-transformed}
#'   \item{binary}{\code{sigmoid(latent)} to probability, round to 0/1}
#'   \item{count}{reverse z-score of log1p, \code{expm1()}, round, clip >= 0}
#'   \item{ordinal}{reverse z-score, round to nearest valid integer level}
#'   \item{categorical}{\code{softmax()} over K latent columns, argmax}
#' }
#'
#' **Conformal intervals:** \code{conformal_lower} / \code{conformal_upper}
#' use whatever \code{conformal_method} the fit was trained with
#' (\code{\link{fit_pigauto}}). For \code{"mondrian"}, the half-width is not
#' constant across rows: each target cell's phylogenetic locality (mean
#' cophenetic distance to its 5 nearest training-observed species for that
#' trait) picks the near- or far-stratum score stored on the fit.
#' These are stratum-specific intervals; the far-stratum score is not
#' necessarily larger than the near-stratum score. See
#' \code{\link{fit_pigauto}}'s \code{conformal_method} argument for details.
#'
#' **\code{zi_count} conformal intervals are conditional on non-zero.**
#' \code{conformal_lower[, nm]} / \code{conformal_upper[, nm]} for a
#' \code{zi_count} trait back-transform the magnitude latent (log1p-z of the
#' count \emph{given it is non-zero}) plus/minus the conformal half-width
#' that was calibrated on that same magnitude column
#' (\code{\link{fit_pigauto}}'s \code{compute_conformal_scores()} scores
#' zi_count on \code{latent_cols[2]}, never on the decoded \code{E[X]}).
#' They are \strong{not} an interval for the expected value
#' \code{E[X] = P(nonzero) * E[count | nonzero]} -- constructing a naive
#' \eqn{\pm}quantile interval directly on \code{E[X]} would conflate gate
#' and magnitude uncertainty into one number with no valid coverage
#' interpretation. The gate probability \code{P(nonzero)} is available
#' separately in \code{pred$probabilities[[nm]]}; combine it with the
#' conditional interval yourself if you need an \code{E[X]}-scale bound.
#'
#' @param object object of class \code{"pigauto_fit"}.
#' @param newdata Must be \code{NULL}: predictions use the fitted data.
#'   Any non-NULL value is rejected; new-species prediction is not implemented.
#' @param return_se logical. Return type-dependent uncertainty summaries?
#'   Default \code{TRUE}; see the \code{se} return description below.
#' @param n_imputations integer. Number of stochastic prediction-diagnostic
#'   draws (default \code{1L}). With multiple draws, independent Gaussian
#'   perturbations are added per latent cell using the selected baseline SD;
#'   cells with zero selected baseline SD receive no perturbation. GNN dropout
#'   also varies across runs when the GNN is enabled. These are not joint
#'   phylogenetic BM posterior draws or validated analysis-aware imputations.
#' @param baseline_override optional `list(mu, se)` with the same shape as
#'   `object$baseline`. When supplied, predictions use this baseline instead
#'   of the one saved in the fit. Used internally by [multi_impute_trees()]
#'   to reuse a trained GNN across posterior trees. Most users can ignore
#'   this. Default `NULL` (use the fit's own baseline).
#' @param pool_method character. One of \code{"median"} (default),
#'   \code{"mean"}, or \code{"mode"}. Controls pooling when
#'   \code{n_imputations > 1}; see "Pooling decoded draws" below.
#'   Some types use the same rule for every setting.
#' @param clamp_outliers logical. When \code{TRUE}, cap back-transformed
#'   predictions for log-transformed continuous, count, and zi_count
#'   magnitude traits at \code{tm$obs_max * clamp_factor}, where
#'   \code{tm$obs_max} is the observed maximum on the original scale,
#'   recorded during preprocessing. This optional cap limits extrapolation
#'   after \code{exp()} or \code{expm1()}; it is not an uncertainty bound.
#'   Default \code{FALSE} leaves these predictions uncapped.
#' @param clamp_factor numeric scalar (>= 1). User-selected multiplier
#'   of the observed maximum for the upper cap when clamping is enabled.
#'   Default \code{5}. Ignored when \code{clamp_outliers = FALSE}.
#' @param match_observed character, one of \code{c("none", "pmm")}.
#'   When \code{"pmm"}, uses predictive
#'   Mean Matching (Little 1988; see References) on the at-risk types
#'   (log-transformed continuous, count, zi_count magnitude,
#'   proportion).  For each missing cell, finds the \code{pmm_K}
#'   observed cells whose own predictions are closest to the missing
#'   cell's prediction, samples one, and returns its observed
#'   value.  Imputed values are guaranteed to lie in the observed
#'   data range -- no extrapolation is possible by construction.
#'
#'   \strong{When to use:} PMM is a niche feature in pigauto.  The
#'   package already provides conformal prediction intervals
#'   (calibrated against held-out residuals) and
#'   stochastic conformal-width and mc_dropout prediction-diagnostic draws. PMM is
#'   only worth enabling for: (a) methodological comparison against
#'   mice / equivalent packages, or (b) workflows that specifically
#'   require imputed values to come from the observed data pool.
#'   For tail safety on single-imputation point estimates, prefer
#'   \code{clamp_outliers = TRUE}. PMM failed the downstream fixed-effect
#'   redesign pilot and is unsupported for inference.
#'
#'   Donor matching can reduce extrapolation but also replaces accurate
#'   predictions with donor values, so it is not a general RMSE improvement.
#'
#'   Discrete-class types (binary / categorical / ordinal /
#'   multi_proportion) and un-log continuous: no-op.  Default
#'   \code{"none"} leaves predictions unmatched.
#' @param pmm_K integer scalar (>= 1).  Donor pool size for PMM.
#'   Default \code{5L} (mice convention).  Ignored when
#'   \code{match_observed = "none"}.
#' @param evaluation Logical. Use \code{TRUE} to predict validation and test
#'   cells using the fit's held-out baseline and masked input context. Requires
#'   stored splits and \code{newdata = NULL}. Default \code{FALSE} uses all
#'   observed data for production imputation. Use \code{evaluation = TRUE}
#'   before passing predictions to \code{\link{evaluate_imputation}}.
#' @param ... Internal compatibility arguments. Unrecognised arguments are an
#'   error, including misspelled argument names.
#' @return A list of class \code{"pigauto_pred"} with:
#'   \describe{
#'     \item{imputed}{data.frame of model predictions for every fitted row
#'       (observed and missing cells), on the original scale with proper R
#'       types (numeric, integer, factor, ordered). Observed values are not
#'       retained in this component. Use \code{impute()} and its
#'       \code{$completed} component for a data.frame that preserves observed
#'       values and fills missing cells when predictions are available.}
#'     \item{imputed_latent}{Numeric matrix (n x p_latent) of predictions in
#'       latent scale.}
#'     \item{se}{Numeric matrix (n x n_original_traits) of per-cell
#'       uncertainty. See the "What \code{$se} means per trait type" section
#'       below. Single-run and multi-draw constructions differ. These
#'       are diagnostic summaries, not calibrated total predictive SDs or
#'       valid inputs to downstream pooling. \code{NULL} if
#'       \code{return_se = FALSE}.}
#'     \item{se_latent}{Numeric matrix on the latent scale, with one column
#'       per latent trait column. Returned when \code{return_se = TRUE} for
#'       current trait-map fits; otherwise \code{NULL}. Binary and categorical
#'       entries are \code{NA}; for \code{zi_count}, only the magnitude
#'       column has a summary.}
#'     \item{probabilities}{Named list. Binary traits: numeric probability
#'       vector; categorical traits: n x K class-probability matrix;
#'       zi_count traits: probability of nonzero. A single-run
#'       multi_proportion prediction includes its n x K simplex matrix.
#'       Compositional entries are absent from pooled multi-draw output.}
#'     \item{conformal_lower, conformal_upper}{Matrices of lower and upper
#'       conformal limits when the fitted model has conformal scores. Values
#'       are on the original trait scale except for ordinal traits, whose
#'       bounds are rounded zero-based indices. The lower limit is floored at
#'       0 and the upper limit capped at K - 1; these one-sided limits do not
#'       guarantee both endpoints are in range or that the interval is
#'       non-empty. Check bounds before mapping an index to a label using the
#'       corresponding ordered factor levels (index + 1 in R). Entries can be
#'       \code{NA} for
#'       unsupported traits or unavailable scores; both are \code{NULL} when
#'       scores are absent.}
#'     \item{conformal_scores}{Named numeric vector of the scores stored in
#'       the fitted model, or \code{NULL} when the fit has no scores.}
#'     \item{imputed_datasets}{List of M stochastic prediction data.frames when
#'       \code{n_imputations > 1}; \code{NULL} otherwise. Not supported for
#'       downstream inference.}
#'     \item{trait_map}{Trait map from the fitted model.}
#'     \item{species_names}{Character vector.}
#'     \item{trait_names}{Character vector.}
#'     \item{n_imputations}{Integer, number of imputations performed.}
#'     \item{evaluation_safe_idx}{Latent indices excluded from fitting and
#'       prediction input, used to check held-out scoring.}
#'   }
#' @section Pooling decoded draws:
#' These rules apply to \code{n_imputations > 1}, on the decoded scale.
#'
#' \ifelse{html}{\out{
#' <table>
#' <thead><tr><th scope="col">Type</th><th scope="col">median</th><th scope="col">mean</th><th scope="col">mode</th></tr></thead>
#' <tbody>
#' <tr><td>continuous, unlogged</td><td>mean</td><td>mean</td><td>mean</td></tr>
#' <tr><td>continuous, logged</td><td>median</td><td>median</td><td>median</td></tr>
#' <tr><td>count / proportion / zi_count</td><td>median</td><td>mean</td><td>median</td></tr>
#' <tr><td>ordinal</td><td>rounded mean class index</td><td>rounded mean class index</td><td>modal class</td></tr>
#' <tr><td>binary</td><td>mean probability, then threshold 0.5</td><td>same</td><td>same</td></tr>
#' <tr><td>categorical</td><td>mean class-probability vector, then argmax</td><td>same</td><td>same</td></tr>
#' <tr><td>multi_proportion</td><td>pooled output unavailable</td><td>unavailable</td><td>unavailable</td></tr>
#' </tbody>
#' </table>
#' }}{
#' \tabular{llll}{
#'   Type \tab median \tab mean \tab mode \cr
#'   continuous, unlogged \tab mean \tab mean \tab mean \cr
#'   continuous, logged \tab median \tab median \tab median \cr
#'   count / proportion / zi_count \tab median \tab mean \tab median \cr
#'   ordinal \tab rounded mean class index \tab rounded mean class index \tab modal class \cr
#'   binary \tab mean probability, then threshold 0.5 \tab same \tab same \cr
#'   categorical \tab mean class-probability vector, then argmax \tab same \tab same \cr
#'   multi_proportion \tab pooled output unavailable \tab unavailable \tab unavailable
#' }
#' }
#' Counts and zi_count values are rounded and clipped to nonnegative integers;
#' the zi_count nonzero probability is always averaged separately. Single-run
#' compositional output is a simplex vector; its pooled MC-dropout counterpart
#' is not populated, although individual decoded compositions are returned in
#' \code{imputed_datasets}. Do not interpret this omission as simplex averaging.
#'
#' @references
#' Little RJA (1988). "Missing-Data Adjustments in Large Surveys."
#' \emph{Journal of Business & Economic Statistics} 6(3): 287-296.
#' \doi{10.1080/07350015.1988.10509663}. This is a source for predictive
#' mean matching, not validation of pigauto's implementation.
#'
#' van Buuren S, Groothuis-Oudshoorn K (2011). "mice: Multivariate
#' Imputation by Chained Equations in R." \emph{Journal of Statistical
#' Software} 45(3), 1-67. \doi{10.18637/jss.v045.i03}. The
#' \href{https://amices.org/mice/reference/mice.impute.pmm.html}{official mice PMM documentation}
#' describes that software's method; it does not validate pigauto's PMM.
#'
#' @section What \code{$se} means per trait type:
#' For fits with a \code{trait_map}, \code{pred$se} is an
#' \code{n x n_original_traits} matrix of type-dependent diagnostic summaries.
#' Its construction also depends on \code{n_imputations}. It is not a
#' uniformly Gaussian standard error, a calibrated total predictive SD, or
#' an input to Rubin pooling.
#'
#' \ifelse{html}{\out{
#' <table>
#' <thead><tr><th scope="col">Type</th><th scope="col">Single run</th><th scope="col">More than one draw</th></tr></thead>
#' <tbody>
#' <tr><td>continuous / count / ordinal / proportion</td><td>Selected-baseline latent uncertainty scaled to the original scale, using delta-method back-transformation where applicable.</td><td>Square root of transformed baseline variance plus the between-decoded-draw variance. Logged continuous, count, and proportion transformations use the first latent run as their anchor.</td></tr>
#' <tr><td>binary</td><td><code>min(p, 1-p)</code></td><td>The same score using the probability averaged across draws.</td></tr>
#' <tr><td>categorical</td><td><code>1 - max(p_k)</code></td><td>The same score using the class-probability vector averaged across draws.</td></tr>
#' <tr><td>zi_count</td><td>A delta-method product summary for <code>P(nonzero) * E[count | nonzero]</code>, combining gate and magnitude terms.</td><td>Between-draw SD of decoded expected counts, without an additional baseline-variance term.</td></tr>
#' <tr><td>multi_proportion</td><td><code>NA</code></td><td><code>NA</code></td></tr>
#' </tbody>
#' </table>
#' }}{
#' \describe{
#'   \item{continuous/count/ordinal/proportion}{Single run: selected-baseline
#'     latent uncertainty scaled/back-transformed to the original scale.
#'     Multiple draws: square root of transformed baseline variance plus
#'     between-decoded-draw variance; logged continuous, count, and proportion
#'     transformations use the first latent run as their anchor.}
#'   \item{binary}{\code{min(p, 1-p)}, using the mean probability across
#'     draws when \code{n_imputations > 1}.}
#'   \item{categorical}{\code{1 - max(p_k)}, using the mean class-probability
#'     vector across draws when \code{n_imputations > 1}.}
#'   \item{zi_count}{Single run: a delta-method product summary combining
#'     gate and magnitude terms. Multiple draws: between-draw SD of decoded
#'     expected counts, with no additional baseline-variance term.}
#'   \item{multi_proportion}{\code{NA} for either setting.}
#' }
#' }
#'
#' For a BM Gaussian baseline, the single-run continuous-family source is a
#' model-dependent BM/joint conditional SD. It is not total final
#' blended-prediction uncertainty: it describes uncertainty under the
#' selected baseline, not prediction error in the final baseline--GNN blend.
#' Other route summaries do not inherit that interpretation automatically.
#' Discrete scores measure distance from a
#' certain class prediction, not a Gaussian SE. For compositions, inspect
#' the separate CLR latent summary in \code{se_latent}. The multi-draw
#' construction can contain baseline-draw variation with \code{gnn = FALSE};
#' it should not generally be described as an MC-dropout SE.
#'
#' Older saved fits without a \code{trait_map} use a separate continuous-only
#' legacy prediction path and are not described by this table. For supported
#' downstream multiple-imputation routes, consult
#' \code{\link{multi_impute_analysis}} or \code{\link{multi_impute}} with
#' \code{draws_method = "posterior"}, then use
#' \code{\link{with_imputations}} and \code{\link{pool_mi}} under their
#' documented eligibility conditions.
#' @examples
#' \donttest{
#' data(avonet300, tree300)
#' tree <- ape::keep.tip(tree300, tree300$tip.label[seq_len(30L)])
#' traits <- avonet300[match(tree$tip.label, avonet300$Species_Key),
#'                      c("Mass", "Wing.Length"), drop = FALSE]
#' rownames(traits) <- tree$tip.label
#' data <- preprocess_traits(traits, tree)
#' splits <- make_missing_splits(data$X_scaled, trait_map = data$trait_map)
#' fit <- fit_pigauto(data, tree, splits = splits, epochs = 5L,
#'                    verbose = FALSE)
#' pred <- predict(fit, return_se = TRUE)
#' pred$imputed
#' pred$se
#' pred$probabilities
#' pred2 <- predict(fit, n_imputations = 2L)
#' pred2$imputed_datasets
#' }
#' @importFrom torch torch_tensor torch_float with_no_grad torch_zeros
#' @importFrom torch torch_cat
#' @export
predict.pigauto_fit <- function(object, newdata = NULL, return_se = TRUE,
                                n_imputations = 1L, baseline_override = NULL,
                                pool_method = c("median", "mean", "mode"),
                                clamp_outliers = FALSE,
                                clamp_factor = 5,
                                match_observed = c("none", "pmm"),
                                pmm_K = 5L, evaluation = FALSE,
                                ...) {
  dots <- list(...)
  unused <- setdiff(names(dots), ".mask_observed_idx")
  if (length(unused) || (length(dots) &&
      (is.null(names(dots)) || any(!nzchar(names(dots)))))) {
    stop("Unused argument(s) in predict(): ",
         paste(c(unused, if (is.null(names(dots)) ||
                              any(!nzchar(names(dots)))) "<unnamed>"), collapse = ", "),
         call. = FALSE)
  }
  pool_method <- match.arg(pool_method)
  match_observed <- match.arg(match_observed)
  .pigauto_assert_predictable_state(object)
  clamp_outliers <- isTRUE(clamp_outliers)
  if (!is.numeric(clamp_factor) || length(clamp_factor) != 1L ||
      !is.finite(clamp_factor) || clamp_factor < 1) {
    stop("'clamp_factor' must be a single finite numeric >= 1.",
         call. = FALSE)
  }
  pmm_K <- as.integer(pmm_K)
  if (length(pmm_K) != 1L || is.na(pmm_K) || pmm_K < 1L) {
    stop("'pmm_K' must be a single positive integer.", call. = FALSE)
  }
  mask_observed_idx <- dots[[".mask_observed_idx"]]
  if (!is.logical(evaluation) || length(evaluation) != 1L || is.na(evaluation)) {
    stop("'evaluation' must be TRUE or FALSE.", call. = FALSE)
  }
  if (evaluation) {
    if (!is.null(newdata) || !is.null(baseline_override)) {
      stop("'evaluation = TRUE' requires newdata = NULL and no baseline_override.",
           call. = FALSE)
    }
    held <- c(object$splits$val_idx, object$splits$test_idx)
    if (!length(held)) {
      stop("'evaluation = TRUE' requires stored validation or test splits.",
           call. = FALSE)
    }
    mask_observed_idx <- unique(c(held, mask_observed_idx))
  }
  cfg       <- object$model_config
  # gnn = FALSE fits (gnn-off contract, S2): the GNN was never constructed or
  # trained, so this function must make ZERO torch:: calls in that path --
  # no get_device(), no ResidualPhyloDAE(), no load_state_dict(), no
  # torch_tensor().  Everything below runs on plain R matrices instead.
  # `isFALSE()` (not `!isTRUE()`) so old saves without a `gnn` field
  # (implicitly GNN-on) fall through to the unchanged torch path.
  gnn_off   <- isFALSE(cfg$gnn)
  device    <- if (!gnn_off) get_device() else NULL
  trait_map <- object$trait_map
  has_trait_map <- !is.null(trait_map)

  mps_cov_linear <- NULL
  if (!gnn_off) {
    # Reconstruct model (backward compat with old saves that lack new params)
    per_col                <- isTRUE(cfg$per_column_rs)
    n_gnn_layers           <- cfg$n_gnn_layers %||% 1L
    gate_cap               <- cfg$gate_cap %||% 0.5
    use_attention          <- cfg$use_attention %||% FALSE
    n_user_cov             <- cfg$n_user_cov %||% 0L
    use_transformer_blocks <- cfg$use_transformer_blocks %||% FALSE  # old saves: legacy
    n_heads                <- cfg$n_heads %||% 4L
    ffn_mult               <- cfg$ffn_mult %||% 4L
    use_trait_attention    <- isTRUE(cfg$use_trait_attention)        # old saves: FALSE
    n_trait_heads          <- cfg$n_trait_heads   %||% 2L
    trait_embed_dim        <- cfg$trait_embed_dim %||% 32L
    dropout_cfg            <- cfg$dropout %||% 0.10
    model <- ResidualPhyloDAE(
      input_dim              = as.integer(cfg$input_dim),
      hidden_dim             = as.integer(cfg$hidden_dim),
      coord_dim              = as.integer(cfg$k_eigen),
      cov_dim                = as.integer(cfg$cov_dim),
      per_column_rs          = per_col,
      n_gnn_layers           = as.integer(n_gnn_layers),
      gate_cap               = gate_cap,
      use_attention          = use_attention,
      n_user_cov             = as.integer(n_user_cov),
      dropout                = dropout_cfg,
      use_transformer_blocks = use_transformer_blocks,
      n_heads                = as.integer(n_heads),
      ffn_mult               = as.integer(ffn_mult),
      use_trait_attention    = use_trait_attention,
      n_trait_heads          = as.integer(n_trait_heads),
      trait_embed_dim        = as.integer(trait_embed_dim)
    )
    # Restore the CPU state before moving the rebuilt module to an accelerator.
    # Loading CPU tensors directly into an MPS module can silently miss scalar
    # bias values on some libtorch/macOS combinations (the weight still loads),
    # which drops fixed-effect intercepts from prediction.
    tryCatch(
      model$load_state_dict(object$model_state),
      error = function(e) {
        stop("This pigauto_fit cannot be used after saveRDS()/readRDS(). ",
             "Use save_pigauto() and load_pigauto() instead.",
             call. = FALSE)
      }
    )
    model$to(device = device)
    # Some ARM/MPS libtorch builds expose the correct length-one bias after state
    # loading but omit it from nn_linear()'s forward result.  Preserve the saved
    # direct-covariate parameters so prediction can reconstruct this small fixed-
    # effect term on CPU and bypass the affected MPS kernel entirely.
    cov_weight <- object$model_state[["cov_linear.weight"]]
    cov_bias <- object$model_state[["cov_linear.bias"]]
    if (identical(device$type, "mps") && !is.null(cov_weight) &&
        !is.null(cov_bias) && !is.null(model$cov_linear)) {
      mps_cov_linear <- list(
        weight = as.matrix(as.array(cov_weight$detach()$cpu())),
        bias = as.numeric(as.array(cov_bias$detach()$cpu()))
      )
    }
    gpu_mem_checkpoint("predict: after model rebuild + load_state_dict")
  }

  # Calibrated gates override learned gates.
  # Defensive length check (Fix C.4 / Opus 2026-04-28): when a downstream
  # caller manually overrides `object$calibrated_gates` (and the matching
  # r_cal_bm / r_cal_gnn / r_cal_mean) with a vector whose length does not
  # match the model's latent dim, the (1, k) override tensors broadcast
  # against the (n, p_latent) baseline to a degenerate shape and the
  # propagated `pred` becomes (n, 0) on the next refine step, which then
  # corrupts enc1's input width. Fail loudly with a useful message instead.
  expected_p <- as.integer(cfg$input_dim)
  calibrated_gates <- object$calibrated_gates  # NULL if not available
  if (!is.null(calibrated_gates) && length(calibrated_gates) == 0L) {
    # Treat 0-length override (e.g. rep(0, length(NULL))) as "no calibration".
    calibrated_gates <- NULL
  }
  if (!is.null(calibrated_gates) && length(calibrated_gates) != expected_p) {
    stop("calibrated_gates has length ", length(calibrated_gates),
         " but the model has ", expected_p, " latent column(s). ",
         "Pass a length-", expected_p,
         " numeric vector (one gate per latent column) to override.",
         call. = FALSE)
  }
  for (slot in c("r_cal_bm", "r_cal_gnn", "r_cal_mean", "mean_baseline_per_col")) {
    val <- object[[slot]]
    if (!is.null(val) && length(val) != 0L && length(val) != expected_p) {
      stop("`", slot, "` has length ", length(val),
           " but the model has ", expected_p, " latent column(s). ",
           "All per-column gate / mean overrides must be length ", expected_p, ".",
           call. = FALSE)
    }
  }
  use_calibrated   <- !is.null(calibrated_gates)
  calibration_slot <- function(slot, default) {
    val <- object[[slot]]
    if (is.null(val) || length(val) == 0L) default else val
  }
  numeric_calibration_slot <- function(x, slot) {
    out <- suppressWarnings(as.numeric(x))
    if (length(out) != expected_p || any(!is.finite(out))) {
      stop("`", slot, "` must be a finite numeric vector of length ",
           expected_p, ".", call. = FALSE)
    }
    out
  }

  # Optional baseline override — used by multi_impute_trees(share_gnn = TRUE)
  # to reuse a trained GNN across posterior trees, with only the BM baseline
  # recomputed per tree. Under gnn = FALSE (and no baseline_override),
  # production mode (no `.mask_observed_idx`, i.e. predicting on the fit's
  # own training data) uses `baseline_full` -- fit with splits = NULL, so
  # every observed cell can inform every other cell's baseline. Evaluation
  # mode (`.mask_observed_idx` supplied, e.g. by internal val/test scoring)
  # uses the held-out `baseline` so held-out cells are scored honestly.
  # GNN-on fits are unaffected: they always use `object$baseline`, as before.
  effective_baseline <- if (!is.null(baseline_override)) {
    baseline_override
  } else if (gnn_off) {
    if (is.null(mask_observed_idx)) object$baseline_full else object$baseline
  } else {
    object$baseline
  }
  baseline_label <- if (!is.null(baseline_override)) {
    "baseline_override"
  } else if (gnn_off) {
    if (is.null(mask_observed_idx)) "object$baseline_full" else "object$baseline"
  } else {
    "object$baseline"
  }
  if (!is.matrix(effective_baseline$mu) || !is.matrix(effective_baseline$se)) {
    stop("`", baseline_label, "` must contain `mu` and `se` matrices.",
         call. = FALSE)
  }

  # Prepare data
  multi_obs <- isTRUE(object$multi_obs)
  if (is.null(newdata)) {
    MU_species <- effective_baseline$mu    # n_species x p
    coords     <- object$graph$coords   # n_species x k
    adj        <- object$graph$adj      # n_species x n_species
    D_sq       <- object$graph$D_sq     # n_species x n_species, or NULL for old saves
    obs_to_sp  <- object$obs_to_species # NULL or integer vector
  } else {
    stop("newdata support not yet implemented.")
  }

  # For multi-obs, expand baseline to observation level
  if (multi_obs) {
    n_obs     <- object$n_obs
    n_species <- object$n_species
    MU <- MU_species[obs_to_sp, , drop = FALSE]
    rownames(MU) <- NULL
  } else {
    n_obs     <- nrow(MU_species)
    n_species <- n_obs
    MU        <- MU_species
    obs_to_sp <- NULL
  }

  n <- n_obs   # rows in output
  p <- ncol(MU)
  n_imp <- as.integer(n_imputations)
  if (is.null(p) || is.na(p) || p != expected_p) {
    stop("`", baseline_label, "$mu` has ", p,
         " latent column(s), but the model expects ", expected_p, ".",
         call. = FALSE)
  }
  if (!identical(dim(effective_baseline$se), dim(MU_species))) {
    stop("`", baseline_label, "$se` must be a matrix with the same dimensions as `",
         baseline_label, "$mu`.", call. = FALSE)
  }

  # Prediction-time input mirrors fit-time assembly: observed latent cells
  # remain available as DAE context, while originally-missing cells start at
  # the phylogenetic baseline. Older fit objects did not store X_scaled, so
  # they fall back to the baseline-only seed for backward compatibility.
  X_seed <- MU
  observed_mask <- NULL
  observed_values <- NULL
  if (!is.null(object$X_scaled)) {
    if (!is.matrix(object$X_scaled) ||
        !identical(dim(object$X_scaled), dim(MU))) {
      stop("Stored `X_scaled` must be a matrix with the same dimensions as `",
           baseline_label, "$mu` after any multi-observation expansion.",
           call. = FALSE)
    }
    observed_values <- object$X_scaled
    observed_mask <- !is.na(observed_values)
    if (!is.null(mask_observed_idx)) {
      mask_observed_idx <- as.integer(mask_observed_idx)
      if (anyNA(mask_observed_idx) ||
          any(mask_observed_idx < 1L | mask_observed_idx > length(X_seed))) {
        stop("`.mask_observed_idx` must contain valid linear indices into the ",
             "prediction latent matrix.", call. = FALSE)
      }
      observed_mask[unique(mask_observed_idx)] <- FALSE
    }
    X_seed[observed_mask] <- observed_values[observed_mask]
  }

  has_covariates <- !is.null(object$covariates)
  t_covariates   <- NULL
  t_mps_cov_fixed_effects <- NULL
  if (!gnn_off) {
    t_X_fill <- torch::torch_tensor(X_seed, dtype = torch::torch_float(),
                                    device = device)
    t_MU     <- torch::torch_tensor(MU, dtype = torch::torch_float(),
                                    device = device)
    t_coords <- torch::torch_tensor(coords, dtype = torch::torch_float(),
                                    device = device)
    t_adj    <- torch::torch_tensor(adj,    dtype = torch::torch_float(),
                                    device = device)
    # Squared cophenetic distances for B2 rate-aware attention.
    # NULL for old pigauto_fit objects saved before B2.1 — backward compat.
    t_D_sq <- if (!is.null(D_sq)) {
      torch::torch_tensor(D_sq, dtype = torch::torch_float(), device = device)
    } else {
      NULL
    }

    # Observation-to-species mapping tensor
    if (multi_obs) {
      t_obs_to_sp <- torch::torch_tensor(
        as.integer(obs_to_sp), dtype = torch::torch_long(), device = device
      )
    } else {
      t_obs_to_sp <- NULL
    }
    t_observed_mask <- NULL
    t_observed_values <- NULL
    if (!is.null(observed_mask)) {
      t_observed_mask <- torch::torch_tensor(observed_mask,
                                             dtype = torch::torch_bool(),
                                             device = device)
      t_observed_values <- torch::torch_tensor(observed_values,
                                               dtype = torch::torch_float(),
                                               device = device)
    }

    # ---- GNN covariates (environmental conditioners) ------------------------
    # These inputs condition GNN-specific prediction terms. With gnn = FALSE,
    # this GNN input block is absent; any covariate-aware per-column BM effect
    # is already represented in the baseline means supplied to prediction.
    n_cov_cols <- 0L
    if (has_covariates) {
      covariates <- as.matrix(object$covariates)
      if (nrow(covariates) != n) {
        stop("Stored covariates have ", nrow(covariates),
             " row(s), but prediction needs ", n, " row(s).",
             call. = FALSE)
      }
      n_cov_cols <- ncol(covariates)
      t_covariates <- torch::torch_tensor(
        covariates, dtype = torch::torch_float(), device = device
      )
    }
    if (!is.null(mps_cov_linear) && has_covariates) {
      mps_fixed_effects <- covariates %*% t(mps_cov_linear$weight)
      mps_fixed_effects <- sweep(
        mps_fixed_effects, 2L, mps_cov_linear$bias, FUN = "+"
      )
      t_mps_cov_fixed_effects <- torch::torch_tensor(
        mps_fixed_effects, dtype = torch::torch_float(), device = device
      )
    }
    actual_cov_dim <- p + 1L + n_cov_cols
    expected_cov_dim <- as.integer(cfg$cov_dim)
    if (length(expected_cov_dim) == 1L && !is.na(expected_cov_dim) &&
        actual_cov_dim != expected_cov_dim) {
      stop("Prediction covariate tensor would have ", actual_cov_dim,
           " column(s), but the model was fitted with cov_dim = ",
           expected_cov_dim, ". Check the fit object's stored covariates.",
           call. = FALSE)
    }

    gpu_mem_checkpoint("predict: after input tensor creation (adj, D_sq, coords, MU)")
  }

  # ---- Inference (single or MC dropout) ------------------------------------
  latent_runs <- vector("list", n_imp)

  if (!gnn_off) {
    # Re-seed the torch generator for stochastic prediction. fit_pigauto()
    # seeds training, but prediction rebuilds the module and then consumes
    # dropout and Normal draws from the process-global torch generator. Without
    # an explicit prediction seed, two otherwise identical impute(..., seed = s)
    # calls can differ according to unrelated torch work performed in between.
    # The stored fit seed makes the public seed contract reproducible while
    # different user seeds still generate different imputations.
    if (n_imp > 1L) {
      if (!is.null(cfg$seed)) {
        prediction_seed <- as.integer(cfg$seed) + 100000L
        torch::torch_manual_seed(prediction_seed)
      }
    }
  }

  # Pre-create calibrated gate vectors (once, outside the loop).
  # Three-way blend: pred = r_bm * BM_draw + r_gnn * GNN_delta + r_mean * MEAN
  # Backward-compat fallback: legacy v0.9.1 fits only have calibrated_gates /
  # r_cal (scalar per col). When r_cal_bm / r_cal_mean are missing, reconstruct
  # the 2-way blend as r_bm = 1 - r_cal, r_gnn = r_cal, r_mean = 0, mean = 0.
  if (use_calibrated) {
    r_bm_vec   <- calibration_slot("r_cal_bm", 1 - calibrated_gates)
    r_gnn_vec  <- calibration_slot("r_cal_gnn", calibrated_gates)
    r_mean_vec <- calibration_slot("r_cal_mean", rep(0, length(calibrated_gates)))
    mean_vec   <- calibration_slot("mean_baseline_per_col",
                                   rep(0, length(calibrated_gates)))
    r_bm_vec   <- numeric_calibration_slot(r_bm_vec, "r_cal_bm")
    r_gnn_vec  <- numeric_calibration_slot(r_gnn_vec, "r_cal_gnn")
    r_mean_vec <- numeric_calibration_slot(r_mean_vec, "r_cal_mean")
    mean_vec   <- numeric_calibration_slot(mean_vec, "mean_baseline_per_col")
    if (!gnn_off) {
      t_w_bm          <- torch::torch_tensor(r_bm_vec,   dtype = torch::torch_float(),
                                             device = device)$unsqueeze(1L)
      t_w_gnn         <- torch::torch_tensor(r_gnn_vec,  dtype = torch::torch_float(),
                                             device = device)$unsqueeze(1L)
      t_w_mean        <- torch::torch_tensor(r_mean_vec, dtype = torch::torch_float(),
                                             device = device)$unsqueeze(1L)
      t_mean_baseline <- torch::torch_tensor(mean_vec,   dtype = torch::torch_float(),
                                             device = device)$unsqueeze(1L)
      t_cal_gates     <- t_w_gnn  # legacy alias: downstream code that references
                                   # t_cal_gates directly still gets the GNN gate
    }
  } else if (gnn_off) {
    stop("`gnn = FALSE` fits require calibrated gates (r_cal_bm etc.), but ",
         "this fit has none. This indicates a malformed fit object.",
         call. = FALSE)
  }

  # Baseline SD (latent / z-score scale) for stochastic prediction diagnostics.
  # Independent Gaussian perturbations are added per latent cell, not drawn
  # jointly from the phylogenetic BM posterior. Cells with zero selected
  # baseline SD receive no Gaussian perturbation. In the GNN path, one
  # perturbed baseline matrix is held fixed across refinement steps; GNN
  # dropout adds further variation when enabled.
  if (n_imp > 1L) {
    bse_mat <- effective_baseline$se            # n_species x p_latent
    if (multi_obs) bse_mat <- bse_mat[obs_to_sp, , drop = FALSE]
    if (!gnn_off) {
      t_BM_SE <- torch::torch_tensor(
        bse_mat, dtype = torch::torch_float(), device = device
      )
    }
  }

  if (gnn_off) {
    # ---- Plain-R blend (no GNN): pred = r_bm * MU_m + r_mean * mean_baseline
    # (r_gnn = 0, since there is no GNN delta under gnn = FALSE). There is no
    # refine loop either -- with no GNN correction to refine, one pass per
    # imputation is the whole computation.
    #
    # RNG isolation: seed with cfg$seed + 100000L, the same prediction-seed
    # contract as the torch re-seed above, then restore the caller's RNG
    # state so predict() has no side effects on unrelated code.
    old_seed <- if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
      get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    } else {
      NULL
    }
    on.exit({
      if (!is.null(old_seed)) {
        assign(".Random.seed", old_seed, envir = .GlobalEnv)
      } else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
        rm(".Random.seed", envir = .GlobalEnv)
      }
    }, add = TRUE)
    if (n_imp > 1L && !is.null(cfg$seed)) {
      set.seed(as.integer(cfg$seed) + 100000L)
    }

    # Arm parity with the GNN-on path: `latent_runs[[m]]` stores the raw
    # blend at EVERY cell, observed included -- the GNN-on path never
    # restores observed cells into `last_pred` either (only into `X_iter`,
    # the next refine step's model input), so the two arms must differ only
    # in the GNN term, not in whether observed cells are patched back in.
    # This is safe for BM-eligible columns because `MU` (`baseline_mu`) is
    # already exactly the observed value at observed cells with `se = 0`
    # (bse_mat = 0 there), so `MU_m == MU` at those cells regardless of
    # `n_imp` -- the only thing that changes at an observed cell is the
    # mean-floor pull `r_mean * mean_baseline_per_col`, matching what the
    # GNN-on blend already does at observed cells.
    mean_term <- r_mean_vec * mean_vec   # per-column constant, broadcast over rows
    for (m in seq_len(n_imp)) {
      if (n_imp == 1L) {
        MU_m <- MU
      } else {
        # Add independent Gaussian perturbations per latent cell, scaled by
        # baseline SD. Zero SD means no Gaussian perturbation for that cell.
        noise <- matrix(stats::rnorm(n * p), nrow = n, ncol = p)
        MU_m  <- MU + noise * bse_mat
      }
      pred <- sweep(MU_m, 2, r_bm_vec, "*")
      pred <- sweep(pred, 2, mean_term, "+")
      latent_runs[[m]] <- pred
    }
    rs_val <- rep(0, p)
  } else {
    # Default: deterministic baseline for n_imp == 1 path (same as t_MU).
    # Overwritten each iteration when n_imp > 1.
    t_BM_draw <- t_MU

    for (m in seq_len(n_imp)) {
      last_pred <- NULL
      if (n_imp == 1L) {
        model$eval()
        X_iter <- t_X_fill$clone()
        # t_BM_draw stays as t_MU  → blend is identical to original single-pass
      } else {
        model$train()   # activates dropout on GNN hidden layers
        # Add independent Gaussian perturbations per latent cell, scaled by
        # baseline SD. Zero SD means no Gaussian perturbation for that cell.
        noise     <- torch::torch_randn(c(n, p), dtype = torch::torch_float(),
                                       device = device)
        t_BM_draw <- t_MU + noise * t_BM_SE   # fixed BM draw for this m
        X_iter    <- t_BM_draw$clone()          # GNN input starts from BM draw
        if (!is.null(t_observed_mask)) {
          X_iter <- torch::torch_where(t_observed_mask, t_observed_values, X_iter)
        }
      }
      torch::with_no_grad({
        mask_ind0 <- torch::torch_zeros(c(n, 1L), device = device)
        for (step in seq_len(cfg$refine_steps)) {
          covs0 <- make_covs_tensor(t_MU, mask_ind0, t_covariates)
          out   <- model(X_iter, t_coords, covs0, t_adj, t_obs_to_sp,
                         D_sq = t_D_sq)
          # Use this run's perturbed baseline value in the blend. The baseline
          # perturbation can contribute variation even when the GNN weight is 0.
          if (use_calibrated) {
            pred <- t_w_bm * t_BM_draw + t_w_gnn * out$delta +
                    t_w_mean * t_mean_baseline
          } else {
            pred <- (1 - out$rs) * t_BM_draw + out$rs * out$delta
          }
          if (!is.null(t_mps_cov_fixed_effects)) {
            pred <- pred + t_mps_cov_fixed_effects
          } else if (!is.null(out$fixed_effects)) {
            pred <- pred + out$fixed_effects
          }
          last_pred <- pred
          # Drop the previous X_iter before binding the new one so that the
          # old forward-pass intermediates (attention matrices, FFN outputs,
          # and all their stored views) become unreachable and available for
          # the caching allocator to reclaim on cuda_empty_cache().  At
          # n=5000 with refine_steps=8 and n_imputations=5, skipping this
          # step causes ~22 GB of attention-per-step to pile up across
          # refinements -- see job 4745401 (n=5000, DEBUG_GPU_MEM=1) for
          # the reproducer.
          X_iter <- if (!is.null(t_observed_mask)) {
            torch::torch_where(t_observed_mask, t_observed_values, pred)
          } else {
            pred
          }
          # Preserve `out` for the last-iteration reference at line ~283
          # (rs_val <- out$rs$cpu()$squeeze()).  Drop covs0 and pred
          # which are safe to release -- X_iter holds the latest pred's
          # value and the next iteration rebinds both.
          rm(covs0, pred)
        }
        rm(mask_ind0)
      })
      # Release the accumulated intra-draw intermediates before the next
      # MI draw starts. cuda_empty_cache() actually reclaims the allocator
      # blocks -- without it, torch holds the 22 GB chunk forever.
      if (torch::cuda_is_available()) {
        try(torch::cuda_empty_cache(), silent = TRUE)
      }
      if (is.null(last_pred)) last_pred <- X_iter
      latent_runs[[m]] <- as.matrix(last_pred$cpu())
      gpu_mem_checkpoint(sprintf("predict: after MI draw %d / %d", m, n_imp))
    }

    # Residual scale (per-column vector or legacy scalar)
    rs_val <- as.numeric(out$rs$cpu()$squeeze())
  }

  # ---- Legacy path: no trait_map (old pigauto_fit objects) -----------------
  if (!has_trait_map) {
    return(decode_continuous_legacy(latent_runs, object, rs_val,
                                   return_se, n_imp, effective_baseline))
  }

  # ---- Mixed-type decoding -------------------------------------------------
  row_labels <- if (multi_obs) object$obs_species else object$species_names
  decode_results <- lapply(latent_runs, function(lat) {
    decode_from_latent(lat, trait_map, row_labels,
                        clamp_outliers = clamp_outliers,
                        clamp_factor   = clamp_factor)
  })

  # ---- Phase G' (2026-05-01): Predictive Mean Matching --------------------
  # When match_observed = "pmm", replace the back-transformed prediction at
  # each missing cell with an observed value from the K nearest donors.
  # Imputed values are guaranteed to lie in the observed-data range; no
  # extrapolation is possible (Little 1988; Buuren mice).  Discrete-class
  # types (binary / categorical / ordinal / multi_proportion) are no-op.
  # Untransformed continuous: no-op (no expm1 tail risk).
  if (identical(match_observed, "pmm")) {
    if (is.null(object$X_scaled)) {
      stop("match_observed = 'pmm' requires a fit object with X_scaled. ",
           "This fit was produced by an older pigauto version; refit with ",
           "v0.9.1.9012+ to enable PMM.", call. = FALSE)
    }
    X_orig <- recover_X_orig(object$X_scaled, trait_map)
    if (!is.null(mask_observed_idx)) {
      row_i <- ((mask_observed_idx - 1L) %% n) + 1L
      col_j <- ceiling(mask_observed_idx / n)
      for (tm in trait_map) {
        trait_rows <- row_i[col_j %in% tm$latent_cols]
        if (length(trait_rows) > 0L && tm$name %in% names(X_orig)) {
          X_orig[unique(trait_rows), tm$name] <- NA
        }
      }
    }
    decode_results <- apply_pmm_to_decoded(
      decode_results, trait_map, X_orig,
      K = pmm_K,
      base_seed = object$model_config$seed
    )
  }

  if (n_imp == 1L) {
    imputed     <- decode_results[[1]]$imputed
    probs       <- decode_results[[1]]$probabilities
    latent_pred <- latent_runs[[1]]
  } else {
    pool <- pool_imputations(decode_results, latent_runs, trait_map,
                              pool_method = pool_method)
    imputed     <- pool$imputed
    probs       <- pool$probabilities
    latent_pred <- pool$latent_mean
  }

  rownames(latent_pred) <- row_labels
  lat_names <- latent_names_from_map(trait_map)
  if (length(lat_names) == ncol(latent_pred)) {
    colnames(latent_pred) <- lat_names
  }

  # ---- SE ------------------------------------------------------------------
  se_mat <- NULL
  se_latent_mat <- NULL
  if (return_se) {
    # Expand species-level baseline SE to obs level if multi_obs
    bse <- effective_baseline$se
    if (multi_obs) {
      bse <- bse[obs_to_sp, , drop = FALSE]
      rownames(bse) <- NULL
    }
    # Row names for output
    row_names <- if (multi_obs) object$obs_species else object$species_names

    if (n_imp > 1L) {
      se_mat <- compute_mc_se(decode_results, trait_map,
                              bse, latent_runs[[1]],
                              row_names)
    } else {
      se_mat <- compute_single_se(latent_runs[[1]], probs, trait_map,
                                  bse, row_names)
    }

    se_latent_mat <- compute_latent_se(latent_runs, trait_map,
                                       bse, row_names)
  }

  # ---- Conformal prediction intervals -----------------------------------
  conformal_lower <- NULL
  conformal_upper <- NULL
  conformal_scores_out <- object$conformal_scores

  if (!is.null(conformal_scores_out) && has_trait_map) {
    n_traits <- length(trait_map)
    conformal_lower <- matrix(NA_real_, nrow = n, ncol = n_traits)
    conformal_upper <- matrix(NA_real_, nrow = n, ncol = n_traits)
    colnames(conformal_lower) <- vapply(trait_map, "[[", character(1), "name")
    colnames(conformal_upper) <- vapply(trait_map, "[[", character(1), "name")
    rownames(conformal_lower) <- row_labels
    rownames(conformal_upper) <- row_labels

    # Mondrian (B2, 2026-08-16): each target cell's conformal score
    # depends on its phylogenetic locality relative to the SAME
    # training-time observed set used at calibration (fit_pigauto.R's
    # M_obs_mat = observed AND not held out for val/test). Reconstructed
    # here from object$X_scaled + object$splits rather than stored
    # directly on the fit, matching how PMM (match_observed = "pmm")
    # already recovers observed cells from X_scaled above. Single-obs
    # only -- fit_pigauto() errors at fit time for multi_obs, so
    # `multi_obs` here should already be FALSE whenever this fires; the
    # check is defensive.
    #
    # Per-cell stratum logic extracted to mondrian_cell_scores() so
    # multi_impute()'s conformal draws can reuse it identically (see that
    # function's roxygen for the refactor rationale).
    cell_scores <- if (!multi_obs) {
      mondrian_cell_scores(object, D_sq, trait_map, n)
    } else {
      NULL
    }

    for (tm in trait_map) {
      nm <- tm$name
      lc <- tm$latent_cols

      if (!(tm$type %in%
            c("continuous", "count", "ordinal", "proportion", "zi_count"))) next
      if (is.na(conformal_scores_out[nm])) next

      # zi_count is scored on the magnitude (log1p-z) column, not the
      # Bernoulli gate -- must match fit_helpers.R's compute_conformal_scores()
      # `score_col`, both for reading conformal_scores_out[nm] above.
      score_col <- if (identical(tm$type, "zi_count")) lc[2L] else lc[1L]

      # q_vec: per-row conformal half-width. Constant (global score) for
      # "split" / "bootstrap"; per-row near/far stratum score for
      # "mondrian" (rows whose locality can't be computed, e.g. no
      # observed species for this trait, keep the global fallback value).
      q_vec <- if (!is.null(cell_scores) && !is.na(cell_scores$scores[1L, nm])) {
        cell_scores$scores[, nm]
      } else {
        rep(conformal_scores_out[nm], n)
      }

      if (tm$type == "continuous") {
        # Convert conformal score from latent to original scale
        pred_latent <- latent_pred[, lc[1]]
        pred_low  <- (pred_latent - q_vec) * tm$sd + tm$mean
        pred_high <- (pred_latent + q_vec) * tm$sd + tm$mean
        if (isTRUE(tm$log_transform)) {
          conformal_lower[, nm] <- exp(pred_low)
          conformal_upper[, nm] <- exp(pred_high)
        } else {
          conformal_lower[, nm] <- pred_low
          conformal_upper[, nm] <- pred_high
        }

      } else if (tm$type == "count") {
        pred_latent <- latent_pred[, lc[1]]
        pred_low  <- (pred_latent - q_vec) * tm$sd + tm$mean
        pred_high <- (pred_latent + q_vec) * tm$sd + tm$mean
        conformal_lower[, nm] <- pmax(expm1(pred_low), 0)
        conformal_upper[, nm] <- expm1(pred_high)

      } else if (tm$type == "ordinal") {
        pred_latent <- latent_pred[, lc[1]]
        pred_low  <- (pred_latent - q_vec) * tm$sd + tm$mean
        pred_high <- (pred_latent + q_vec) * tm$sd + tm$mean
        K <- length(tm$levels)
        conformal_lower[, nm] <- pmax(round(pred_low), 0)
        conformal_upper[, nm] <- pmin(round(pred_high), K - 1L)

      } else if (tm$type == "proportion") {
        pred_latent <- latent_pred[, lc[1]]
        pred_low  <- (pred_latent - q_vec) * tm$sd + tm$mean
        pred_high <- (pred_latent + q_vec) * tm$sd + tm$mean
        conformal_lower[, nm] <- stats::plogis(pred_low)
        conformal_upper[, nm] <- stats::plogis(pred_high)

      } else if (tm$type == "zi_count") {
        # Conditional-on-nonzero interval: back-transform the magnitude
        # latent (log1p-z of counts | nonzero) +/- the conformal half-width,
        # which was calibrated on this same magnitude column
        # (fit_helpers.R's compute_conformal_scores(), score_col = lc[2]).
        # This is NOT an interval for E[X] = P(nonzero) * E[count|nonzero] --
        # see the "Conformal intervals" details above and pred$probabilities
        # for the gate probability P(nonzero).
        pred_latent <- latent_pred[, score_col]
        pred_low  <- (pred_latent - q_vec) * tm$sd + tm$mean
        pred_high <- (pred_latent + q_vec) * tm$sd + tm$mean
        conformal_lower[, nm] <- pmax(expm1(pred_low), 0)
        conformal_upper[, nm] <- expm1(pred_high)
      }
    }
  }

  # ---- Stochastic completed datasets for prediction diagnostics ------------
  imputed_datasets <- if (n_imp > 1L) {
    lapply(decode_results, "[[", "imputed")
  }

  structure(
    list(
      imputed          = imputed,
      imputed_latent   = latent_pred,
      se               = se_mat,
      se_latent        = se_latent_mat,
      probabilities    = probs,
      imputed_datasets = imputed_datasets,
      conformal_lower  = conformal_lower,
      conformal_upper  = conformal_upper,
      conformal_scores = conformal_scores_out,
      calibrated_gates = calibrated_gates,
      trait_map        = trait_map,
      species_names    = object$species_names,
      obs_species      = if (multi_obs) object$obs_species else NULL,
      obs_to_species   = obs_to_sp,
      multi_obs        = multi_obs,
      trait_names      = object$trait_names,
      n_imputations    = n_imp,
      evaluation_safe_idx = if (is.null(baseline_override)) {
        as.integer(union(which(is.na(object$X_scaled)),
          intersect(mask_observed_idx,
                    c(object$splits$val_idx, object$splits$test_idx))))
      } else integer(0)
    ),
    class = "pigauto_pred"
  )
}


# ---- Internal: legacy all-continuous decoding ---------------------------------

decode_continuous_legacy <- function(latent_runs, object, rs_val,
                                    return_se, n_imp,
                                    effective_baseline = object$baseline) {
  if (n_imp == 1L) {
    pred_scaled <- latent_runs[[1]]
  } else {
    pred_scaled <- Reduce("+", latent_runs) / n_imp
  }

  rownames(pred_scaled) <- object$species_names
  colnames(pred_scaled) <- object$trait_names

  sds    <- object$norm$sds
  means  <- object$norm$means
  is_log <- isTRUE(object$norm$log_transform)

  # Back-transform predictions
  imputed <- sweep(pred_scaled, 2, sds, "*")
  imputed <- sweep(imputed, 2, means, "+")
  if (is_log) imputed <- exp(imputed)

  se_out <- NULL
  if (return_se) {
    if (n_imp > 1L) {
      all_bt <- lapply(latent_runs, function(lr) {
        bt <- sweep(lr, 2, sds, "*")
        bt <- sweep(bt, 2, means, "+")
        if (is_log) bt <- exp(bt)
        bt
      })
      se_mc <- matrix(NA_real_, nrow(imputed), ncol(imputed),
                      dimnames = dimnames(imputed))
      for (j in seq_len(ncol(imputed))) {
        vals <- sapply(all_bt, function(m) m[, j])
        se_mc[, j] <- apply(vals, 1, stats::sd)
      }
      # Add baseline SE in quadrature
      bm_se <- effective_baseline$se
      se_bm_orig <- sweep(bm_se, 2, sds, "*")
      if (is_log) {
        pred_log <- sweep(pred_scaled, 2, sds, "*")
        pred_log <- sweep(pred_log, 2, means, "+")
        se_bm_orig <- exp(pred_log) * se_bm_orig
      }
      se_out <- sqrt(se_bm_orig^2 + se_mc^2)
    } else {
      bm_se   <- effective_baseline$se
      se_orig <- sweep(bm_se, 2, sds, "*")
      if (is_log) {
        pred_log <- sweep(pred_scaled, 2, sds, "*")
        pred_log <- sweep(pred_log, 2, means, "+")
        se_orig  <- exp(pred_log) * se_orig  # delta method
      }
      rownames(se_orig) <- object$species_names
      colnames(se_orig) <- object$trait_names
      se_out <- se_orig
    }
  }

  list(imputed = imputed, se = se_out)
}


# ---- Internal: decode latent matrix to original-scale data.frame ---------------

decode_from_latent <- function(latent_mat, trait_map, species_names,
                                clamp_outliers = FALSE, clamp_factor = 5) {
  # Phase G (2026-05-01): optional value clamp on log-transformed
  # continuous, count, and zi_count magnitude after the expm1 / exp
  # back-transform.  When clamp_outliers = TRUE and tm$obs_max is
  # available (set at preprocess time), predictions are capped at
  # obs_max * clamp_factor.  Helps with the AVONET Mass tail-extrapolation
  # mode (see useful/MEMO_2026-05-01_avonet_mass_diag.md): a +3-4 SD
  # latent overshoot becomes a 50x-100x value error after expm1.  Default
  # FALSE preserves v0.9.1 behaviour exactly.
  .clamp_high <- function(vals, tm) {
    if (!clamp_outliers) return(vals)
    if (is.null(tm$obs_max) || !is.finite(tm$obs_max)) return(vals)
    upper <- as.numeric(tm$obs_max) * clamp_factor
    pmin(vals, upper)
  }
  n <- nrow(latent_mat)
  # Use make.unique for multi-obs (species_names may have duplicates)
  imputed <- data.frame(row.names = make.unique(species_names, sep = "."))
  probs <- list()

  for (tm in trait_map) {
    nm <- tm$name
    lc <- tm$latent_cols

    if (tm$type == "continuous") {
      vals <- latent_mat[, lc] * tm$sd + tm$mean
      if (tm$log_transform) {
        vals <- exp(vals)
        vals <- .clamp_high(vals, tm)
      }
      imputed[[nm]] <- vals

    } else if (tm$type == "count") {
      vals <- latent_mat[, lc] * tm$sd + tm$mean
      vals <- expm1(vals)
      vals <- pmax(round(vals), 0)
      vals <- .clamp_high(vals, tm)
      imputed[[nm]] <- as.integer(vals)

    } else if (tm$type == "ordinal") {
      vals <- latent_mat[, lc] * tm$sd + tm$mean
      K <- length(tm$levels)
      int_vals <- as.integer(pmin(pmax(round(vals), 0), K - 1L))
      imputed[[nm]] <- factor(tm$levels[int_vals + 1L],
                              levels = tm$levels, ordered = TRUE)

    } else if (tm$type == "binary") {
      prob <- expit(latent_mat[, lc])
      probs[[nm]] <- prob
      pred_class <- ifelse(prob >= 0.5, tm$levels[2], tm$levels[1])
      imputed[[nm]] <- factor(pred_class, levels = tm$levels)

    } else if (tm$type == "categorical") {
      logits <- latent_mat[, lc, drop = FALSE]
      prob_mat <- softmax_rows(logits)
      colnames(prob_mat) <- tm$levels
      rownames(prob_mat) <- species_names
      probs[[nm]] <- prob_mat
      pred_idx <- apply(prob_mat, 1, which.max)
      imputed[[nm]] <- factor(tm$levels[pred_idx], levels = tm$levels)

    } else if (tm$type == "proportion") {
      # Inverse logit: latent -> logit scale -> (0,1)
      vals_logit <- latent_mat[, lc] * tm$sd + tm$mean
      vals <- stats::plogis(vals_logit)
      imputed[[nm]] <- vals

    } else if (tm$type == "zi_count") {
      # Expected value: E[X] = P(non-zero) * E[count | non-zero]
      p_nz <- expit(latent_mat[, lc[1]])
      count_logscale <- latent_mat[, lc[2]] * tm$sd + tm$mean
      count_hat <- expm1(count_logscale)
      count_hat <- pmax(count_hat, 0)
      count_hat <- .clamp_high(count_hat, tm)
      ev <- p_nz * count_hat
      imputed[[nm]] <- as.integer(pmax(round(ev), 0L))
      probs[[nm]] <- p_nz  # probability of non-zero

    } else if (tm$type == "multi_proportion") {
      # K latent CLR columns -> undo z-score -> sum-to-zero projection
      # -> softmax -> proportions on the simplex.
      clr_mat <- latent_mat[, lc, drop = FALSE]
      for (k in seq_len(tm$n_latent)) {
        clr_mat[, k] <- clr_mat[, k] * tm$sd[k] + tm$mean[k]
      }
      clr_mat <- clr_mat - rowMeans(clr_mat)            # enforce sum=0
      prop_mat <- softmax_rows(clr_mat)
      colnames(prop_mat) <- tm$levels
      rownames(prop_mat) <- rownames(imputed)
      probs[[nm]] <- prop_mat
      # Return each component as its own column for convenience; also add the
      # whole matrix under the group name as an attribute-less list entry.
      for (k in seq_along(tm$levels)) {
        imputed[[tm$levels[k]]] <- prop_mat[, k]
      }
    }
  }

  list(imputed = imputed, probabilities = probs)
}


# ---- Internal: aggregate stochastic prediction draws ----------------------------

pool_imputations <- function(decode_results, latent_runs, trait_map,
                              pool_method = c("median", "mean", "mode")) {
  # `pool_method`:
  #   "median" — per-cell median across M decoded draws for count /
  #     proportion / zi_count magnitude.  Robust to dropout-noisy draws
  #     amplified by non-linear decoders (expm1 / plogis).
  #   "mean"   — per-cell arithmetic mean (pre-v0.9.2 behaviour).  Kept
  #     as opt-in for strict backward compat.
  #   "mode"   — Phase H (2026-05-01): per-cell mode (majority vote)
  #     for ordinal traits.  Closes the AVONET Migration N_IMP=20
  #     regression (-10.9 pp) by avoiding integer-mean-round bias
  #     toward middle classes.  For continuous-family types ("mode"
  #     falls back to "median" since mode does not apply to continuous
  #     decoders).  Binary / categorical / multi_proportion are
  #     unchanged (already probability-averaged + argmax).
  # Continuous / binary / categorical are UNAFFECTED by "median" vs
  # "mean" -- their decoders are linear or probability-averaged, so
  # mean pooling is fine.
  pool_method <- match.arg(pool_method)
  M <- length(decode_results)
  latent_mean <- Reduce("+", latent_runs) / M
  sp_names <- rownames(decode_results[[1]]$imputed)
  imputed <- data.frame(row.names = sp_names)
  probs <- list()

  # Helper: per-cell median of a trait's decoded values across M draws.
  # Median pooling across decoded values. Robust to dropout-noisy draws
  # whose decode path (expm1, plogis) amplifies high-tail values --
  # critical for log-transformed continuous, count, zi_count, and
  # proportion traits at large n where a few outlier draws dominate the
  # mean pool. See the FishBase n=10,654 bench for the reproducer.
  row_median_decoded <- function(nm) {
    mat <- sapply(decode_results, function(dr) as.numeric(dr$imputed[[nm]]))
    if (!is.matrix(mat)) mat <- matrix(mat, ncol = M)
    apply(mat, 1L, stats::median, na.rm = TRUE)
  }

  for (tm in trait_map) {
    nm <- tm$name

    if (tm$type == "continuous") {
      if (isTRUE(tm$log_transform)) {
        # Log-transformed continuous: median pool to avoid expm1
        # amplification of dropout-noisy draws.
        imputed[[nm]] <- row_median_decoded(nm)
      } else {
        # Untransformed continuous: mean pool (backward-compat default).
        vals <- rowMeans(sapply(decode_results,
                                 function(dr) dr$imputed[[nm]]))
        imputed[[nm]] <- vals
      }

    } else if (tm$type == "count") {
      # Count traits are decoded via expm1() on the log1p+z latent.  A
      # single dropout-noisy large draw can produce a latent ~ +5 SD,
      # which expm1 turns into thousands — mean-pooling with M=20
      # contaminates the whole cell.  Median-pool to stay robust
      # (Issue #40).
      vals <- if (pool_method %in% c("median", "mode")) row_median_decoded(nm) else
        rowMeans(sapply(decode_results, function(dr) as.numeric(dr$imputed[[nm]])))
      imputed[[nm]] <- as.integer(pmax(round(vals), 0L))

    } else if (tm$type == "ordinal") {
      K <- length(tm$levels)
      if (identical(pool_method, "mode")) {
        # Phase H: per-cell mode (majority vote) across M draws.
        # Preserves the K-class discrete structure better than
        # integer-mean+round when dropout spreads predictions across
        # adjacent classes.  See useful/MEMO_2026-05-01_phase_f_smoke_results.md
        # for the diagnostic that motivated this path.
        int_mat <- sapply(decode_results, function(dr) {
          as.integer(dr$imputed[[nm]]) - 1L
        })
        if (!is.matrix(int_mat)) int_mat <- matrix(int_mat, ncol = M)
        int_vals <- apply(int_mat, 1L, function(row) {
          row <- row[!is.na(row)]
          if (length(row) == 0L) return(NA_integer_)
          tab <- tabulate(row + 1L, nbins = K)
          which.max(tab) - 1L
        })
      } else {
        # Default: per-cell mean of integer class indices, rounded.
        # Backward-compatible with v0.9.1 behaviour.
        int_vals <- rowMeans(sapply(decode_results, function(dr) {
          as.integer(dr$imputed[[nm]]) - 1L
        }))
        int_vals <- as.integer(pmin(pmax(round(int_vals), 0), K - 1L))
      }
      imputed[[nm]] <- factor(tm$levels[int_vals + 1L],
                              levels = tm$levels, ordered = TRUE)

    } else if (tm$type == "binary") {
      avg_prob <- rowMeans(sapply(decode_results, function(dr) {
        dr$probabilities[[nm]]
      }))
      probs[[nm]] <- avg_prob
      pred_class <- ifelse(avg_prob >= 0.5, tm$levels[2], tm$levels[1])
      imputed[[nm]] <- factor(pred_class, levels = tm$levels)

    } else if (tm$type == "categorical") {
      prob_mats <- lapply(decode_results, function(dr) dr$probabilities[[nm]])
      avg_prob <- Reduce("+", prob_mats) / M
      colnames(avg_prob) <- tm$levels
      probs[[nm]] <- avg_prob
      pred_idx <- apply(avg_prob, 1, which.max)
      imputed[[nm]] <- factor(tm$levels[pred_idx], levels = tm$levels)

    } else if (tm$type == "proportion") {
      # Proportion traits are decoded via plogis() on the logit+z latent.
      # Extreme dropout draws push decoded values toward 0 or 1; mean
      # pooling contaminates the cell.  Median-pool for robustness
      # (Issue #40).
      vals <- if (pool_method %in% c("median", "mode")) row_median_decoded(nm) else
        rowMeans(sapply(decode_results, function(dr) dr$imputed[[nm]]))
      imputed[[nm]] <- vals

    } else if (tm$type == "zi_count") {
      # Magnitude col is expm1-decoded -- same hazard as "count".  Default
      # to median-pool; honour pool_method = "mean" when explicitly opted
      # in (pre-v0.9.2 byte-compat).  P(non-zero) is the mean of per-draw
      # decoder probabilities (always probability-pool, independent of
      # pool_method).
      vals <- if (pool_method %in% c("median", "mode")) row_median_decoded(nm) else
        rowMeans(sapply(decode_results, function(dr) as.numeric(dr$imputed[[nm]])))
      imputed[[nm]] <- as.integer(pmax(round(vals), 0L))
      avg_pnz <- rowMeans(sapply(decode_results, function(dr) {
        dr$probabilities[[nm]]
      }))
      probs[[nm]] <- avg_pnz
    }
  }

  list(imputed = imputed, probabilities = probs, latent_mean = latent_mean)
}


# ---- Internal: MC dropout SE computation ----------------------------------------

compute_mc_se <- function(decode_results, trait_map, baseline_se,
                          latent_mean, species_names) {
  # Combines two sources of uncertainty:
  # 1. Baseline (BM) SE -- phylogenetic imputation uncertainty
  # 2. MC dropout between-imputation SD -- GNN correction uncertainty
  # Combined in quadrature: SE_total = sqrt(SE_BM^2 + SE_MC^2)
  M <- length(decode_results)
  n <- nrow(decode_results[[1]]$imputed)
  n_traits <- length(trait_map)

  se_mat <- matrix(NA_real_, nrow = n, ncol = n_traits)
  colnames(se_mat) <- vapply(trait_map, "[[", character(1), "name")
  rownames(se_mat) <- species_names

  for (tm in trait_map) {
    nm <- tm$name
    lc <- tm$latent_cols

    if (tm$type %in% c("continuous", "count")) {
      # MC dropout between-imputation SD in original scale
      vals <- sapply(decode_results, function(dr) as.numeric(dr$imputed[[nm]]))
      se_mc <- apply(vals, 1, stats::sd)

      # Baseline SE in original scale
      se_latent <- baseline_se[, lc[1]]
      se_bm_orig <- se_latent * tm$sd
      if (tm$type == "continuous" && isTRUE(tm$log_transform)) {
        pred_log <- latent_mean[, lc[1]] * tm$sd + tm$mean
        se_bm_orig <- exp(pred_log) * se_bm_orig
      } else if (tm$type == "count") {
        pred_log1p <- latent_mean[, lc[1]] * tm$sd + tm$mean
        se_bm_orig <- exp(pred_log1p) * se_bm_orig
      }

      # Combine in quadrature
      se_mat[, nm] <- sqrt(se_bm_orig^2 + se_mc^2)

    } else if (tm$type == "ordinal") {
      vals <- sapply(decode_results, function(dr) {
        as.integer(dr$imputed[[nm]]) - 1L
      })
      se_mc <- apply(vals, 1, stats::sd)

      se_latent <- baseline_se[, lc[1]]
      se_bm_orig <- se_latent * tm$sd

      se_mat[, nm] <- sqrt(se_bm_orig^2 + se_mc^2)

    } else if (tm$type == "binary") {
      # Uncertainty = min(p, 1-p) of the mean probability across MC runs.
      # Between-imputation SD of probabilities is also available but
      # min(p, 1-p) is more interpretable (probability of being wrong).
      prob_vals <- sapply(decode_results, function(dr) dr$probabilities[[nm]])
      avg_prob  <- rowMeans(prob_vals)
      se_mat[, nm] <- pmin(avg_prob, 1 - avg_prob)

    } else if (tm$type == "categorical") {
      # Uncertainty = 1 - max class probability of the mean prob across runs.
      prob_mats <- lapply(decode_results, function(dr) dr$probabilities[[nm]])
      avg_prob  <- Reduce("+", prob_mats) / M
      se_mat[, nm] <- 1 - apply(avg_prob, 1, max)

    } else if (tm$type == "proportion") {
      # Between-imputation SD on (0,1) scale + baseline SE via delta method
      vals <- sapply(decode_results, function(dr) as.numeric(dr$imputed[[nm]]))
      se_mc <- apply(vals, 1, stats::sd)
      # Baseline SE on logit scale -> (0,1) via delta method: se * p * (1-p)
      se_latent <- baseline_se[, lc[1]]
      se_logit <- se_latent * tm$sd
      pred_logit <- latent_mean[, lc[1]] * tm$sd + tm$mean
      pred_p <- stats::plogis(pred_logit)
      se_bm_orig <- se_logit * pred_p * (1 - pred_p)
      se_mat[, nm] <- sqrt(se_bm_orig^2 + se_mc^2)

    } else if (tm$type == "zi_count") {
      # Between-imputation SD of expected values
      vals <- sapply(decode_results, function(dr) as.numeric(dr$imputed[[nm]]))
      se_mat[, nm] <- apply(vals, 1, stats::sd)
    }
  }
  se_mat
}


# ---- Internal: single-run SE computation ----------------------------------------

compute_single_se <- function(latent_mat, probs, trait_map, baseline_se,
                              species_names) {
  # Propagate baseline (BM) SE to original scale.
  # The baseline SE captures phylogenetic imputation uncertainty.
  # This uncertainty is always present, regardless of GNN correction magnitude.
  n <- nrow(latent_mat)
  n_traits <- length(trait_map)

  se_mat <- matrix(NA_real_, nrow = n, ncol = n_traits)
  colnames(se_mat) <- vapply(trait_map, "[[", character(1), "name")
  rownames(se_mat) <- species_names

  for (tm in trait_map) {
    nm <- tm$name
    lc <- tm$latent_cols

    if (tm$type == "continuous") {
      # Baseline SE in latent (z-score) scale -> original scale
      se_latent <- baseline_se[, lc]
      se_orig <- se_latent * tm$sd
      if (isTRUE(tm$log_transform)) {
        pred_log <- latent_mat[, lc] * tm$sd + tm$mean
        se_orig <- exp(pred_log) * se_orig  # delta method
      }
      se_mat[, nm] <- se_orig

    } else if (tm$type == "count") {
      se_latent <- baseline_se[, lc]
      se_log1p <- se_latent * tm$sd
      pred_log1p <- latent_mat[, lc] * tm$sd + tm$mean
      se_mat[, nm] <- exp(pred_log1p) * se_log1p  # delta method

    } else if (tm$type == "ordinal") {
      se_latent <- baseline_se[, lc]
      se_mat[, nm] <- se_latent * tm$sd

    } else if (tm$type == "binary") {
      # Uncertainty = probability of the non-modal (less likely) class.
      # Ranges 0 (certain) to 0.5 (maximally uncertain).
      # sqrt(p*(1-p)) is the Bernoulli SD of a *single draw*, not the SE of
      # the estimated probability, so we report min(p, 1-p) instead.
      prob <- probs[[nm]]
      se_mat[, nm] <- pmin(prob, 1 - prob)

    } else if (tm$type == "categorical") {
      # Uncertainty = 1 - max class probability (margin from certainty).
      # Ranges 0 (certain) to (K-1)/K (maximally uncertain).
      # Entropy would also work but has different units; 1-max(p) is
      # interpretable as the probability of being wrong.
      prob_mat <- probs[[nm]]
      se_mat[, nm] <- 1 - apply(prob_mat, 1, max)

    } else if (tm$type == "proportion") {
      # Baseline SE on logit scale -> (0,1) via delta method
      se_latent <- baseline_se[, lc]
      se_logit <- se_latent * tm$sd
      pred_logit <- latent_mat[, lc] * tm$sd + tm$mean
      pred_p <- stats::plogis(pred_logit)
      se_mat[, nm] <- se_logit * pred_p * (1 - pred_p)

    } else if (tm$type == "zi_count") {
      # Approximate SE via Bernoulli SD of the gate * count magnitude
      p_nz <- expit(latent_mat[, lc[1]])
      # Gate uncertainty
      se_gate <- sqrt(p_nz * (1 - p_nz))
      # Magnitude SE from baseline
      se_mag_latent <- baseline_se[, lc[2]]
      pred_log1p <- latent_mat[, lc[2]] * tm$sd + tm$mean
      count_hat <- pmax(expm1(pred_log1p), 0)
      se_mag_orig <- exp(pred_log1p) * se_mag_latent * tm$sd
      # Combined SE: delta method for product p_nz * count_hat
      se_mat[, nm] <- sqrt((count_hat * se_gate)^2 + (p_nz * se_mag_orig)^2)
    }
  }
  se_mat
}


# ---- Internal: latent-scale SE for coverage computation --------------------------
#
# Returns an n x p_latent matrix of SE in latent (z-score) scale.
# For continuous/count/ordinal: baseline SE from BM.
# For binary/categorical: NA (coverage is not computed for discrete types).
# When multiple stochastic draws exist, combines baseline SE with between-draw
# SD in latent scale via quadrature. This is predictive uncertainty accounting,
# not Rubin pooling.

compute_latent_se <- function(latent_runs, trait_map, baseline_se,
                              species_names) {
  n <- nrow(latent_runs[[1]])
  p_latent <- ncol(latent_runs[[1]])
  n_imp <- length(latent_runs)

  se_lat <- matrix(NA_real_, nrow = n, ncol = p_latent)
  rownames(se_lat) <- species_names

  for (tm in trait_map) {
    lc <- tm$latent_cols

    if (tm$type %in% c("continuous", "count", "ordinal", "proportion",
                       "multi_proportion")) {
      for (j in lc) {
        se_bm <- baseline_se[, j]

        if (n_imp > 1L) {
          vals <- sapply(latent_runs, function(lr) lr[, j])
          se_mc <- apply(vals, 1, stats::sd)
          se_lat[, j] <- sqrt(se_bm^2 + se_mc^2)
        } else {
          se_lat[, j] <- se_bm
        }
      }
    } else if (tm$type == "zi_count") {
      # Only magnitude column (col 2) gets latent SE
      j <- lc[2]
      se_bm <- baseline_se[, j]
      if (n_imp > 1L) {
        vals <- sapply(latent_runs, function(lr) lr[, j])
        se_mc <- apply(vals, 1, stats::sd)
        se_lat[, j] <- sqrt(se_bm^2 + se_mc^2)
      } else {
        se_lat[, j] <- se_bm
      }
    }
    # binary/categorical: leave as NA (coverage not applicable)
  }
  se_lat
}


# ---- Internal: reconstruct latent column names from trait_map --------------------

latent_names_from_map <- function(trait_map) {
  nms <- character(0)
  for (tm in trait_map) {
    if (tm$type == "categorical") {
      nms <- c(nms, paste0(tm$name, "=", tm$levels))
    } else if (tm$type == "zi_count") {
      nms <- c(nms, paste0(tm$name, "_gate"), paste0(tm$name, "_mag"))
    } else {
      nms <- c(nms, tm$name)
    }
  }
  nms
}


# ---- Print methods ---------------------------------------------------------------

#' @rdname fit_pigauto
#' @param x A fitted pigauto model.
#' @param ... Ignored. Included for compatibility with the base \code{print()}
#'   generic.
#' @section Printing:
#' Prints configuration, losses, gates and signal summaries. A printed signal label does not verify that a mean fallback was enabled. The `...` argument is currently unused.
#' @return The print method returns `x` invisibly.
#' @export
print.pigauto_fit <- function(x, ...) {
  cat("pigauto_fit\n")
  if (isFALSE(x$model_config$gnn)) cat("  GNN     : off (baseline only)\n")
  cat("  Species :", length(x$species_names), "\n")
  cat("  Traits  :", length(x$trait_names),
      "--", paste(x$trait_names, collapse = ", "), "\n")

  if (!is.null(x$trait_map)) {
    types <- vapply(x$trait_map, "[[", character(1), "type")
    type_tab <- table(types)
    cat("  Types   :",
        paste(names(type_tab), type_tab, sep = "=", collapse = ", "), "\n")
  }

  cat("  Architecture: hidden_dim =", x$model_config$hidden_dim,
      "| k_eigen =", x$model_config$k_eigen, "\n")

  if (is.finite(x$val_rmse)) {
    cat("  Best val loss :", round(x$val_rmse, 4), "\n")
  }
  if (!is.na(x$test_rmse)) {
    cat("  Test loss     :", round(x$test_rmse, 4), "\n")
  }
  if (!is.null(x$calibrated_gates)) {
    cat("  Gate calibration: yes\n")
  }
  if (!is.null(x$conformal_scores)) {
    cs <- x$conformal_scores[!is.na(x$conformal_scores)]
    cat("  Conformal scores:", length(cs), "traits\n")
  }
  if (!is.null(x$phylo_gate_triggered) &&
      any(!is.na(x$phylo_signal_per_trait))) {
    `%||%` <- function(a, b) if (is.null(a)) b else a
    thr <- x$phylo_signal_threshold %||% 0.2
    method <- x$phylo_signal_method %||% "lambda"
    sig <- x$phylo_signal_per_trait
    gated <- x$phylo_gate_triggered
    cat(sprintf("\nPhylogenetic signal (%s, threshold %.2f):\n", method, thr))
    if (any(gated, na.rm = TRUE)) {
      gated_names <- names(gated)[gated & !is.na(gated)]
      greek <- if (method == "lambda") "lambda" else "K"
      cat("  gated (BM skipped, using grand mean):",
           paste(sprintf("%s (%s=%.2f)", gated_names, greek, sig[gated_names]),
                 collapse = ", "), "\n")
    } else {
      greek <- if (method == "lambda") "lambda" else "K"
      cat(sprintf("  all %d traits have %s >= %.2f; safety floor is the fallback.\n",
                   sum(!is.na(sig)), greek, thr))
    }
  }
  invisible(x)
}


#' @rdname predict.pigauto_fit
#' @param x A pigauto prediction object.
#' @section Printing:
#' Prints dimensions, trait types, draw count and available probability/bounds components. Component presence does not establish interval coverage. The `...` argument is currently unused.
#' @return The print method returns `x` invisibly.
#' @export
print.pigauto_pred <- function(x, ...) {
  cat("pigauto_pred\n")
  cat("  Species :", length(x$species_names), "\n")
  cat("  Traits  :", length(x$trait_names), "\n")
  cat("  Imputations:", x$n_imputations, "\n")

  if (!is.null(x$trait_map)) {
    types <- vapply(x$trait_map, "[[", character(1), "type")
    type_tab <- table(types)
    cat("  Types   :",
        paste(names(type_tab), type_tab, sep = "=", collapse = ", "), "\n")
  }

  if (!is.null(x$probabilities) && length(x$probabilities) > 0) {
    cat("  Probability traits:",
        paste(names(x$probabilities), collapse = ", "), "\n")
  }
  if (!is.null(x$conformal_lower)) {
    cat("  Conformal 95% intervals: yes\n")
  }
  invisible(x)
}

.pigauto_assert_predictable_state <- function(object) {
  state <- object$model_state
  if (is.null(state) || !length(state)) return(invisible(NULL))
  item <- state[[1L]]
  rds_msg <- paste(
    "This pigauto_fit cannot be used after saveRDS()/readRDS().",
    "Use save_pigauto() and load_pigauto() instead."
  )
  if (is.raw(item)) {
    stop("This pigauto_fit still has a serialised model_state. ",
         "Load it with load_pigauto() after save_pigauto().",
         call. = FALSE)
  }
  if (!inherits(item, "torch_tensor")) {
    stop(rds_msg, call. = FALSE)
  }
  ok <- tryCatch({
    item$device
    TRUE
  }, error = function(e) FALSE)
  if (!ok) stop(rds_msg, call. = FALSE)
  invisible(NULL)
}


# ---- Internal: per-cell Mondrian conformal half-width (latent scale) ------
#' Per-cell Mondrian conformal half-widths (internal)
#'
#' Extracted from `predict.pigauto_fit()`'s conformal-interval loop (B2,
#' 2026-08-16) so [multi_impute()]'s conformal draws can reuse the identical
#' per-row near/far stratum logic instead of the single global conformal
#' score. `predict.pigauto_fit()` calls this and its numeric output is
#' unchanged by the refactor.
#'
#' Only trait types scored by `compute_conformal_scores()` (continuous,
#' count, ordinal, proportion, zi_count magnitude) get a populated column;
#' other columns, and any trait with no conformal score at all, are left
#' `NA`. When `object$conformal_method` is not `"mondrian"`, or the fit
#' does not carry the pieces Mondrian needs (`conformal_mondrian`,
#' `X_scaled`, and a non-NULL `D_sq`), every populated column is just the
#' constant global score repeated `n` times -- i.e. this degrades to the
#' "split" / "bootstrap" behaviour exactly.
#'
#' @param object a `pigauto_fit`.
#' @param D_sq `n_species x n_species` squared cophenetic distance matrix
#'   (`object$graph$D_sq`), or `NULL`.
#' @param trait_map trait map (list of descriptors) for the predicted data.
#' @param n number of prediction rows. Mondrian is single-obs-only, so this
#'   is `n_species`.
#' @return `NULL` if `object$conformal_scores` is `NULL`; otherwise a list
#'   with `scores` (`n x n_traits` matrix, latent scale, `NA` columns for
#'   traits with no conformal score; column names are trait names) and
#'   `score_cols` (named integer vector, trait name -> the latent column
#'   each trait's score was computed on; zi_count uses the magnitude
#'   column, not the gate).
#' @keywords internal
#' @noRd
mondrian_cell_scores <- function(object, D_sq, trait_map, n) {
  cs <- object$conformal_scores
  if (is.null(cs)) return(NULL)

  trait_names <- vapply(trait_map, "[[", character(1), "name")
  n_traits <- length(trait_names)
  scores <- matrix(NA_real_, nrow = n, ncol = n_traits,
                    dimnames = list(NULL, trait_names))
  score_cols <- stats::setNames(integer(n_traits), trait_names)

  use_mondrian <- identical(object$conformal_method, "mondrian") &&
    !is.null(object$conformal_mondrian) &&
    !is.null(D_sq) && !is.null(object$X_scaled)

  obs_mask_train <- NULL
  if (use_mondrian) {
    obs_mask_train <- !is.na(object$X_scaled)
    hold <- c(object$splits$val_idx, object$splits$test_idx)
    if (length(hold)) obs_mask_train[hold] <- FALSE
  }

  for (tm in trait_map) {
    nm <- tm$name
    lc <- tm$latent_cols
    if (!(tm$type %in%
          c("continuous", "count", "ordinal", "proportion", "zi_count"))) next
    if (is.na(cs[nm])) next

    # zi_count is scored on the magnitude (log1p-z) column, not the
    # Bernoulli gate -- must match fit_helpers.R's compute_conformal_scores()
    # `score_col`.
    score_col <- if (identical(tm$type, "zi_count")) lc[2L] else lc[1L]
    score_cols[nm] <- score_col

    q_vec <- rep(cs[nm], n)
    if (use_mondrian) {
      mo <- object$conformal_mondrian[[nm]]
      if (!is.null(mo) && !isTRUE(mo$fallback)) {
        obs_idx <- which(obs_mask_train[, score_col])
        if (length(obs_idx) > 0L) {
          locality <- mondrian_locality(D_sq, obs_idx, seq_len(n), k = 5L)
          loc_ok <- is.finite(locality)
          far  <- loc_ok & (locality > mo$threshold)
          near <- loc_ok & !far
          q_vec[far]  <- mo$far_score
          q_vec[near] <- mo$near_score
        }
      }
    }
    scores[, nm] <- q_vec
  }

  list(scores = scores, score_cols = score_cols)
}
