#' Preprocess trait data: align to tree, encode into latent space
#'
#' Aligns species in the trait data frame to the tree, detects or accepts
#' trait types (continuous, binary, categorical, ordinal, count, proportion,
#' zi_count), and encodes each trait into a continuous latent matrix.
#'
#' When each species has one observation (the default), output rows match
#' \code{tree$tip.label} order.  When \code{species_col} is supplied,
#' multiple observations per species are supported: the output matrix has
#' one row per observation, plus an \code{obs_to_species} mapping for the
#' GNN (which operates at species level).
#'
#' @details
#' **Automatic type detection** (when \code{trait_types = NULL}) follows the
#' R class of each column — no user input is required for most data:
#'
#' \ifelse{html}{\out{
#' <table>
#' <thead><tr><th scope="col"><strong>R class</strong></th><th scope="col"><strong>pigauto type</strong></th></tr></thead>
#' <tbody>
#' <tr><td><code>numeric</code> (non-integer)</td><td>continuous</td></tr>
#' <tr><td><code>integer</code>, all nonnegative</td><td>count</td></tr>
#' <tr><td><code>integer</code>, any negative value</td><td>continuous</td></tr>
#' <tr><td><code>factor</code> with 2 levels</td><td>binary</td></tr>
#' <tr><td><code>factor</code> (unordered) with &gt;2 levels</td><td>categorical</td></tr>
#' <tr><td><code>ordered</code> with 2 levels</td><td>binary</td></tr>
#' <tr><td><code>ordered</code> with &gt;2 levels</td><td>ordinal</td></tr>
#' <tr><td><code>character</code></td><td>converted to <code>factor</code>, then binary or categorical</td></tr>
#' <tr><td><code>logical</code></td><td>binary (FALSE = 0, TRUE = 1)</td></tr>
#' </tbody>
#' </table>
#' }}{
#' \tabular{ll}{
#'   \strong{R class} \tab \strong{pigauto type} \cr
#'   \code{numeric} (non-integer) \tab continuous \cr
#'   \code{integer}, all nonnegative \tab count \cr
#'   \code{integer}, any negative value \tab continuous \cr
#'   \code{factor} with 2 levels \tab binary \cr
#'   \code{factor} (unordered) with >2 levels \tab categorical \cr
#'   \code{ordered} with 2 levels \tab binary \cr
#'   \code{ordered} with >2 levels \tab ordinal \cr
#'   \code{character} \tab converted to \code{factor}, then binary or categorical \cr
#'   \code{logical} \tab binary (FALSE = 0, TRUE = 1) \cr
#' }
#' }
#'
#' Whole-number measurements can still be scientifically continuous. Use
#' `trait_types = c(measurement = "continuous")` to override count detection.
#'
#' **Two types require an explicit override** because they cannot be
#' distinguished from their R class alone:
#' \describe{
#'   \item{\code{"proportion"}}{A \code{numeric} column bounded 0–1 looks
#'     identical to continuous.  Declare it explicitly:
#'     \code{trait_types = c(SurvivalRate = "proportion")}.
#'     Encoded via \code{qlogis(clamp(x, 0.001, 0.999))}.}
#'   \item{\code{"zi_count"}}{An \code{integer} column with excess zeros
#'     looks identical to count.  Declare it explicitly:
#'     \code{trait_types = c(Parasites = "zi_count")}.
#'     Encoded as a binary zero/non-zero gate plus \code{log1p}-z magnitude.}
#' }
#'
#' **Practical examples of type assignment:**
#' \itemize{
#'   \item Body mass (\code{numeric}, all positive) → \code{continuous},
#'     auto-log-transformed.
#'   \item Clutch size (\code{integer}) → \code{count}.
#'   \item Migratory (\code{factor} with levels "Yes"/"No") → \code{binary}.
#'   \item Diet (\code{factor} with >2 levels) → \code{categorical}.
#'   \item IUCN status (\code{ordered} factor, LC < NT < VU < EN < CR) →
#'     \code{ordinal}.  If left as an unordered factor, it becomes
#'     \code{categorical} — both are valid depending on the question.
#'   \item Parasite load (\code{integer} with many zeros) → needs
#'     \code{trait_types = c(Parasites = "zi_count")}.
#'   \item Survival rate (\code{numeric}, values in 0 to 1) → needs
#'     \code{trait_types = c(Survival = "proportion")}.
#' }
#'
#' **Species and composition alignment:** trait rows whose species are absent
#' from the tree are dropped with a warning. Tree tips without trait rows
#' remain in the aligned data with all trait values missing; no shared species
#' is an error. For a \code{multi_proportion_groups} composition, a row is
#' used only when every component is present, so a partly missing composition
#' is treated as missing as a whole. Complete compositions must be
#' non-negative and sum to 1 within 1 percent; zero components are replaced
#' by a small positive value for the log-ratio transform.
#'
#' **Latent encoding** per type:
#' \describe{
#'   \item{continuous}{optional \code{log()}, then z-score (1 latent column)}
#'   \item{binary}{0/1 encoding (1 latent column)}
#'   \item{count}{\code{log1p()}, then z-score (1 latent column)}
#'   \item{ordinal}{integer coding (0 to K-1), then z-score (1 latent column)}
#'   \item{categorical}{one-hot encoding (K latent columns)}
#'   \item{proportion}{\code{qlogis(clamp(x, 0.001, 0.999))}, then z-score (1 latent column)}
#'   \item{zi_count}{gate (0/1) + \code{log1p}-z of non-zeros (2 latent columns)}
#'   \item{multi_proportion}{centred log-ratio (CLR) + per-component z-score
#'     (K latent columns per group).  Rows must sum to 1.  Declared via the
#'     \code{multi_proportion_groups} argument, not \code{trait_types}.}
#' }
#'
#' @param traits \code{data.frame} with species as row names (one row per
#'   species), or with a species column identified by \code{species_col}
#'   (potentially multiple rows per species).  Columns may be numeric,
#'   integer, factor, ordered, character, or logical.
#' @param tree object of class \code{"phylo"}.
#' @param species_col character.  Name of the column in \code{traits} that
#'   identifies species.  When supplied, \code{traits} may have multiple
#'   rows per species.  The column is removed from trait columns before
#'   encoding.  Default \code{NULL} uses row names (one row per species).
#' @param trait_types named character vector overriding auto-detection,
#'   e.g. \code{c(Mass = "continuous", Diet = "categorical")}.
#'   Valid types: \code{"continuous"}, \code{"binary"}, \code{"categorical"},
#'   \code{"ordinal"}, \code{"count"}, \code{"proportion"}, \code{"zi_count"}.
#'   Proportion and zi_count are override-only (not auto-detected).
#'   Unspecified traits are auto-detected.  Note that
#'   \code{"multi_proportion"} is NOT set here — use
#'   \code{multi_proportion_groups} instead.
#' @param ordinal_levels named list giving the scientific order of ordinal
#'   levels, e.g. \code{list(status = c("LC", "NT", "VU", "EN", "CR"))}.
#'   Each named column is coerced to an ordered factor with exactly those
#'   levels before type detection, so no \code{trait_types} entry is needed:
#'   the coerced column detects as \code{"ordinal"}, or as \code{"binary"}
#'   (order preserved) when exactly two levels are declared — the same
#'   detection an \code{ordered()} column with those levels receives.
#'   Observed values absent from the declared levels are an error.  Same
#'   semantics as the \code{ordinal_levels} argument of
#'   \code{\link{read_traits}}.  Default \code{NULL}.
#' @param multi_proportion_groups named list declaring compositional
#'   (multi-proportion) trait groups.  Each element is a character vector
#'   of column names whose row-wise values sum to 1 (e.g.
#'   \code{list(diet = c("plants", "insects", "fish"))}).  The group
#'   name becomes a single trait in the output, encoded via centred
#'   log-ratio (CLR) + per-component z-score.  Group names must NOT
#'   match any column in \code{traits}.  Default \code{NULL}.
#' @param log_cols character vector of continuous trait names to
#'   log-transform.  Default \code{NULL} means auto-detect (log if all
#'   observed values are positive).  Set to \code{character(0)} to disable.
#' @param log_transform logical.  Legacy parameter: if \code{TRUE} and
#'   \code{log_cols} is \code{NULL}, log-transform all continuous traits
#'   with all-positive values.  Overridden by \code{log_cols} when both
#'   are supplied.  Traits already on a log scale should not be logged
#'   again: set \code{log_transform = FALSE} or leave them out of
#'   \code{log_cols} (see \code{\link{impute}}).
#' @param center logical. Subtract column means for continuous traits, log1p
#'   counts, ordinal scores, logit proportions, nonzero zero-inflated-count
#'   magnitudes, and each compositional CLR component. Binary/categorical
#'   indicators and the zero-inflation gate are unchanged. Default
#'   \code{TRUE}.
#' @param scale logical. Divide those same transformed values by their column
#'   SDs; binary/categorical indicators and the zero-inflation gate are
#'   unchanged. Default \code{TRUE}.
#' @param covariates data.frame or numeric matrix of environmental covariates.
#'   Covariates are conditioners: they inform imputation but are not themselves
#'   imputed, so they must be \strong{fully observed} (no NAs — if a variable
#'   has missing values, put it in \code{traits} instead).  Rows are aligned
#'   to the same species / observation order as \code{X_scaled} after traits
#'   are matched to the tree.  Single-obs: rownames should match
#'   \code{tree$tip.label} (they are reordered to tip order).  Multi-obs:
#'   include the same \code{species_col} and keep observations in the same
#'   order within each species in both frames. Repeated species labels alone
#'   do not identify individual observations: matching takes the next unused
#'   covariate row for each species. Align by an explicit observation ID before
#'   calling if within-species rows were shuffled independently.
#'   Unnamed covariates are assumed to share the input-row order of
#'   \code{traits} and receive the same drop / reorder.  Matching
#'   \code{nrow} alone is not enough — unmatched species names are an error.
#'   \describe{
#'     \item{Numeric / integer columns}{z-scored automatically.}
#'     \item{Factor / ordered columns}{one-hot encoded (K binary columns per
#'       factor with K levels).  Column names become \code{"var.level"}.}
#'     \item{Character / logical columns}{coerced to factor, then one-hot.}
#'   }
#'   Default \code{NULL} (no covariates).
#' @return A list of class \code{"pigauto_data"} with components:
#'   \describe{
#'     \item{X_scaled}{Numeric matrix (n_obs x p_latent), latent encoding.
#'       When \code{species_col} is \code{NULL}, n_obs = n_species.}
#'     \item{X_raw}{Numeric matrix of continuous traits after optional log
#'       but before z-scoring (for backward compatibility).}
#'     \item{X_original}{Original data.frame (aligned to tree, before encoding).}
#'     \item{means}{Named numeric vector of scalar means used for centering
#'       continuous, count, ordinal, proportion, and zero-inflated-count
#'       magnitude traits. Multi-proportion component means are vectors stored
#'       in the corresponding \code{trait_map} entry.}
#'     \item{sds}{Named numeric vector of scalar SDs for those same traits.
#'       Multi-proportion component SDs are vectors stored in the corresponding
#'       \code{trait_map} entry.}
#'     \item{species_names}{Character vector of unique species matching
#'       \code{tree$tip.label} order (length = n_species).}
#'     \item{obs_species}{Character vector of species labels per observation
#'       (length = n_obs).  When multi-obs, can have duplicates.
#'       \code{NULL} when \code{species_col} is \code{NULL}.}
#'     \item{obs_to_species}{Integer vector (length = n_obs) mapping each
#'       observation to its species index in \code{species_names}.
#'       \code{NULL} when \code{species_col} is \code{NULL}.}
#'     \item{n_species}{Integer, number of unique species.}
#'     \item{n_obs}{Integer, number of observations (= n_species when
#'       single-obs).}
#'     \item{multi_obs}{Logical, \code{TRUE} whenever \code{species_col}
#'       is supplied, including with exactly one observation per species.}
#'     \item{trait_names}{Character vector of original trait names.}
#'     \item{latent_names}{Character vector of latent column names.}
#'     \item{trait_map}{List of trait descriptors (see Details).}
#'     \item{p_latent}{Integer, total number of latent columns.}
#'     \item{log_transform}{Logical, legacy field (TRUE if any continuous
#'       trait was log-transformed).}
#'   }
#' @examples
#' # Single-obs per species (backward compatible)
#' data(avonet300, tree300, package = "pigauto")
#' traits <- avonet300
#' rownames(traits) <- traits$Species_Key
#' traits$Species_Key <- NULL
#' pd <- preprocess_traits(traits, tree300)
#' dim(pd$X_scaled)   # 300 x p_latent
#'
#' # Multi-obs per species (via species_col)
#' pd2 <- preprocess_traits(avonet300, tree300, species_col = "Species_Key")
#' pd2$n_obs      # number of observations
#' pd2$n_species  # number of unique species
#'
#' @importFrom ape keep.tip
#' @export
preprocess_traits <- function(traits, tree, species_col = NULL,
                              trait_types = NULL,
                              multi_proportion_groups = NULL,
                              log_cols = NULL, log_transform = TRUE,
                              center = TRUE, scale = TRUE,
                              covariates = NULL,
                              ordinal_levels = NULL) {
  if (!is.data.frame(traits)) stop("'traits' must be a data.frame.")
  if (!inherits(tree, "phylo")) stop("'tree' must be a phylo object.")
  traits <- .apply_ordinal_levels(traits, ordinal_levels)

  # Keep input identity before dropping data-only species.  Internal rows are
  # later reordered to tree order, while build_completed() must always target
  # the user's original rows.  Synthetic tree-only rows receive NA below.
  original_row_id <- seq_len(nrow(traits))

  # Phylogenetic imputation needs >= 2 tips to define any signal.  A
  # 1-tip tree silently produces a 1-row pigauto_data that downstream
  # fit_baseline / fit_pigauto cannot use; better to fail loudly here.
  if (length(tree$tip.label) < 2L) {
    stop("`tree` has fewer than 2 tips (", length(tree$tip.label),
         "). Phylogenetic imputation requires at least 2 species.",
         call. = FALSE)
  }

  # ---- Validate multi_proportion_groups -------------------------------------
  if (!is.null(multi_proportion_groups)) {
    if (!is.list(multi_proportion_groups) ||
        is.null(names(multi_proportion_groups)) ||
        any(names(multi_proportion_groups) == "")) {
      stop("'multi_proportion_groups' must be a named list, e.g. ",
           "list(colour = c('black','blue','red')).", call. = FALSE)
    }
    all_group_cols <- unlist(multi_proportion_groups, use.names = FALSE)
    if (anyDuplicated(all_group_cols)) {
      stop("Columns appear in more than one multi_proportion group: ",
           paste(all_group_cols[duplicated(all_group_cols)], collapse = ", "),
           call. = FALSE)
    }
    if (any(names(multi_proportion_groups) %in% colnames(traits))) {
      bad <- intersect(names(multi_proportion_groups), colnames(traits))
      stop("multi_proportion group name(s) collide with existing column(s): ",
           paste(bad, collapse = ", "),
           ". Pick group names that are NOT column names in `traits`.",
           call. = FALSE)
    }
    missing_cols <- setdiff(all_group_cols, colnames(traits))
    if (length(missing_cols) > 0) {
      stop("multi_proportion_groups references columns not in `traits`: ",
           paste(missing_cols, collapse = ", "), call. = FALSE)
    }
    for (gnm in names(multi_proportion_groups)) {
      gcols <- multi_proportion_groups[[gnm]]
      if (length(gcols) < 2L) {
        stop("multi_proportion group '", gnm, "' needs >= 2 columns.",
             call. = FALSE)
      }
      sub <- traits[, gcols, drop = FALSE]
      if (!all(vapply(sub, is.numeric, logical(1)))) {
        stop("multi_proportion group '", gnm, "' has non-numeric columns.",
             call. = FALSE)
      }
    }
  }

  # ---- Determine species identity per row -----------------------------------
  multi_obs <- !is.null(species_col)
  if (multi_obs) {
    if (!species_col %in% names(traits)) {
      stop("species_col '", species_col, "' not found in traits.")
    }
    obs_species_raw <- as.character(traits[[species_col]])
    traits[[species_col]] <- NULL  # remove from trait columns
  } else {
    if (is.null(rownames(traits))) {
      stop("'traits' must have species as row names (or supply species_col).")
    }
    obs_species_raw <- rownames(traits)
  }

  # ---- Align species to tree ------------------------------------------------
  unique_species <- unique(obs_species_raw)
  in_tree  <- unique_species %in% tree$tip.label
  in_data  <- tree$tip.label %in% unique_species

  n_dropped_sp <- sum(!in_tree)
  if (n_dropped_sp > 0) {
    warning(n_dropped_sp, " species in traits not found in tree: excluded from modeling; ",
            "impute() keeps their input rows unchanged in completed data.", call. = FALSE)
    keep_rows <- obs_species_raw %in% tree$tip.label
    traits <- traits[keep_rows, , drop = FALSE]
    obs_species_raw <- obs_species_raw[keep_rows]
    original_row_id <- original_row_id[keep_rows]
    unique_species <- unique(obs_species_raw)
  }
  # If alignment leaves zero species in common, phylogenetic imputation
  # cannot proceed.  Fail loudly here rather than producing an all-NA
  # X_scaled that downstream fit_pigauto would only fail on much later.
  if (length(unique_species) == 0L) {
    stop("No overlap between trait row names and tree tip labels: ",
         "0 species in common. Check that rownames(traits) match ",
         "tree$tip.label (or pass `species_col` if rows are not species).",
         call. = FALSE)
  }
  n_missing_from_data <- sum(!in_data)
  if (n_missing_from_data > 0) {
    message(n_missing_from_data,
            " tree tip(s) have no trait data and will have all-NA rows.")
  }

  if (multi_obs) {
    # Order by tree tip order; within species, preserve original row order
    sp_order <- tree$tip.label[tree$tip.label %in% unique_species]
    sp_rank  <- setNames(seq_along(sp_order), sp_order)
    row_order <- order(sp_rank[obs_species_raw])
    traits <- traits[row_order, , drop = FALSE]
    obs_species_raw <- obs_species_raw[row_order]
    rownames(traits) <- NULL

    # `input_row_order[k]` = original input-row index that was placed at
    # internal position k.  Used by `build_completed()` (and any downstream
    # caller that needs to re-align internal-order results back to the
    # user's input row order).
    input_row_order <- as.integer(original_row_id[row_order])

    # Add all-NA rows for tree tips missing from data
    missing_tips <- tree$tip.label[!in_data]
    if (length(missing_tips) > 0) {
      na_rows <- traits[rep(NA_integer_, length(missing_tips)), , drop = FALSE]
      rownames(na_rows) <- NULL
      traits <- rbind(traits, na_rows)
      obs_species_raw <- c(obs_species_raw, missing_tips)
      # Pad input_row_order with NAs for these synthetic rows (no original
      # input row corresponds to them).
      input_row_order <- c(input_row_order,
                            rep(NA_integer_, length(missing_tips)))
    }

    # Build species-level outputs
    species_names <- tree$tip.label[tree$tip.label %in%
                                      c(unique_species, missing_tips)]
    obs_to_species <- match(obs_species_raw, species_names)
    n_obs <- nrow(traits)
    n_species <- length(species_names)
    obs_species <- obs_species_raw
  } else {
    # Single-obs path: reorder rows to match tree$tip.label exactly
    idx <- match(tree$tip.label, rownames(traits))
    # `input_row_order[k]` = original input-row index that was placed at
    # internal position k.  `idx[k]` is the row of `traits` (= input row
    # index, since rownames are preserved at this point) that maps to
    # tree$tip.label[k].  When a tip has no input row, idx[k] = NA.
    input_row_order <- as.integer(original_row_id[idx])
    traits <- traits[idx, , drop = FALSE]
    rownames(traits) <- tree$tip.label

    species_names <- tree$tip.label
    obs_species <- NULL
    obs_to_species <- NULL
    n_obs <- nrow(traits)
    n_species <- n_obs
  }

  # ---- Convert convenience types -------------------------------------------
  for (nm in names(traits)) {
    if (is.character(traits[[nm]])) traits[[nm]] <- factor(traits[[nm]])
    if (is.logical(traits[[nm]]))   traits[[nm]] <- factor(traits[[nm]],
                                                           levels = c(FALSE, TRUE))
  }

  X_original <- traits  # save before encoding

  # ---- Detect trait types ---------------------------------------------------
  # Columns that belong to a multi_proportion group are excluded from
  # the per-column type detection — they're handled as a single group entry
  # in build_trait_map below.
  group_member_cols <- unlist(multi_proportion_groups, use.names = FALSE)
  standalone_cols   <- setdiff(colnames(traits), group_member_cols)
  types <- detect_trait_types(traits[, standalone_cols, drop = FALSE],
                              trait_types)

  # ---- Determine which continuous traits to log-transform -------------------
  cont_names <- names(types)[types == "continuous"]
  if (!is.null(log_cols)) {
    # Explicit list overrides everything
    log_set <- intersect(log_cols, cont_names)
  } else if (log_transform) {
    # Legacy: log all continuous traits with all-positive observed values
    log_set <- vapply(cont_names, function(nm) {
      vals <- traits[[nm]][!is.na(traits[[nm]])]
      length(vals) > 0 && all(vals > 0)
    }, logical(1))
    log_set <- cont_names[log_set]
  } else {
    log_set <- character(0)
  }

  # ---- Build trait map and encode to latent ---------------------------------
  # Pass multi_proportion_groups so build_trait_map can add one entry per group
  trait_map <- build_trait_map(traits, types, log_set, center, scale,
                               multi_proportion_groups = multi_proportion_groups)
  latent    <- encode_to_latent(traits, trait_map)

  # ---- Backward-compat X_raw (continuous traits only) -----------------------
  cont_cols <- which(types[colnames(traits)] == "continuous")
  if (length(cont_cols) > 0) {
    X_raw <- as.matrix(traits[, cont_cols, drop = FALSE])
    storage.mode(X_raw) <- "double"
    for (nm in intersect(log_set, colnames(X_raw))) {
      X_raw[, nm] <- log(X_raw[, nm])
    }
  } else {
    X_raw <- matrix(nrow = nrow(traits), ncol = 0)
  }

  # ---- Backward-compat means/sds vectors ------------------------------------
  # Note: multi_proportion traits have K-vector mean/sd (one per component),
  # not a scalar — we store NA_real_ in these scalar-per-trait back-compat
  # vectors since no downstream code legitimately consumes a scalar mean/sd
  # for multi_proportion. The full mean/sd lives in trait_map[[gnm]]$mean.
  all_means <- vapply(trait_map, function(tm) {
    if (!is.null(tm$mean) && length(tm$mean) == 1L && !is.na(tm$mean)) {
      tm$mean
    } else {
      NA_real_
    }
  }, numeric(1))
  names(all_means) <- vapply(trait_map, "[[", character(1), "name")

  all_sds <- vapply(trait_map, function(tm) {
    if (!is.null(tm$sd) && length(tm$sd) == 1L && !is.na(tm$sd)) {
      tm$sd
    } else {
      NA_real_
    }
  }, numeric(1))
  names(all_sds) <- names(all_means)

  # ---- Environmental covariates (conditioners, not imputed) ------------------
  # Supports: numeric columns (z-scored), factor/ordered columns (one-hot).
  # No NAs allowed — covariates are conditioning variables, not imputation
  # targets.  If a variable has missing values, put it in `traits` instead.
  cov_scaled <- NULL
  cov_means  <- NULL
  cov_sds    <- NULL
  cov_names  <- NULL

  if (!is.null(covariates)) {
    if (!is.data.frame(covariates) && !is.matrix(covariates)) {
      stop("`covariates` must be a data.frame or matrix.", call. = FALSE)
    }
    # Coerce matrix to data.frame so column classes are preserved
    if (is.matrix(covariates)) {
      covariates <- as.data.frame(covariates)
    }

    covariates <- align_covariates_to_obs(
      covariates       = covariates,
      species_names    = species_names,
      obs_species      = if (multi_obs) obs_species else species_names,
      multi_obs        = multi_obs,
      species_col      = species_col,
      input_row_order  = input_row_order
    )

    if (nrow(covariates) != n_obs) {
      stop("`covariates` has ", nrow(covariates), " rows but traits has ",
           n_obs, " rows after alignment. They must match.", call. = FALSE)
    }
    if (any(vapply(covariates, anyNA, logical(1)))) {
      stop("`covariates` must be fully observed (no NAs). ",
           "If a covariate has missing values, include it in `traits` ",
           "instead so pigauto can impute it jointly.",
           call. = FALSE)
    }
    for (j in seq_along(covariates)) {
      col <- covariates[[j]]
      if (!is.numeric(col)) next
      bad <- which(!is.finite(col))
      if (!length(bad)) next
      nm <- names(covariates)[j]
      if (is.null(nm) || is.na(nm) || !nzchar(nm)) nm <- paste0("[,", j, "]")
      stop("Column '", nm, "' in `covariates` contains a non-finite value (",
           col[[bad[[1L]]]], "). Covariates must be finite.",
           call. = FALSE)
    }

    # Encode each covariate column -----------------------------------------
    # numeric/integer  → z-score (1 column)
    # factor/ordered   → one-hot (K columns, column names = "var.levelK")
    # character/logical → coerced to factor then one-hot
    cov_parts      <- list()
    cov_means_list <- list()   # only for numeric cols
    cov_sds_list   <- list()

    raw_names <- colnames(covariates)
    if (is.null(raw_names))
      raw_names <- paste0("cov", seq_len(ncol(covariates)))

    for (j in seq_along(raw_names)) {
      nm  <- raw_names[j]
      col <- covariates[[j]]

      if (is.character(col) || is.logical(col)) col <- factor(col)

      if (is.factor(col) || is.ordered(col)) {
        # One-hot encoding (drop-none; model learns to handle collinearity)
        levs   <- levels(col)
        K      <- length(levs)
        oh_mat <- matrix(0.0, nrow = n_obs, ncol = K)
        colnames(oh_mat) <- paste0(nm, ".", levs)
        for (k in seq_len(K)) oh_mat[, k] <- as.numeric(col == levs[k])
        cov_parts[[nm]] <- oh_mat
        # No z-score means/sds for one-hot columns
        cov_means_list[[nm]] <- rep(NA_real_, K)
        cov_sds_list[[nm]]   <- rep(NA_real_, K)

      } else if (is.numeric(col) || is.integer(col)) {
        col   <- as.double(col)
        cmean <- mean(col)
        csd   <- stats::sd(col)
        if (!is.finite(csd) || csd < 1e-12) csd <- 1.0  # constant column
        scaled_col <- (col - cmean) / csd
        mat <- matrix(scaled_col, ncol = 1, dimnames = list(NULL, nm))
        cov_parts[[nm]]      <- mat
        cov_means_list[[nm]] <- cmean
        cov_sds_list[[nm]]   <- csd

      } else {
        stop("Column '", nm, "' in `covariates` has unsupported class '",
             paste(class(col), collapse = "/"), "'. ",
             "Use numeric, integer, factor, ordered, character, or logical.",
             call. = FALSE)
      }
    }

    cov_scaled <- do.call(cbind, cov_parts)
    cov_names  <- colnames(cov_scaled)
    cov_means  <- unlist(cov_means_list)
    cov_sds    <- unlist(cov_sds_list)
    names(cov_means) <- cov_names
    names(cov_sds)   <- cov_names
  }

  structure(
    list(
      X_scaled       = latent$X,
      X_raw          = X_raw,
      X_original     = X_original,
      means          = all_means,
      sds            = all_sds,
      species_names  = species_names,
      obs_species    = obs_species,
      obs_to_species = obs_to_species,
      input_row_order = input_row_order,
      n_species      = n_species,
      n_obs          = n_obs,
      multi_obs      = multi_obs,
      trait_names    = colnames(traits),
      latent_names   = colnames(latent$X),
      trait_map      = trait_map,
      p_latent       = ncol(latent$X),
      log_transform  = length(log_set) > 0,
      covariates     = cov_scaled,
      cov_means      = cov_means,
      cov_sds        = cov_sds,
      cov_names      = cov_names
    ),
    class = "pigauto_data"
  )
}


# ---- Internal: align covariates to X_scaled / obs order ---------------------
# Named single-obs covariates → match species_names (tree tip order).
# Multi-obs + species_col → match obs_species, consuming rows per species.
# Unnamed → same input_row_order permutation as traits.
align_covariates_to_obs <- function(covariates,
                                    species_names,
                                    obs_species,
                                    multi_obs,
                                    species_col,
                                    input_row_order) {
  target_sp <- if (is.null(obs_species)) species_names else obs_species
  n_target  <- length(target_sp)
  n_cov     <- nrow(covariates)
  rn        <- rownames(covariates)
  trivial_rn <- is.null(rn) || identical(rn, as.character(seq_len(n_cov)))

  id_col <- NULL
  if (!is.null(species_col) && species_col %in% names(covariates)) {
    id_col <- species_col
  }

  drop_id_col <- function(x, col) {
    if (is.null(col) || !col %in% names(x)) return(x)
    x[, setdiff(names(x), col), drop = FALSE]
  }

  stop_unmatched <- function(missing, what) {
    stop("Cannot match covariate rows to ", what, ". ",
         "Unmatched species: ",
         paste(utils::head(missing, 8L), collapse = ", "),
         if (length(missing) > 8L) ", ..." else "",
         ". Matching nrow alone is not enough; names must identify ",
         "the same species as aligned traits.",
         call. = FALSE)
  }

  if (!multi_obs && !trivial_rn) {
    idx <- match(target_sp, rn)
    if (anyNA(idx)) {
      stop_unmatched(target_sp[is.na(idx)], "species")
    }
    return(drop_id_col(covariates[idx, , drop = FALSE], id_col))
  }

  if (!is.null(id_col)) {
    cov_sp <- as.character(covariates[[id_col]])
    cov_data <- drop_id_col(covariates, id_col)
    used <- logical(n_cov)
    idx  <- integer(n_target)
    for (i in seq_len(n_target)) {
      hit <- which(!used & cov_sp == target_sp[[i]])
      if (!length(hit)) {
        stop_unmatched(target_sp[[i]], "observations")
      }
      idx[[i]] <- hit[[1L]]
      used[[idx[[i]]]] <- TRUE
    }
    return(cov_data[idx, , drop = FALSE])
  }

  if (anyNA(input_row_order) || n_cov < max(input_row_order, na.rm = TRUE)) {
    stop("`covariates` has ", n_cov, " rows but traits has ",
         n_target, " rows after alignment. They must match ",
         "(unnamed covariates follow the input-row order of `traits`).",
         call. = FALSE)
  }
  covariates[input_row_order, , drop = FALSE]
}


# ---- Internal: detect trait types -------------------------------------------

.validate_declared_trait_type <- function(nm, x, tp) {
  obs <- x[!is.na(x)]
  ok <- switch(
    tp,
    binary = is.logical(x) ||
      (is.factor(x) && nlevels(x) == 2L) ||
      (is.numeric(x) && length(obs) > 0L && all(obs %in% c(0, 1))),
    categorical = is.factor(x) && !is.ordered(x) && nlevels(x) > 2L,
    ordinal = is.ordered(x),
    continuous = is.numeric(x) && !is.factor(x),
    count = is.numeric(x) && !is.factor(x),
    proportion = is.numeric(x) && !is.factor(x),
    zi_count = is.numeric(x) && !is.factor(x),
    TRUE
  )
  if (!isTRUE(ok)) {
    if (identical(unname(tp), "ordinal")) {
      # Backtick-quote non-syntactic names so the suggested code is valid R.
      nm_code <- deparse1(as.name(nm), backtick = TRUE)
      stop("Trait '", nm, "' is declared \"ordinal\", but you have not ",
           "provided the order of its levels. Pass ordinal_levels = list(",
           nm_code, " = c(...)) listing the levels from lowest to highest, ",
           "or make the column an ordered factor with ordered().",
           call. = FALSE)
    }
    stop("Trait '", nm, "' is declared \"", tp, "\" but the column ",
         "contradicts that type.", call. = FALSE)
  }
  invisible(TRUE)
}

#' @keywords internal
detect_trait_types <- function(traits, overrides = NULL) {
  types <- character(ncol(traits))
  names(types) <- colnames(traits)
  auto_count_cols <- character(0)
  neg_int_cols    <- character(0)

  if (!is.null(overrides)) {
    if (is.null(names(overrides)) || any(!nzchar(names(overrides)))) {
      stop("'trait_types' must be a named character vector.", call. = FALSE)
    }
    unknown <- setdiff(names(overrides), colnames(traits))
    if (length(unknown)) {
      stop("'trait_types' names not found in trait columns: ",
           paste(unknown, collapse = ", "), ".", call. = FALSE)
    }
  }

  for (nm in colnames(traits)) {
    x <- traits[[nm]]
    if (!is.null(overrides) && nm %in% names(overrides)) {
      types[nm] <- match.arg(overrides[nm],
                             c("continuous", "binary", "categorical",
                               "ordinal", "count", "proportion",
                               "zi_count"))
      .validate_declared_trait_type(nm, x, types[nm])
      next
    }
    if (is.ordered(x)) {
      nlev <- nlevels(x)
      types[nm] <- if (nlev == 2) "binary" else "ordinal"
    } else if (is.factor(x)) {
      nlev <- nlevels(x)
      types[nm] <- if (nlev == 2) "binary" else "categorical"
    } else if (is.integer(x)) {
      # A count cannot be negative.  Without this guard a negative integer
      # column auto-detects as "count" and its log1p encoding produces NaN
      # (P1-13).  This is a fail-closed correction, not a heuristic: the
      # data contradict the type.
      if (any(x < 0, na.rm = TRUE)) {
        types[nm] <- "continuous"
        neg_int_cols <- c(neg_int_cols, nm)
      } else {
        types[nm] <- "count"
        auto_count_cols <- c(auto_count_cols, nm)
      }
    } else if (is.numeric(x)) {
      types[nm] <- "continuous"
    } else {
      stop("Cannot determine type for column '", nm, "' (class: ",
           paste(class(x), collapse = "/"), ").")
    }
  }

  # P1-13: `read.csv()` returns whole-number columns as integer, so a
  # continuous trait measured in whole units silently becomes a "count"
  # (log1p-encoded, count semantics downstream).  Auto-detection cannot
  # tell the two apart from storage class alone, so surface the decision
  # rather than making it silently.
  # A message, not a warning: genuine count traits are common, and warning on
  # every one of them would cry wolf (and trip `expect_silent()` tests).  The
  # point is to make the inference visible, not to alarm.
  if (length(auto_count_cols)) {
    message("Auto-detected trait type \"count\" (log1p-encoded) for integer ",
            "column(s): ", paste(auto_count_cols, collapse = ", "),
            ". If any is a continuous measurement stored as whole numbers ",
            "(common after read.csv), override it: trait_types = c(",
            auto_count_cols[1], " = \"continuous\").")
  }
  if (length(neg_int_cols)) {
    message("Integer column(s) with negative values treated as continuous, ",
            "not count: ", paste(neg_int_cols, collapse = ", "),
            " (a count cannot be negative).")
  }
  types
}


# ---- Internal: build trait map ----------------------------------------------

#' Internal: build trait map from type labels
#' @keywords internal
#' @noRd
build_trait_map <- function(traits, types, log_set, center, scale,
                            multi_proportion_groups = NULL) {
  tmap <- list()
  col_offset <- 0L
  group_member_cols <- unlist(multi_proportion_groups, use.names = FALSE)

  # Iterate over named columns of `types` (which excludes group members)
  for (nm in names(types)) {
    tp <- unname(types[nm])
    x  <- traits[[nm]][!is.na(traits[[nm]])]

    entry <- list(name = nm, type = tp)

    if (tp == "continuous") {
      do_log <- nm %in% log_set
      vals <- if (do_log) log(x) else as.numeric(x)
      m <- if (center && length(vals) > 0) mean(vals) else 0
      s <- if (scale && length(vals) > 1) stats::sd(vals) else 1
      if (s == 0) s <- 1
      entry$n_latent      <- 1L
      entry$latent_cols   <- col_offset + 1L
      entry$levels        <- NULL
      entry$log_transform <- do_log
      entry$mean          <- m
      entry$sd            <- s
      # Phase G (2026-05-01): observed range in original units, used by
      # the optional `clamp_outliers` argument to predict.pigauto_fit() to
      # cap tail-extrapolation amplified by the back-transform.  Only
      # populated for log-transformed traits where expm1/exp() can blow up
      # latent overshoots; left NA for untransformed continuous (which
      # decode linearly and don't need clamping).
      if (do_log && length(stats::na.omit(as.numeric(x))) > 0L) {
        entry$obs_max <- max(as.numeric(x), na.rm = TRUE)
        entry$obs_min <- min(as.numeric(x), na.rm = TRUE)
      } else {
        entry$obs_max <- NA_real_
        entry$obs_min <- NA_real_
      }

    } else if (tp == "count") {
      # P1-10 fail-closed: count encoding is log1p, so a negative value
      # would silently become NaN and propagate through the whole latent
      # matrix. Auto-detection now routes negative integers to continuous,
      # but an explicit trait_types = c(x = "count") can still contradict
      # the data — refuse rather than encode nonsense.
      xnum <- as.numeric(x)
      if (any(xnum < 0, na.rm = TRUE)) {
        stop("Trait '", nm, "' is typed \"count\" but contains negative ",
             "value(s) (min = ", min(xnum, na.rm = TRUE), "). Counts cannot ",
             "be negative and are log1p-encoded, which would produce NaN. ",
             "Use trait_types = c(", nm, " = \"continuous\") instead.",
             call. = FALSE)
      }
      vals <- log1p(xnum)
      m <- if (center && length(vals) > 0) mean(vals) else 0
      s <- if (scale && length(vals) > 1) stats::sd(vals) else 1
      if (s == 0) s <- 1
      entry$n_latent      <- 1L
      entry$latent_cols   <- col_offset + 1L
      entry$levels        <- NULL
      entry$log_transform <- FALSE
      entry$mean          <- m
      entry$sd            <- s
      # Phase G: count is always log1p-z; expm1 back-transform amplifies
      # tail overshoots.  Clamp at obs_max * clamp_factor when the user
      # opts in via predict(clamp_outliers = TRUE).
      if (length(stats::na.omit(as.numeric(x))) > 0L) {
        entry$obs_max <- max(as.numeric(x), na.rm = TRUE)
        entry$obs_min <- min(as.numeric(x), na.rm = TRUE)
      } else {
        entry$obs_max <- NA_real_
        entry$obs_min <- NA_real_
      }

    } else if (tp == "ordinal") {
      int_vals <- as.integer(x) - 1L  # 0-based
      vals <- as.numeric(int_vals)
      m <- if (center && length(vals) > 0) mean(vals) else 0
      s <- if (scale && length(vals) > 1) stats::sd(vals) else 1
      if (s == 0) s <- 1
      entry$n_latent      <- 1L
      entry$latent_cols   <- col_offset + 1L
      entry$levels        <- levels(traits[[nm]])
      entry$log_transform <- FALSE
      entry$mean          <- m
      entry$sd            <- s

    } else if (tp == "binary") {
      levs <- levels(traits[[nm]])
      if (is.null(levs)) levs <- sort(unique(x))
      entry$n_latent      <- 1L
      entry$latent_cols   <- col_offset + 1L
      entry$levels        <- levs
      entry$log_transform <- FALSE
      entry$mean          <- NA_real_
      entry$sd            <- NA_real_

    } else if (tp == "categorical") {
      levs <- levels(traits[[nm]])
      if (is.null(levs)) levs <- sort(unique(x))
      K <- length(levs)
      entry$n_latent      <- K
      entry$latent_cols   <- col_offset + seq_len(K)
      entry$levels        <- levs
      entry$log_transform <- FALSE
      entry$mean          <- NA_real_
      entry$sd            <- NA_real_

    } else if (tp == "proportion") {
      # P1-10 fail-closed: the 0.001/0.999 clamp exists to keep qlogis()
      # finite at exact 0 and 1 — NOT to absorb out-of-range data. Values
      # like 1.5 or -0.3 (or a 0-100 percentage column mistyped as a
      # proportion) were silently squashed to the boundary and encoded as
      # if they were legitimate. Refuse them; keep clamping the boundary.
      xnum <- as.numeric(x)
      bad <- which(is.finite(xnum) & (xnum < 0 | xnum > 1))
      if (length(bad)) {
        rng <- range(xnum[bad])
        stop("Trait '", nm, "' is typed \"proportion\" but ", length(bad),
             " value(s) fall outside [0, 1] (range ", rng[1], " to ", rng[2],
             "). If these are percentages, divide by 100; if the trait is ",
             "unbounded, use \"continuous\".", call. = FALSE)
      }
      # Logit transform: qlogis(clamp(x, 0.001, 0.999)), then z-score
      vals <- stats::qlogis(pmin(pmax(xnum, 0.001), 0.999))
      m <- if (center && length(vals) > 0) mean(vals) else 0
      s <- if (scale && length(vals) > 1) stats::sd(vals) else 1
      if (s == 0) s <- 1
      entry$n_latent      <- 1L
      entry$latent_cols   <- col_offset + 1L
      entry$levels        <- NULL
      entry$log_transform <- FALSE
      entry$mean          <- m
      entry$sd            <- s

    } else if (tp == "zi_count") {
      # Two latent columns: gate (binary 0/1) + magnitude (log1p-z of non-zeros)
      nz <- x[x > 0]
      nz_log <- if (length(nz) > 0) log1p(as.numeric(nz)) else numeric(0)
      m_nz <- if (center && length(nz_log) > 0) mean(nz_log) else 0
      s_nz <- if (scale && length(nz_log) > 1) stats::sd(nz_log) else 1
      if (s_nz == 0) s_nz <- 1
      entry$n_latent      <- 2L
      entry$latent_cols   <- col_offset + 1:2
      entry$levels        <- NULL
      entry$log_transform <- FALSE
      entry$mean          <- m_nz      # for magnitude column z-scoring
      entry$sd            <- s_nz
      entry$zero_frac     <- sum(x == 0) / length(x)
      # Phase G: same expm1 amplification hazard as count.  Use the
      # non-zero observations to derive the clamp range (zero values
      # would push obs_min to 0 and make the lower clamp meaningless).
      if (length(nz) > 0L) {
        entry$obs_max <- max(as.numeric(nz), na.rm = TRUE)
        entry$obs_min <- min(as.numeric(nz), na.rm = TRUE)
      } else {
        entry$obs_max <- NA_real_
        entry$obs_min <- NA_real_
      }
    }

    col_offset <- col_offset + entry$n_latent
    tmap[[nm]] <- entry
  }

  # ---- Multi-proportion group entries (CLR + per-component z-scoring) ----
  # Each group becomes ONE trait_map entry with K latent columns.
  if (!is.null(multi_proportion_groups)) {
    eps <- 1e-6   # for log-safety on observed zeros
    for (gnm in names(multi_proportion_groups)) {
      gcols <- multi_proportion_groups[[gnm]]
      K <- length(gcols)
      mat_raw <- as.matrix(traits[, gcols, drop = FALSE])
      storage.mode(mat_raw) <- "double"

      # Only use rows with NO NAs across the group for fitting mean/sd
      complete_rows <- stats::complete.cases(mat_raw)
      mat_fit <- mat_raw[complete_rows, , drop = FALSE]

      # P1-10 fail-closed: the group is documented as summing to 1, but
      # nothing enforced it. The eps-clamp + renormalise below will happily
      # turn ANY complete row into a simplex point — including a row of all
      # zeros (which becomes a uniform composition invented from no data)
      # and a 0-100 percentage row (silently rescaled). Both then encode as
      # if legitimate. Check before renormalising.
      if (nrow(mat_fit) > 0L) {
        if (any(mat_fit < 0, na.rm = TRUE)) {
          stop("multi_proportion group '", gnm, "' contains negative value(s) ",
               "(min = ", min(mat_fit, na.rm = TRUE), "). Compositional ",
               "components must be non-negative.", call. = FALSE)
        }
        rs_check <- rowSums(mat_fit)
        bad <- which(abs(rs_check - 1) > 0.01)
        if (length(bad)) {
          stop("multi_proportion group '", gnm, "' has ", length(bad),
               " complete row(s) whose components do not sum to 1 ",
               "(observed sums range ", signif(min(rs_check[bad]), 4), " to ",
               signif(max(rs_check[bad]), 4), "; tolerance 1%). ",
               "If these are percentages, divide by 100; if a row is entirely ",
               "unobserved, set its components to NA rather than 0.",
               call. = FALSE)
        }
      }

      # Handle zeros: replace with eps, re-normalise so rows still sum to ~1
      if (nrow(mat_fit) > 0L) {
        mat_fit <- pmax(mat_fit, eps)
        rs <- rowSums(mat_fit)
        mat_fit <- mat_fit / rs
        # CLR: log(x) - mean(log(x)) row-wise
        log_mat <- log(mat_fit)
        gmean_row <- rowMeans(log_mat)
        clr_mat <- log_mat - gmean_row
      } else {
        clr_mat <- matrix(NA_real_, 0L, K)
      }

      mu <- if (center && nrow(clr_mat) > 0L) colMeans(clr_mat) else rep(0, K)
      sd_vec <- if (scale && nrow(clr_mat) > 1L) {
        apply(clr_mat, 2L, stats::sd)
      } else {
        rep(1, K)
      }
      sd_vec[sd_vec == 0] <- 1

      entry <- list(
        name          = gnm,
        type          = "multi_proportion",
        n_latent      = K,
        latent_cols   = col_offset + seq_len(K),
        levels        = gcols,      # component names
        input_cols    = gcols,      # original column names in traits
        log_transform = FALSE,
        mean          = mu,         # K-vector
        sd            = sd_vec,     # K-vector
        epsilon       = eps
      )
      col_offset <- col_offset + K
      tmap[[gnm]] <- entry
    }
  }

  tmap
}


# ---- Internal: encode to latent matrix --------------------------------------

#' @keywords internal
encode_to_latent <- function(traits, trait_map) {
  n       <- nrow(traits)
  p_latent <- sum(vapply(trait_map, "[[", integer(1), "n_latent"))
  X       <- matrix(NA_real_, nrow = n, ncol = p_latent)

  lat_names <- character(p_latent)

  for (tm in trait_map) {
    nm  <- tm$name
    col <- traits[[nm]]

    if (tm$type == "continuous") {
      vals <- as.numeric(col)
      if (tm$log_transform) vals <- log(vals)
      vals <- (vals - tm$mean) / tm$sd
      X[, tm$latent_cols] <- vals
      lat_names[tm$latent_cols] <- nm

    } else if (tm$type == "count") {
      vals <- log1p(as.numeric(col))
      vals <- (vals - tm$mean) / tm$sd
      X[, tm$latent_cols] <- vals
      lat_names[tm$latent_cols] <- nm

    } else if (tm$type == "ordinal") {
      vals <- as.numeric(as.integer(col) - 1L)
      vals <- (vals - tm$mean) / tm$sd
      X[, tm$latent_cols] <- vals
      lat_names[tm$latent_cols] <- nm

    } else if (tm$type == "binary") {
      # Second level = 1, first level = 0
      vals <- as.numeric(col == tm$levels[2])
      vals[is.na(col)] <- NA_real_
      X[, tm$latent_cols] <- vals
      lat_names[tm$latent_cols] <- nm

    } else if (tm$type == "categorical") {
      K    <- tm$n_latent
      levs <- tm$levels
      for (k in seq_len(K)) {
        vals <- as.numeric(col == levs[k])
        vals[is.na(col)] <- NA_real_
        X[, tm$latent_cols[k]] <- vals
        lat_names[tm$latent_cols[k]] <- paste0(nm, "=", levs[k])
      }

    } else if (tm$type == "proportion") {
      vals <- as.numeric(col)
      vals <- stats::qlogis(pmin(pmax(vals, 0.001), 0.999))
      vals <- (vals - tm$mean) / tm$sd
      X[, tm$latent_cols] <- vals
      lat_names[tm$latent_cols] <- nm

    } else if (tm$type == "multi_proportion") {
      # K CLR columns, per-component z-score, small epsilon for zeros
      mat_raw <- as.matrix(traits[, tm$input_cols, drop = FALSE])
      storage.mode(mat_raw) <- "double"
      K  <- tm$n_latent
      lc <- tm$latent_cols
      eps <- tm$epsilon

      complete_rows <- stats::complete.cases(mat_raw)

      # Replace zeros/small values with epsilon and re-normalise
      mat <- mat_raw
      mat[complete_rows, ] <- pmax(mat_raw[complete_rows, , drop = FALSE], eps)
      rs <- rowSums(mat[complete_rows, , drop = FALSE])
      mat[complete_rows, ] <- mat[complete_rows, , drop = FALSE] / rs

      # CLR
      clr <- matrix(NA_real_, nrow(mat_raw), K)
      if (any(complete_rows)) {
        log_mat <- log(mat[complete_rows, , drop = FALSE])
        clr[complete_rows, ] <- log_mat - rowMeans(log_mat)
      }
      # Per-component z-score
      for (k in seq_len(K)) {
        clr[, k] <- (clr[, k] - tm$mean[k]) / tm$sd[k]
      }
      X[, lc] <- clr
      lat_names[lc] <- paste0(tm$name, "=", tm$levels)
      next

    } else if (tm$type == "zi_count") {
      lc <- tm$latent_cols
      raw <- as.numeric(col)
      # Column 1 (gate): 0 = zero, 1 = non-zero, NA = missing
      gate <- rep(NA_real_, length(raw))
      gate[!is.na(raw) & raw == 0] <- 0
      gate[!is.na(raw) & raw > 0]  <- 1
      X[, lc[1]] <- gate
      lat_names[lc[1]] <- paste0(nm, "_gate")
      # Column 2 (magnitude): log1p-z of non-zero values, NA otherwise
      mag <- rep(NA_real_, length(raw))
      nz_idx <- !is.na(raw) & raw > 0
      if (any(nz_idx)) {
        mag[nz_idx] <- (log1p(raw[nz_idx]) - tm$mean) / tm$sd
      }
      X[, lc[2]] <- mag
      lat_names[lc[2]] <- paste0(nm, "_mag")
    }
  }

  rownames(X) <- rownames(traits)
  colnames(X) <- lat_names
  list(X = X)
}


#' @rdname preprocess_traits
#' @param x A preprocessed trait-data object.
#' @param ... Ignored. Included for compatibility with the base \code{print()}
#'   generic.
#' @section Printing:
#' Reports species and trait counts, and observation counts plus the
#' observation-per-species range and median in multi-observation mode.
#' With \code{trait_map}, it reports type counts and the latent-column
#' count. Without \code{trait_map}, it reports column names and log-transform
#' status. The latent-cell missing fraction is printed only when greater
#' than zero and can differ from original-cell missingness. Covariates are
#' stored in \code{x$covariates}, not displayed by this method. The dots
#' argument is unused.
#' @return The print method returns `x` invisibly.
#' @export
print.pigauto_data <- function(x, ...) {
  cat("pigauto_data\n")
  cat("  Species:", x$n_species %||% length(x$species_names), "\n")
  if (isTRUE(x$multi_obs)) {
    cat("  Observations:", x$n_obs, "\n")
    obs_per_sp <- table(x$obs_to_species)
    cat("  Obs/species: min=", min(obs_per_sp), " median=",
        stats::median(obs_per_sp), " max=", max(obs_per_sp), "\n", sep = "")
  }
  cat("  Traits: ", length(x$trait_names), "\n")

  if (!is.null(x$trait_map)) {
    types <- vapply(x$trait_map, "[[", character(1), "type")
    type_tab <- table(types)
    cat("  Types:  ",
        paste(names(type_tab), type_tab, sep = "=", collapse = ", "), "\n")
    cat("  Latent columns:", x$p_latent, "\n")
  } else {
    cat("  Columns:", paste(x$trait_names, collapse = ", "), "\n")
    cat("  Log-transformed:", x$log_transform, "\n")
  }

  missing_frac <- mean(is.na(x$X_scaled))
  if (missing_frac > 0) {
    cat("  Missing values:", round(100 * missing_frac, 1), "%\n")
  }
  invisible(x)
}
