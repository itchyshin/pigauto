## ----setup, message=FALSE-----------------------------------------------------
library(pigauto)
data(avonet300, tree300)
set.seed(42)
tree <- ape::keep.tip(tree300, sample(tree300$tip.label, 80))
traits <- avonet300[match(tree$tip.label, avonet300$Species_Key),
                    c("Mass", "Wing.Length", "Trophic.Level",
                      "Primary.Lifestyle"), drop = FALSE]
rownames(traits) <- tree$tip.label
traits$Mass[1:8] <- NA
traits$Wing.Length[6:13] <- NA
traits$Trophic.Level[4:11] <- NA
traits$Primary.Lifestyle[10:17] <- NA
x <- preprocess_traits(traits, tree)

## ----fig.height=6, fig.width=8, out.width="100%"------------------------------
plot_missingness(x, "summary")
plot_missingness(x, "matrix")

## ----fig.height=6, fig.width=8, out.width="100%"------------------------------
plot_missingness(x, "phylo", tree)
plot_missingness(x, "co_missing")

## ----fit-plots, message=FALSE, fig.width=8, fig.height=5----------------------
result <- impute(traits, tree, gnn = FALSE, verbose = FALSE, seed = 7)
missing_mass <- which(is.na(traits$Mass))
mass_predictions <- data.frame(
  species = rownames(traits)[missing_mass],
  predicted_mass_g = result$prediction$imputed[missing_mass, "Mass"],
  lower_g = result$prediction$conformal_lower[missing_mass, "Mass"],
  upper_g = result$prediction$conformal_upper[missing_mass, "Mass"],
  hidden_mass_g = avonet300$Mass[match(rownames(traits)[missing_mass],
                                       avonet300$Species_Key)],
  row.names = NULL
)
mass_predictions

## ----mass-intervals, fig.width=8, fig.height=5--------------------------------
ggplot2::ggplot(mass_predictions,
  ggplot2::aes(x = predicted_mass_g, y = species,
               xmin = lower_g, xmax = upper_g)) +
  ggplot2::geom_pointrange(orientation = "y") +
  ggplot2::geom_point(ggplot2::aes(x = hidden_mass_g),
                      shape = 4, colour = "#B33A3A", size = 2.5) +
  ggplot2::scale_x_log10() +
  ggplot2::labs(x = "Predicted body mass (g; log scale)", y = NULL,
                title = "Missing body masses: predictions and exploratory intervals") +
  ggplot2::theme_minimal()

## ----categorical-predictions--------------------------------------------------
missing_diet <- which(is.na(traits$Trophic.Level))
data.frame(
  species = rownames(traits)[missing_diet],
  predicted_trophic_level = result$prediction$imputed[missing_diet, "Trophic.Level"],
  hidden_trophic_level = avonet300$Trophic.Level[
    match(rownames(traits)[missing_diet], avonet300$Species_Key)],
  row.names = NULL
)

## ----evaluation, message=FALSE------------------------------------------------
evaluate(result$fit)

